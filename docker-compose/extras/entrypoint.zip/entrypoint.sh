#!/bin/bash
# =============================================================================
# Arranque de Sybase ASE 16 para desarrollo.
#
# Sustituye al entrypoint de datagrip/sybase:16.0, que espera mensajes de un
# log que ya viene dentro de la imagen (por eso inicializa demasiado pronto),
# crea la base sobre el device "master" y falla si la contraseña lleva "!".
#
# Este script:
#   1. arranca dataserver,
#   2. espera a que ASE acepte conexiones (timeout configurable),
#   3. crea devices, base, login y permisos solo si no existen (idempotente),
#   4. aplica el tamaño del pool de locks,
#   5. se queda en primer plano y cierra ASE limpio al recibir SIGTERM.
#
# Toda la configuración llega por variables de entorno (ver docker-compose.yml
# y .env).
# =============================================================================

export SYBASE=/opt/sybase
# Ojo: SYBASE.sh usa variables opcionales (INCLUDE, LIB...), por eso se carga
# antes de activar el modo estricto de variables.
# shellcheck disable=SC1091
. "$SYBASE/SYBASE.sh" >/dev/null 2>&1

set -u

ISQL="$SYBASE/OCS-16_0/bin/isql"
DATA_DIR="$SYBASE/data"
LOG_FILE="$SYBASE/ASE-16_0/install/MYSYBASE.log"

: "${SYBASE_HOSTNAME:=MYSYBASE}"
: "${SYBASE_USER:=dev}"
: "${SYBASE_PASSWORD:=guest1234}"
: "${SYBASE_DB:=dev_db}"
: "${SYBASE_DATA_SIZE_MB:=1024}"
: "${SYBASE_LOG_SIZE_MB:=512}"
: "${SYBASE_NUMBER_OF_LOCKS:=50000}"
# Clave de sa fijada en la imagen durante el build; no es configurable.
: "${SYBASE_SA_PASSWORD:=myPassword}"
: "${SYBASE_STARTUP_TIMEOUT:=600}"
: "${SYBASE_SHUTDOWN_TIMEOUT:=60}"

SERVER_PID=""
SHUTTING_DOWN=0

log() { printf '[sybase] %s\n' "$*"; }
die() { printf '[sybase] ERROR: %s\n' "$*" >&2; exit 1; }

sql_quote() { printf '%s' "$1" | sed "s/'/''/g"; }

# Ejecuta SQL por stdin como sa. --retserverror hace que isql devuelva un
# código distinto de 0 si el servidor reporta un error.
run_sql() {
  "$ISQL" -Usa -P"$SYBASE_SA_PASSWORD" -S"$SYBASE_HOSTNAME" \
    -l 5 -t 30 -b --retserverror -w 300
}

# Devuelve el valor numérico de una consulta (vacío si falla o no hay filas).
query_scalar() {
  printf '%s\ngo\n' "$1" | run_sql -h 2>/dev/null |
    tr -d ' \t' | grep -Ex '[0-9]+' | tail -n 1
}

device_exists() {
  [ "$(query_scalar "select count(*) from master.dbo.sysdevices where name = '$(sql_quote "$1")'")" = "1" ]
}

login_exists() {
  [ "$(query_scalar "select count(*) from master.dbo.syslogins where name = '$(sql_quote "$SYBASE_USER")'")" = "1" ]
}

database_exists() {
  [ "$(query_scalar "select count(*) from master.dbo.sysdatabases where name = '$(sql_quote "$SYBASE_DB")'")" = "1" ]
}

db_user_exists() {
  [ "$(query_scalar "select count(*) from $SYBASE_DB.dbo.sysusers where name = '$(sql_quote "$SYBASE_USER")'")" = "1" ]
}

validate_config() {
  [[ "$SYBASE_USER" =~ ^[A-Za-z][A-Za-z0-9_]*$ ]] ||
    die "SYBASE_USER debe ser un identificador simple (letras, números, _)"
  [[ "$SYBASE_DB" =~ ^[A-Za-z][A-Za-z0-9_]*$ ]] ||
    die "SYBASE_DB debe ser un identificador simple (letras, números, _)"
  [[ "$SYBASE_DATA_SIZE_MB" =~ ^[1-9][0-9]*$ ]] ||
    die "SYBASE_DATA_SIZE_MB debe ser un entero positivo"
  [[ "$SYBASE_LOG_SIZE_MB" =~ ^[1-9][0-9]*$ ]] ||
    die "SYBASE_LOG_SIZE_MB debe ser un entero positivo"
}

ping_ase() {
  printf 'select 1\ngo\n' | run_sql >/dev/null 2>&1
}

start_server() {
  log "Iniciando ASE ($SYBASE_HOSTNAME)..."
  sh "$SYBASE/ASE-16_0/install/RUN_MYSYBASE" >/tmp/dataserver.out 2>&1 &
  SERVER_PID=$!

  local deadline=$((SECONDS + SYBASE_STARTUP_TIMEOUT))
  log "Esperando a que ASE acepte conexiones (máx. ${SYBASE_STARTUP_TIMEOUT}s)..."
  while (( SECONDS < deadline )); do
    if ! kill -0 "$SERVER_PID" 2>/dev/null; then
      tail -n 20 /tmp/dataserver.out >&2 2>/dev/null || true
      die "dataserver terminó durante el arranque; revisar $LOG_FILE"
    fi
    if ping_ase; then
      log "ASE acepta conexiones"
      return 0
    fi
    sleep 2
  done
  die "timeout esperando a que ASE arranque"
}

init_database() {
  if ! device_exists app_data; then
    log "Creando device app_data (${SYBASE_DATA_SIZE_MB} MiB)..."
    run_sql <<SQL || die "no se pudo crear el device app_data"
disk init name = 'app_data', physname = '$DATA_DIR/app_data.dat', size = '${SYBASE_DATA_SIZE_MB}M'
go
SQL
  fi

  if ! device_exists app_log; then
    log "Creando device app_log (${SYBASE_LOG_SIZE_MB} MiB)..."
    run_sql <<SQL || die "no se pudo crear el device app_log"
disk init name = 'app_log', physname = '$DATA_DIR/app_log.dat', size = '${SYBASE_LOG_SIZE_MB}M'
go
SQL
  fi

  log "Creando base de datos $SYBASE_DB..."
  run_sql <<SQL || die "no se pudo crear la base $SYBASE_DB"
create database $SYBASE_DB on app_data = '${SYBASE_DATA_SIZE_MB}M' log on app_log = '${SYBASE_LOG_SIZE_MB}M'
go
SQL

  log "Configurando opciones de $SYBASE_DB..."
  run_sql <<SQL || die "no se pudieron aplicar las opciones de $SYBASE_DB"
use master
go
exec sp_dboption '$SYBASE_DB', 'abort tran on log full', true
go
exec sp_dboption '$SYBASE_DB', 'allow nulls by default', true
go
exec sp_dboption '$SYBASE_DB', 'ddl in tran', true
go
exec sp_dboption '$SYBASE_DB', 'trunc log on chkpt', true
go
exec sp_dboption '$SYBASE_DB', 'select into', true
go
SQL
}

ensure_login() {
  if login_exists; then
    return 0
  fi
  log "Creando login $SYBASE_USER..."
  run_sql <<SQL || die "no se pudo crear el login $SYBASE_USER"
create login $SYBASE_USER with password '$(sql_quote "$SYBASE_PASSWORD")'
go
SQL
}

ensure_db_user() {
  if db_user_exists; then
    return 0
  fi
  log "Agregando el usuario $SYBASE_USER a $SYBASE_DB con permisos de desarrollo..."
  run_sql <<SQL || die "no se pudo agregar el usuario $SYBASE_USER"
use $SYBASE_DB
go
sp_adduser '$SYBASE_USER', '$SYBASE_USER', null
go
grant create default to $SYBASE_USER
go
grant create table to $SYBASE_USER
go
grant create view to $SYBASE_USER
go
grant create rule to $SYBASE_USER
go
grant create function to $SYBASE_USER
go
grant create procedure to $SYBASE_USER
go
SQL
}

apply_lock_pool() {
  [[ "$SYBASE_NUMBER_OF_LOCKS" =~ ^[1-9][0-9]*$ ]] ||
    die "SYBASE_NUMBER_OF_LOCKS debe ser un entero positivo"
  log "Aplicando number of locks = $SYBASE_NUMBER_OF_LOCKS..."
  run_sql <<SQL || die "no se pudo configurar el pool de locks"
use master
go
exec sp_configure 'number of locks', $SYBASE_NUMBER_OF_LOCKS
go
SQL
}

stop_server() {
  [ "$SHUTTING_DOWN" = "1" ] && return 0
  SHUTTING_DOWN=1
  [ -n "$SERVER_PID" ] || return 0

  log "Deteniendo ASE..."
  printf 'shutdown\ngo\n' | run_sql >/dev/null 2>&1 || true

  local i
  for i in $(seq 1 "$SYBASE_SHUTDOWN_TIMEOUT"); do
    kill -0 "$SERVER_PID" 2>/dev/null || { log "ASE detenido"; return 0; }
    sleep 1
  done

  log "Forzando cierre de ASE..."
  pkill -TERM -x dataserver 2>/dev/null || true
  sleep 5
  pkill -KILL -x dataserver 2>/dev/null || true
}

trap 'stop_server; exit 0' INT TERM

main() {
  validate_config
  start_server

  if database_exists; then
    log "La base $SYBASE_DB ya existe; se conservan los datos"
  else
    init_database
  fi

  ensure_login
  ensure_db_user
  apply_lock_pool

  log "Listo: $SYBASE_DB en $SYBASE_HOSTNAME:5000 (usuario $SYBASE_USER)"
  wait "$SERVER_PID"
  local rc=$?
  [ "$SHUTTING_DOWN" = "1" ] && exit 0
  log "dataserver terminó con código $rc"
  exit "$rc"
}

main "$@"
