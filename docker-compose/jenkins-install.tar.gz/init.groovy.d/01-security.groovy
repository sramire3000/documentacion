import hudson.model.User
import hudson.security.FullControlOnceLoggedInAuthorizationStrategy
import hudson.security.HudsonPrivateSecurityRealm
import hudson.tasks.Mailer
import jenkins.model.Jenkins

// Crea el usuario administrador y los executors a partir de las variables
// definidas en .env. Solo actúa la primera vez (cuando aún no hay securityRealm).
def env = System.getenv()
def jenkins = Jenkins.get()

def adminId = env['JENKINS_ADMIN_ID']?.trim()
def adminPassword = env['JENKINS_ADMIN_PASSWORD']

if (!(jenkins.getSecurityRealm() instanceof HudsonPrivateSecurityRealm) && adminId && adminPassword) {
    def realm = new HudsonPrivateSecurityRealm(false)
    jenkins.setSecurityRealm(realm)

    def strategy = new FullControlOnceLoggedInAuthorizationStrategy()
    strategy.setAllowAnonymousRead(false)
    jenkins.setAuthorizationStrategy(strategy)

    def user = realm.createAccount(adminId, adminPassword)
    user.setFullName(env['JENKINS_ADMIN_NAME'] ?: 'Jenkins Admin')
    def email = env['JENKINS_ADMIN_EMAIL']
    if (email) {
        user.addProperty(new Mailer.UserProperty(email))
    }
    user.save()

    jenkins.save()
    println "[init] Usuario administrador '${adminId}' creado."
}

def executors = (env['JENKINS_EXECUTORS'] ?: '').trim()
if (executors.isInteger() && executors.toInteger() > 0) {
    jenkins.setNumExecutors(executors.toInteger())
    jenkins.save()
    println "[init] Executors configurados en ${executors}."
}
