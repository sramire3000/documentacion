# pdf2md — Convertidor de PDF a Markdown

CLI escrita en Go puro (sin CGO) que convierte un PDF con texto, tablas e imágenes en un archivo Markdown GFM, extrayendo las imágenes JPEG y PNG a un directorio `assets/`.

- Texto con posición y tamaño de fuente para reconstruir títulos, párrafos, listas y tablas.
- Tablas GFM detectadas por rectángulos y columnas alineadas, con degradación a texto si no se reconocen.
- Imágenes JPEG y PNG extraídas a `assets/<nombre-pdf>/page-<n>-img-<k>.<ext>`.
- Separador `---` entre páginas.

## Requisitos

- Go 1.27.4 (la versión declarada en `go.mod`).
- No hace falta compilador de C ni librerías del sistema: todo el stack es Go puro y se compila con `CGO_ENABLED=0`.
- Dependencias: `github.com/pdfcpu/pdfcpu` (imágenes) y `github.com/ledongthuc/pdf` (texto y posiciones). Se resuelven solas con `go mod download`.

## Compilación

### Linux (host actual)

```bash
CGO_ENABLED=0 go build -o dist/pdf2md ./cmd/pdf2md
```

Para ARM64 (servidores, Raspberry Pi):

```bash
CGO_ENABLED=0 GOOS=linux GOARCH=arm64 go build -o dist/pdf2md-linux-arm64 ./cmd/pdf2md
```

### Windows

Desde Linux/macOS (compilación cruzada):

```bash
CGO_ENABLED=0 GOOS=windows GOARCH=amd64 go build -o dist/pdf2md.exe ./cmd/pdf2md
```

Desde Windows (PowerShell o CMD):

```powershell
$env:CGO_ENABLED = "0"
go build -o pdf2md.exe ./cmd/pdf2md
```

También hay binario para ARM64 cambiando `GOARCH=arm64`.

| Destino          | Comando                                                        | Salida          |
| ---------------- | -------------------------------------------------------------- | --------------- |
| Linux x86-64     | `CGO_ENABLED=0 GOOS=linux GOARCH=amd64 go build -o dist/pdf2md ./cmd/pdf2md`   | `dist/pdf2md`   |
| Linux ARM64      | `CGO_ENABLED=0 GOOS=linux GOARCH=arm64 go build -o dist/pdf2md-linux-arm64 ./cmd/pdf2md` | `dist/pdf2md-linux-arm64` |
| Windows x86-64   | `CGO_ENABLED=0 GOOS=windows GOARCH=amd64 go build -o dist/pdf2md.exe ./cmd/pdf2md` | `dist/pdf2md.exe` |
| Windows ARM64    | `CGO_ENABLED=0 GOOS=windows GOARCH=arm64 go build -o dist/pdf2md-arm64.exe ./cmd/pdf2md` | `dist/pdf2md-arm64.exe` |
| WebAssembly WASI | `CGO_ENABLED=0 GOOS=wasip1 GOARCH=wasm go build -o dist/pdf2md.wasm ./cmd/pdf2md` | `dist/pdf2md.wasm` |

### Instalación local

```bash
go install ./cmd/pdf2md
```

El binario queda en `$(go env GOPATH)/bin/pdf2md` (agregá ese directorio al `PATH`).

### Verificación rápida del build

```bash
gofmt -l .
go vet ./...
go build ./...
go test ./...
```

## Uso

```text
pdf2md <archivo.pdf> [opciones]
```

| Opción            | Descripción                                                                 | Valor por defecto                          |
| ----------------- | --------------------------------------------------------------------------- | ------------------------------------------ |
| `-o`, `--output`  | Ruta del `.md` de salida. Admite rutas relativas y absolutas.                | Mismo nombre que el PDF, con `.md`         |
| `--assets-dir`    | Directorio donde se escriben las imágenes extraídas.                        | `assets/<nombre-pdf>/` junto al `.md`      |
| `--overwrite`     | Sobrescribe el `.md` si ya existe.                                          | No sobrescribe                            |
| `-h`, `--help`    | Muestra la ayuda.                                                           | —                                          |

Las opciones se pueden escribir antes o después de la ruta del PDF.

### Ejemplos

Conversión por defecto (genera el `.md` y `assets/` junto al PDF):

```bash
pdf2md documento.pdf
```

```text
documento.pdf
documento.md
assets/documento/page-1-img-1.jpg
assets/documento/page-2-img-1.png
```

Salida y assets en rutas explícitas:

```bash
pdf2md documento.pdf -o /tmp/salida/docs/reporte.md --assets-dir /tmp/salida/media
```

En el Markdown, las imágenes se referencian con la ruta relativa desde el `.md` hasta el directorio de assets (`../media/page-1-img-1.jpg` en el ejemplo anterior).

Sobrescribir una conversión previa:

```bash
pdf2md documento.pdf --overwrite
```

Windows:

```powershell
pdf2md.exe C:\docs\documento.pdf -o C:\docs\documento.md --assets-dir C:\docs\assets\documento
```

### Qué genera el Markdown

- Títulos `#`, `##` y `###` según el tamaño de fuente relativo a la mediana del documento.
- Párrafos reconstruidos agrupando líneas por línea base y orden de lectura.
- Listas con `•`, `-`, `*` o `N.` (las viñetas se normalizan a `-`).
- Tablas GFM con encabezado y separador `| --- |`; si la tabla no se reconoce, el contenido queda como texto.
- Imágenes como `![Imagen extraída de la página N](assets/<pdf>/page-N-img-K.ext)`.
- Una línea `---` entre páginas, sin separador al inicio ni al final del documento.

### Códigos de salida

| Código | Significado                                                                 |
| ------ | --------------------------------------------------------------------------- |
| `0`    | Conversión correcta (puede incluir advertencias por `stderr`).               |
| `1`    | Error general: PDF cifrado, PDF sin capa de texto u otro fallo de lectura/escritura. |
| `2`    | No se encontró el PDF de entrada. El mensaje incluye la ruta recibida.      |
| `3`    | El `.md` de salida ya existe y no se pasó `--overwrite`.                    |

Los errores se escriben por `stderr` con el prefijo `pdf2md:`. Las advertencias (por ejemplo, imágenes JPX/JBIG2/CCITT omitidas) también van a `stderr` y no cambian el código de salida.

## WebAssembly (WASI)

El binario se compila para `wasip1` y se ejecuta con cualquier runtime que implemente WASI preview 1 (Node 22+, wasmtime, Wasmer, wazero).

```bash
CGO_ENABLED=0 GOOS=wasip1 GOARCH=wasm go build -o dist/pdf2md.wasm ./cmd/pdf2md
```

El runtime debe preabrir dos tipos de directorios:

1. El directorio de trabajo con el PDF y donde se escribirán el `.md` y `assets/`.
2. Un `$HOME` escribible: `pdfcpu` crea su configuración al inicializarse en el directorio del usuario. Si no está preabierto y exportado en `env`, el proceso aborta con `panic: config problem: ... Bad file number`. `TMPDIR` es opcional, pero conviene preabrirlo si el runtime lo necesita.

### Ejecución con Node.js 22

Guardá este runner como `wasi-run.mjs`:

```javascript
import { WASI } from 'node:wasi';
import { argv } from 'node:process';
import { readFile } from 'node:fs/promises';

const [wasmPath, ...appArgs] = argv.slice(2);
const wasi = new WASI({
  version: 'preview1',
  args: ['pdf2md', ...appArgs],
  env: { HOME: '/home/user', TMPDIR: '/tmp' },
  preopens: {
    '/work': '/ruta/host/trabajo',
    '/home/user': '/ruta/host/home',
    '/tmp': '/ruta/host/tmp',
  },
  returnOnExit: true,
});

const wasm = await WebAssembly.compile(await readFile(wasmPath));
const instance = await WebAssembly.instantiate(wasm, wasi.getImportObject());
process.exit(await wasi.start(instance));
```

Prepará los directorios del host y ejecutá:

```bash
mkdir -p /ruta/host/trabajo /ruta/host/home /ruta/host/tmp
cp documento.pdf /ruta/host/trabajo/

node --experimental-wasi-unstable-preview1 wasi-run.mjs dist/pdf2md.wasm /work/documento.pdf
```

Salida esperada:

```text
/work/documento.md (2 páginas, 2 imágenes)
```

Con flags:

```bash
node --experimental-wasi-unstable-preview1 wasi-run.mjs \
  dist/pdf2md.wasm /work/documento.pdf -o /work/salida.md --assets-dir /work/media --overwrite
```

Notas:

- En WASI las rutas son las del sistema de archivos virtual (`/work/...`), no las del host.
- El binario `js/wasm` también compila, pero no sirve para esta CLI: no expone un sistema de archivos real.
- Los binarios WASM pesan alrededor de 22 MB porque incluyen `pdfcpu`.

## Estructura del proyecto

```text
cmd/pdf2md/main.go                              composition root (solo cablea dependencias)
internal/domain/model/                          Document, Page, Block, ImageAsset
internal/domain/errors/                         errores de negocio (ErrInputNotFound, ErrEncryptedPDF, …)
internal/domain/repository/                     puertos DocumentReader y OutputWriter
internal/application/dto/                       request/result de la conversión
internal/application/usecase/                   caso de uso y render Markdown
internal/infrastructure/persistence/            lector PDF, heurísticas de layout y escritor de archivos
internal/infrastructure/entrypoints/cli/        comando, flags y códigos de salida
internal/infrastructure/persistence/testdata/   PDF de ejemplo para tests
```

## Pruebas

```bash
go test ./...
```

El test de integración usa `internal/infrastructure/persistence/testdata/sample.pdf` y verifica títulos, tabla, listas, imágenes y separador de páginas.

Para probar el binario contra el fixture:

```bash
go run ./cmd/pdf2md internal/infrastructure/persistence/testdata/sample.pdf --overwrite
```

## Alcance y limitaciones

- Sin OCR: los PDF escaneados sin capa de texto devuelven error (`el PDF no tiene texto extraíble`).
- Sin descifrado: los PDF protegidos devuelven error (`el PDF está protegido con contraseña`).
- Imágenes JPX, JBIG2 y CCITT se omiten con una advertencia por `stderr`.
- No se emiten negritas, cursivas, enlaces, bloques de código ni notas al pie.
- Tablas anidadas o con celdas combinadas caen al texto por líneas.
- Sin detección de cabeceras/pies repetidos ni maquetación multicolumna.
- Sin conversión por lotes, modo watch ni servidor HTTP.
- Las imágenes se agregan al final de los bloques de su página, en orden de objeto del PDF.

## Problemas frecuentes

| Síntoma | Causa / solución |
| ------- | ---------------- |
| `el archivo de salida ya existe` (código 3) | Agregá `--overwrite` o cambiá `-o`. |
| No se creó `assets/` | El PDF no tiene imágenes JPEG/PNG; el directorio solo se crea si hay assets. |
| `advertencia: ... formato JPX no soportado` | Formato fuera de alcance; el resto del documento se convierte igual (código 0). |
| `panic: config problem: mkdir ... Bad file number` en WASI | Faltó preabrir `$HOME` escribible y exportarlo en `env`. |
| Binario grande | `pdfcpu` agrega peso; compilá con `-ldflags="-s -w"` si necesitás reducirlo. |
