## Golang Stacks

<!-- GOLANG_STACK:START -->

- **Lenguaje:** Go 1.27.4
- **Módulo Principal:** `github.com/hsr/go-convet-pdf-a-md`
- **Framework / Enrutador:** Ninguno (Standard Library)
- **Base de datos / Persistencia:** Ninguna
- **Librerías Clave:** Ninguna (sin dependencias externas)
- **Testing:** Ninguno por ahora (sin archivos `_test.go`)

<!-- GOLANG_STACK:END -->

## Arquitectura y convenciones (obligatorias)

<!-- ESTRUCTURA:START -->


Estas dos referencias son **de cumplimiento obligatorio** para cualquier agente, skill o cambio manual:

- **`references/estructura/estructura.md`** — estructura Clean Architecture para Go. Todo artefacto vive en una de estas capas:
  - `internal/domain/` — modelos, errores de negocio y puertos (interfaces); sin dependencias de infraestructura ni de frameworks.
  - `internal/application/` — casos de uso y DTOs de aplicación.
  - `internal/infrastructure/` — adaptadores: `entrypoints/http` (handlers), `entrypoints/cli` (comandos), `persistence`, `security`, `client`.
  - `internal/configuration/` — configuración global y wiring.
  - `cmd/<binario>/main.go` — composition root: solo cablea dependencias, sin lógica de negocio.

  Mapeo mínimo (módulo `<module>`, código privado bajo `internal/`):

  | Artefacto                        | Ruta                                                              |
  | -------------------------------- | ----------------------------------------------------------------- |
  | Entrypoint / `main`              | `cmd/<binario>/main.go`                                           |
  | Handler HTTP                     | `internal/infrastructure/entrypoints/http/<x>_handler.go`         |
  | DTO HTTP / mapper                | `.../entrypoints/http/dto/`, `.../entrypoints/http/mapper/`       |
  | Comando CLI                      | `internal/infrastructure/entrypoints/cli/<x>_command.go`          |
  | Caso de uso                      | `internal/application/usecase/<x>_usecase.go`                     |
  | DTO de aplicación                | `internal/application/dto/`                                       |
  | Modelo de dominio                | `internal/domain/model/`                                          |
  | Error de negocio                 | `internal/domain/errors/`                                         |
  | Puerto de repositorio            | `internal/domain/repository/`                                     |
  | Adaptador de persistencia        | `internal/infrastructure/persistence/<x>_repository.go`           |
  | Cliente externo                  | `internal/infrastructure/client/`                                 |
  | Seguridad                        | `internal/infrastructure/security/`                               |
  | Configuración y wiring           | `internal/configuration/`                                         |
  | Test                             | Junto al archivo probado: `<archivo>_test.go`                     |

  **Prohibido:** paquetes planos como `internal/controller`, `internal/service`, `internal/repository` o `internal/dto`, y usar `pkg/` para código privado. `cmd/` no contiene reglas de negocio. Los tests viven junto al código que prueban, en el mismo paquete o en `<paquete>_test`.

- **`references/instructions/instructions.md`** — convenciones de código: identificadores en inglés, comentarios y documentación de métodos en español solo cuando aporten valor, clean code/DRY/SOLID, sin código con “magia”, documentos `.md` en español y patrones de diseño cuando simplifiquen de verdad.

**Aplicación:** `/spec` debe reflejar estas rutas en la tabla de archivos y en cada paso del plan; `/spec-impl` debe detenerse y corregir el spec si las contradice. Si un artefacto no encaja en ninguna carpeta existente, no se inventa un paquete: se consulta antes.

<!-- ESTRUCTURA:END -->

## Flujo de specs (features grandes)

<!-- FLUJO DE SPECS:START -->

Skills en `.agents/skills/`:

- `/spec` — diseña la spec sección por sección y la guarda en `specs/NN-slug.md` (estado por defecto `Borrador`).
- `/spec-impl <NN-slug>` — implementa **solo si** el estado significa `Aprobado` en cualquier idioma (`Approved`, `Aprobado`, …); `Borrador`/`Draft`, `En revisión`, `Implementado` y `Obsoleto` la bloquean. Crea y cambia a la rama `spec-NN-slug`; `AutoCreateBranch` en `specs/.spec-config.yml` (default `true`, el archivo puede no existir todavía) controla la rama. No escribas código antes de que la spec esté aprobada.
- `/opencode-report-change-object <NN-slug>` — genera `reports/NN-slug.csv` con los objetos (archivos) nuevos, modificados y eliminados por la implementación, su tipo, el propósito global del spec y la fecha/hora. `/spec-impl` lo ejecuta automáticamente al final de la Fase 5, después de las métricas.
- `grill-me` — entrevista para afinar un plan o diseño antes de escribir la spec (invocación manual; ver `skills-lock.json`).

Comando y subagente en `.opencode/`:

- `/verify-spec <NN-slug>` (`.opencode/commands/verify-spec.md`) — delega en el subagente `spec-verifier` (`.opencode/agents/spec-verifier.md`); verifica criterios con evidencia y, si todos pasan, marca el spec como `Implementado`. Si hay una línea base de métricas abierta, **no** cambia el estado: el cierre vuelve a `/spec-impl`.

Orden de cierre con métricas (`opencode-metrics-spec`) y reporte de cambios (`opencode-report-change-object`):

1. `/spec-impl` arranca con `start` y, antes de cerrar, ofrece ejecutar `/verify-spec`.
2. La verificación puede ser automática (subagente) o manual en el mismo directorio: su sesión se crea después de `start` y se suma sola a la fila.
3. Después de verificar, se genera el reporte de cambios: `node .agents/skills/opencode-report-change-object/scripts/spec-changes-report.mjs --spec NN-slug`. Escribe `reports/NN-slug.csv` y se commitea junto con el cierre del spec.
4. Con el reporte generado, se ejecuta `finish` (si ya se había ejecutado, se repite: reemplaza la fila). El script de métricas excluye `metrics/` y `reports/` del diff para que el reporte no infle archivos ni LOC.
5. `finalize` se ejecuta recién al terminar la sesión. **Nunca antes de verificar**: borra la línea base y los tokens del verificador ya no se atribuyen. Si el reporte ya se generó, no hace falta regenerarlo.

Los comandos `/spec`, `/spec-impl` y `/opencode-report-change-object` se registran en `opencode.json`.

<!-- FLUJO DE SPECS:END -->

<!-- context7 -->

Usa Context7 MCP para obtener la documentación actualizada siempre que el usuario pregunte sobre una biblioteca, framework, SDK, API, herramienta de CLI o servicio en la nube — incluso sobre bibliotecas conocidas como React, Next.js, Prisma, Express, Tailwind, Django o Spring Boot. Esto incluye sintaxis de API, configuración, migración entre versiones, depuración específica de la biblioteca, instrucciones de configuración y uso de herramientas de CLI. Úsalo incluso cuando creas que ya conoces la respuesta — tus datos de entrenamiento podrían no reflejar cambios recientes. Prefiérelo antes que la búsqueda web para la documentación de bibliotecas.
No lo uses para: refactorización, escribir scripts desde cero, depurar lógica de negocio, revisión de código o conceptos generales de programación.
Pasos

1. Comienza siempre con resolve-library-id usando el nombre de la biblioteca y lo que deseas buscar en su documentación, a menos que el usuario proporcione un ID de biblioteca exacto en formato /org/project
2. Elige la mejor coincidencia (formato de ID: /org/project) según: coincidencia exacta del nombre, relevancia de la descripción, cantidad de fragmentos de código, reputación de la fuente (se prefiere Alta/Media) y puntuación de benchmark (cuanto más alta, mejor). Si los resultados no parecen correctos, prueba con nombres o consultas alternativas (por ejemplo, «next.js» en lugar de «nextjs», o reformula la pregunta). Usa IDs específicos de versión cuando el usuario mencione una versión
3. query-docs con el ID de biblioteca seleccionado y lo que deseas buscar en su documentación (no palabras sueltas), acotado a un solo concepto. Si la pregunta abarca varios conceptos distintos (por ejemplo, enrutamiento y autenticación y caché), haz una llamada query-docs separada por cada concepto con el mismo ID de biblioteca, a menos que la pregunta trate sobre cómo interactúan los conceptos — las consultas combinadas diluyen el ranking y devuelven resultados superficiales para cada tema
4. Responde usando la documentación obtenida
<!-- context7 -->

## MCPs y convenciones

<!-- MCPS:START -->

- **Playwright**: debe estar apagado.
- **Context7**: traé la doc actual del framework en vez de fiarte del entrenamiento.
- **Codebase Memory MCP**: convención del repo: consultar el grafo antes de leer archivos (`list_projects` → `get_architecture`).
<!-- MCPS:END -->

## Context7 MCP
