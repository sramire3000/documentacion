package main

import (
	"os"

	"github.com/hsr/go-convet-pdf-a-md/internal/application/usecase"
	"github.com/hsr/go-convet-pdf-a-md/internal/infrastructure/entrypoints/cli"
	"github.com/hsr/go-convet-pdf-a-md/internal/infrastructure/persistence"
)

func main() {
	reader := persistence.NewPDFDocumentReader()
	writer := persistence.NewMarkdownFileWriter()
	command := cli.NewConvertCommand(usecase.NewConvertPDFUseCase(reader, writer))
	os.Exit(command.Run(os.Args[1:], os.Stdout, os.Stderr))
}
