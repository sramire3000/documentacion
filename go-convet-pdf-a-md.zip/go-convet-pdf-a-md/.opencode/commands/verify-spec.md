---
description: Verifica los criterios de aceptación de un spec y marca los checks
agent: spec-verifier
---

Verificá los criterios de aceptación del spec `$ARGUMENTS` de punta a punta.

Si `$ARGUMENTS` viene vacío, listá los archivos disponibles en `specs/` y
preguntame cuál querés verificar antes de seguir.

Seguí tu flujo completo: verificá cada criterio, corregí lo que falle (en el spec
o en el código), validá las recomendaciones de Angular con Context7, compará las
pantallas con Playwright usando visión, y marcá los checks solo con evidencia.
Cerrá con el reporte en tabla y el estado final del spec.
