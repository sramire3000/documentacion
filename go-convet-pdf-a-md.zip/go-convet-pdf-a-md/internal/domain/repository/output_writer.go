package repository

import "github.com/hsr/go-convet-pdf-a-md/internal/domain/model"

// OutputWriter abstrae la escritura del Markdown y de las imágenes extraídas.
type OutputWriter interface {
	Write(outputPath string, content []byte, overwrite bool) error
	WriteAssets(dir string, assets []model.ImageAsset) error
}
