package repository

import "github.com/hsr/go-convet-pdf-a-md/internal/domain/model"

// DocumentReader abstrae la lectura de un PDF hacia el modelo de documento.
type DocumentReader interface {
	Read(inputPath string) (model.Document, error)
}
