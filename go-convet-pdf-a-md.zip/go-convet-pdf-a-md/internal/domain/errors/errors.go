package errors

import "errors"

var (
	// ErrInputNotFound indica que el archivo PDF de entrada no existe.
	ErrInputNotFound = errors.New("no se encontró el archivo PDF de entrada")
	// ErrUnsupportedFormat indica que el archivo de entrada no es un PDF legible.
	ErrUnsupportedFormat = errors.New("el archivo de entrada no es un PDF válido")
	// ErrEncryptedPDF indica que el PDF está protegido con contraseña.
	ErrEncryptedPDF = errors.New("el PDF está protegido con contraseña")
	// ErrNoTextContent indica que el PDF no expone una capa de texto extraíble.
	ErrNoTextContent = errors.New("el PDF no tiene texto extraíble")
	// ErrOutputExists indica que el archivo de salida existe y no se permite sobrescribirlo.
	ErrOutputExists = errors.New("el archivo de salida ya existe")
)
