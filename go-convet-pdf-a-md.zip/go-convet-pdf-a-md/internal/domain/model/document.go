package model

// Document es la representación intermedia, independiente del PDF y del Markdown.
type Document struct {
	Pages  []Page
	Assets []ImageAsset
}

// Page agrupa los bloques de contenido de una página del PDF.
type Page struct {
	Number int
	Blocks []Block
}

// Block es la suma cerrada de bloques que el renderer sabe escribir.
type Block interface{ isBlock() }

// Heading representa un título de nivel 1 a 3.
type Heading struct {
	Level   int // 1..3
	Content string
}

func (Heading) isBlock() {}

// Paragraph representa un párrafo de texto continuo.
type Paragraph struct {
	Content string
}

func (Paragraph) isBlock() {}

// ListItem representa un elemento de lista con su marcador original.
type ListItem struct {
	Marker  string // "•", "-", "*" o "N."
	Content string
}

func (ListItem) isBlock() {}

// Table representa una tabla con encabezado y filas.
type Table struct {
	Headers []string
	Rows    [][]string
}

func (Table) isBlock() {}

// Image representa una referencia a una imagen extraída.
type Image struct {
	FileName string // page-3-img-1.png, relativo a assets/
	AltText  string
}

func (Image) isBlock() {}

// ImageAsset es una imagen binaria extraída del PDF y pendiente de escritura.
type ImageAsset struct {
	Page     int
	Index    int
	Format   string // "png" | "jpg"
	Data     []byte
	FileName string
}
