package usecase

import (
	"errors"
	"path/filepath"
	"strings"
	"testing"

	"github.com/hsr/go-convet-pdf-a-md/internal/application/dto"
	domainerrors "github.com/hsr/go-convet-pdf-a-md/internal/domain/errors"
	"github.com/hsr/go-convet-pdf-a-md/internal/domain/model"
)

type stubReader struct {
	document model.Document
	err      error
	warnings []string
	path     string
}

func (s *stubReader) Read(inputPath string) (model.Document, error) {
	s.path = inputPath
	return s.document, s.err
}

func (s *stubReader) Warnings() []string {
	return s.warnings
}

type stubWriter struct {
	outputPath string
	content    []byte
	overwrite  bool
	assetsDir  string
	assets     []model.ImageAsset
	writeErr   error
	assetsErr  error
}

func (s *stubWriter) Write(outputPath string, content []byte, overwrite bool) error {
	s.outputPath = outputPath
	s.content = content
	s.overwrite = overwrite
	return s.writeErr
}

func (s *stubWriter) WriteAssets(dir string, assets []model.ImageAsset) error {
	s.assetsDir = dir
	s.assets = assets
	return s.assetsErr
}

func documentWithImage() model.Document {
	return model.Document{
		Pages: []model.Page{{
			Number: 1,
			Blocks: []model.Block{model.Image{FileName: "page-1-img-1.png", AltText: "Imagen"}},
		}},
		Assets: []model.ImageAsset{{Page: 1, Index: 1, Format: "png", FileName: "page-1-img-1.png"}},
	}
}

func TestExecuteUsesDefaultPaths(t *testing.T) {
	reader := &stubReader{document: documentWithImage()}
	writer := &stubWriter{}
	useCase := NewConvertPDFUseCase(reader, writer)

	result, err := useCase.Execute(dto.ConvertPDFRequest{InputPath: "/tmp/docs/reporte.pdf"})
	if err != nil {
		t.Fatalf("Execute devolvió error: %v", err)
	}
	if reader.path != "/tmp/docs/reporte.pdf" {
		t.Fatalf("ruta de entrada inesperada: %q", reader.path)
	}
	if result.OutputPath != "/tmp/docs/reporte.md" {
		t.Fatalf("salida por defecto inesperada: %q", result.OutputPath)
	}
	if writer.assetsDir != filepath.Join("/tmp/docs", "assets", "reporte") {
		t.Fatalf("directorio de assets por defecto inesperado: %q", writer.assetsDir)
	}
	if !strings.Contains(string(writer.content), "](assets/reporte/page-1-img-1.png)") {
		t.Fatalf("referencia de imagen inesperada:\n%s", writer.content)
	}
	if result.PagesConverted != 1 || result.ImagesExtracted != 1 {
		t.Fatalf("contadores inesperados: %+v", result)
	}
	if len(writer.assets) != 1 {
		t.Fatalf("no se delegaron los assets: %+v", writer.assets)
	}
}

func TestExecuteRespectsCustomAbsolutePaths(t *testing.T) {
	reader := &stubReader{document: documentWithImage()}
	writer := &stubWriter{}
	useCase := NewConvertPDFUseCase(reader, writer)

	result, err := useCase.Execute(dto.ConvertPDFRequest{
		InputPath:  "/tmp/reporte.pdf",
		OutputPath: "/tmp/salida/final.md",
		AssetsDir:  "/tmp/imagenes/final",
		Overwrite:  true,
	})
	if err != nil {
		t.Fatalf("Execute devolvió error: %v", err)
	}
	if result.OutputPath != "/tmp/salida/final.md" {
		t.Fatalf("salida inesperada: %q", result.OutputPath)
	}
	if writer.outputPath != "/tmp/salida/final.md" {
		t.Fatalf("el writer recibió otra ruta: %q", writer.outputPath)
	}
	if writer.assetsDir != "/tmp/imagenes/final" {
		t.Fatalf("el writer recibió otro assets dir: %q", writer.assetsDir)
	}
	if !writer.overwrite {
		t.Fatalf("no se propagó overwrite")
	}
	if !strings.Contains(string(writer.content), "](../imagenes/final/page-1-img-1.png)") {
		t.Fatalf("referencia de imagen inesperada:\n%s", writer.content)
	}
}

func TestExecutePropagatesReaderError(t *testing.T) {
	reader := &stubReader{err: domainerrors.ErrEncryptedPDF}
	writer := &stubWriter{}
	useCase := NewConvertPDFUseCase(reader, writer)

	_, err := useCase.Execute(dto.ConvertPDFRequest{InputPath: "/tmp/reporte.pdf"})
	if !errors.Is(err, domainerrors.ErrEncryptedPDF) {
		t.Fatalf("se esperaba ErrEncryptedPDF, se obtuvo %v", err)
	}
	if writer.outputPath != "" {
		t.Fatalf("no se debía escribir nada: %q", writer.outputPath)
	}
}

func TestExecutePropagatesWriterErrors(t *testing.T) {
	writeErr := errors.New("disco lleno")
	useCase := NewConvertPDFUseCase(&stubReader{document: documentWithImage()}, &stubWriter{writeErr: writeErr})
	if _, err := useCase.Execute(dto.ConvertPDFRequest{InputPath: "/tmp/reporte.pdf"}); !errors.Is(err, writeErr) {
		t.Fatalf("se esperaba el error de escritura, se obtuvo %v", err)
	}

	assetsErr := errors.New("sin permisos")
	useCase = NewConvertPDFUseCase(&stubReader{document: documentWithImage()}, &stubWriter{assetsErr: assetsErr})
	if _, err := useCase.Execute(dto.ConvertPDFRequest{InputPath: "/tmp/reporte.pdf"}); !errors.Is(err, assetsErr) {
		t.Fatalf("se esperaba el error de assets, se obtuvo %v", err)
	}
}

func TestExecuteIncludesReaderWarnings(t *testing.T) {
	reader := &stubReader{
		document: documentWithImage(),
		warnings: []string{"página 1: imagen Im1 omitida (formato JPX no soportado)"},
	}
	useCase := NewConvertPDFUseCase(reader, &stubWriter{})

	result, err := useCase.Execute(dto.ConvertPDFRequest{InputPath: "/tmp/reporte.pdf"})
	if err != nil {
		t.Fatalf("Execute devolvió error: %v", err)
	}
	if len(result.Warnings) != 1 || !strings.Contains(result.Warnings[0], "JPX") {
		t.Fatalf("avisos inesperados: %v", result.Warnings)
	}
}

func TestExecuteRequiresInputPath(t *testing.T) {
	useCase := NewConvertPDFUseCase(&stubReader{}, &stubWriter{})
	if _, err := useCase.Execute(dto.ConvertPDFRequest{}); !errors.Is(err, domainerrors.ErrInputNotFound) {
		t.Fatalf("se esperaba ErrInputNotFound, se obtuvo %v", err)
	}
}
