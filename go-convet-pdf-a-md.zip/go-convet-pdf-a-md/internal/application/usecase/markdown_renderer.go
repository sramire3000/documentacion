package usecase

import (
	"fmt"
	"strings"

	"github.com/hsr/go-convet-pdf-a-md/internal/domain/model"
)

const (
	maxHeadingLevel   = 3
	pageSeparator     = "---"
	blockSeparator    = "\n\n"
	tableColumnPrefix = "| "
	tableCellDivider  = " | "
	tableRowSuffix    = " |"
)

// renderMarkdown convierte el documento intermedio en Markdown GFM.
// assetsPrefix es la ruta relativa, desde el .md, hasta el directorio de imágenes.
func renderMarkdown(doc model.Document, assetsPrefix string) []byte {
	var b strings.Builder
	for pageIndex, page := range doc.Pages {
		if pageIndex > 0 {
			b.WriteString(pageSeparator + blockSeparator)
		}
		listOpen := false
		for _, block := range page.Blocks {
			_, isList := block.(model.ListItem)
			if !isList && listOpen {
				b.WriteString("\n")
				listOpen = false
			}
			writeBlock(&b, block, assetsPrefix)
			if isList {
				listOpen = true
			}
		}
	}
	return []byte(normalizeMarkdown(b.String()))
}

func writeBlock(b *strings.Builder, block model.Block, assetsPrefix string) {
	switch typed := block.(type) {
	case model.Heading:
		writeHeading(b, typed)
	case model.Paragraph:
		fmt.Fprintf(b, "%s%s", escapeMarkdownText(typed.Content), blockSeparator)
	case model.ListItem:
		writeListItem(b, typed)
	case model.Table:
		writeTable(b, typed)
	case model.Image:
		writeImage(b, typed, assetsPrefix)
	}
}

func writeHeading(b *strings.Builder, heading model.Heading) {
	level := heading.Level
	if level < 1 {
		level = 1
	}
	if level > maxHeadingLevel {
		level = maxHeadingLevel
	}
	fmt.Fprintf(b, "%s %s%s", strings.Repeat("#", level), escapeMarkdownText(heading.Content), blockSeparator)
}

func writeListItem(b *strings.Builder, item model.ListItem) {
	marker := item.Marker
	if marker == "" || marker == "•" || marker == "*" {
		marker = "-"
	}
	fmt.Fprintf(b, "%s %s\n", marker, escapeMarkdownText(item.Content))
}

func writeTable(b *strings.Builder, table model.Table) {
	if len(table.Headers) == 0 {
		return
	}
	writeTableRow(b, table.Headers)
	divider := make([]string, len(table.Headers))
	for i := range divider {
		divider[i] = "---"
	}
	writeTableRow(b, divider)
	for _, row := range table.Rows {
		writeTableRow(b, row)
	}
	b.WriteString("\n")
}

func writeTableRow(b *strings.Builder, cells []string) {
	b.WriteString(tableColumnPrefix)
	for i, cell := range cells {
		if i > 0 {
			b.WriteString(tableCellDivider)
		}
		b.WriteString(escapeTableCell(cell))
	}
	b.WriteString(tableRowSuffix + "\n")
}

func writeImage(b *strings.Builder, image model.Image, assetsPrefix string) {
	alt := escapeMarkdownText(image.AltText)
	fmt.Fprintf(b, "![%s](%s)%s", alt, assetPath(assetsPrefix, image.FileName), blockSeparator)
}

func assetPath(assetsPrefix, fileName string) string {
	prefix := strings.TrimSuffix(strings.ReplaceAll(assetsPrefix, "\\", "/"), "/")
	if prefix == "" || prefix == "." {
		return fileName
	}
	return prefix + "/" + fileName
}

var markdownEscaper = strings.NewReplacer(
	`\`, `\\`,
	"`", "\\`",
	"*", `\*`,
	"_", `\_`,
	"[", `\[`,
	"]", `\]`,
)

// escapeMarkdownText neutraliza los caracteres con significado en GFM.
func escapeMarkdownText(text string) string {
	escaped := markdownEscaper.Replace(strings.TrimSpace(text))
	if strings.HasPrefix(escaped, "#") {
		return `\` + escaped
	}
	return escaped
}

func escapeTableCell(text string) string {
	escaped := strings.ReplaceAll(text, `\`, `\\`)
	escaped = strings.ReplaceAll(escaped, "|", `\|`)
	escaped = strings.ReplaceAll(escaped, "\n", " ")
	return strings.TrimSpace(escaped)
}

// normalizeMarkdown quita líneas en blanco de más y asegura un único salto final.
func normalizeMarkdown(content string) string {
	lines := strings.Split(strings.ReplaceAll(content, "\r\n", "\n"), "\n")
	cleaned := make([]string, 0, len(lines))
	for _, line := range lines {
		line = strings.TrimRight(line, " \t")
		if line == "" && len(cleaned) > 0 && cleaned[len(cleaned)-1] == "" {
			continue
		}
		cleaned = append(cleaned, line)
	}
	for len(cleaned) > 0 && cleaned[len(cleaned)-1] == "" {
		cleaned = cleaned[:len(cleaned)-1]
	}
	if len(cleaned) == 0 {
		return ""
	}
	return strings.Join(cleaned, "\n") + "\n"
}
