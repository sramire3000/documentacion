package usecase

import (
	"fmt"
	"path/filepath"
	"strings"

	"github.com/hsr/go-convet-pdf-a-md/internal/application/dto"
	domainerrors "github.com/hsr/go-convet-pdf-a-md/internal/domain/errors"
	"github.com/hsr/go-convet-pdf-a-md/internal/domain/repository"
)

// warningProvider lo implementan los lectores que informan imágenes omitidas.
type warningProvider interface {
	Warnings() []string
}

// ConvertPDFUseCase orquesta lectura, render y escritura del documento.
type ConvertPDFUseCase struct {
	reader repository.DocumentReader
	writer repository.OutputWriter
}

// NewConvertPDFUseCase construye el caso de uso con sus puertos.
func NewConvertPDFUseCase(reader repository.DocumentReader, writer repository.OutputWriter) *ConvertPDFUseCase {
	return &ConvertPDFUseCase{reader: reader, writer: writer}
}

// Execute convierte el PDF indicado y devuelve las rutas y contadores resultantes.
func (u *ConvertPDFUseCase) Execute(request dto.ConvertPDFRequest) (dto.ConvertPDFResult, error) {
	var result dto.ConvertPDFResult
	if strings.TrimSpace(request.InputPath) == "" {
		return result, fmt.Errorf("%w: ruta vacía", domainerrors.ErrInputNotFound)
	}

	outputPath := request.OutputPath
	if outputPath == "" {
		outputPath = strings.TrimSuffix(request.InputPath, filepath.Ext(request.InputPath)) + ".md"
	}
	assetsDir := request.AssetsDir
	if assetsDir == "" {
		assetsDir = filepath.Join(filepath.Dir(outputPath), "assets", documentName(request.InputPath))
	}

	document, err := u.reader.Read(request.InputPath)
	if err != nil {
		return result, err
	}

	content := renderMarkdown(document, assetsPrefix(outputPath, assetsDir))
	if err := u.writer.Write(outputPath, content, request.Overwrite); err != nil {
		return result, err
	}
	if err := u.writer.WriteAssets(assetsDir, document.Assets); err != nil {
		return result, err
	}

	result = dto.ConvertPDFResult{
		OutputPath:      outputPath,
		PagesConverted:  len(document.Pages),
		ImagesExtracted: len(document.Assets),
	}
	if provider, ok := u.reader.(warningProvider); ok {
		result.Warnings = provider.Warnings()
	}
	return result, nil
}

// documentName devuelve el nombre del PDF sin extensión.
func documentName(inputPath string) string {
	base := filepath.Base(inputPath)
	return strings.TrimSuffix(base, filepath.Ext(base))
}

// assetsPrefix calcula la ruta relativa del .md al directorio de imágenes.
func assetsPrefix(outputPath, assetsDir string) string {
	relative, err := filepath.Rel(filepath.Dir(outputPath), assetsDir)
	if err != nil {
		return filepath.ToSlash(assetsDir)
	}
	return filepath.ToSlash(relative)
}
