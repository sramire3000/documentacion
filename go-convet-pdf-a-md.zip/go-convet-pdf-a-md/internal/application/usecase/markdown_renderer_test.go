package usecase

import (
	"strings"
	"testing"

	"github.com/hsr/go-convet-pdf-a-md/internal/domain/model"
)

func TestRenderMarkdownHeadings(t *testing.T) {
	document := model.Document{Pages: []model.Page{{
		Number: 1,
		Blocks: []model.Block{
			model.Heading{Level: 1, Content: "Título principal"},
			model.Heading{Level: 2, Content: "Sección"},
			model.Heading{Level: 3, Content: "Detalle"},
			model.Heading{Level: 9, Content: "Nivel acotado"},
		},
	}}}

	got := string(renderMarkdown(document, ""))
	want := "# Título principal\n\n## Sección\n\n### Detalle\n\n### Nivel acotado\n"
	if got != want {
		t.Fatalf("markdown inesperado:\n%s\nse esperaba:\n%s", got, want)
	}
}

func TestRenderMarkdownParagraphEscapesGFM(t *testing.T) {
	document := model.Document{Pages: []model.Page{{
		Number: 1,
		Blocks: []model.Block{model.Paragraph{Content: "texto *con* _marcas_ y [corchetes]"}},
	}}}

	got := string(renderMarkdown(document, ""))
	want := "texto \\*con\\* \\_marcas\\_ y \\[corchetes\\]\n"
	if got != want {
		t.Fatalf("escape inesperado: %q", got)
	}
}

func TestRenderMarkdownListItems(t *testing.T) {
	document := model.Document{Pages: []model.Page{{
		Number: 1,
		Blocks: []model.Block{
			model.ListItem{Marker: "•", Content: "primero"},
			model.ListItem{Marker: "-", Content: "segundo"},
			model.ListItem{Marker: "3.", Content: "tercero"},
			model.Paragraph{Content: "cierre"},
		},
	}}}

	got := string(renderMarkdown(document, ""))
	want := "- primero\n- segundo\n3. tercero\n\ncierre\n"
	if got != want {
		t.Fatalf("listas inesperadas:\n%q", got)
	}
}

func TestRenderMarkdownTable(t *testing.T) {
	document := model.Document{Pages: []model.Page{{
		Number: 1,
		Blocks: []model.Block{model.Table{
			Headers: []string{"Formato", "Soporte"},
			Rows:    [][]string{{"PDF", "Completo"}, {"PNG", "Completo"}},
		}},
	}}}

	got := string(renderMarkdown(document, ""))
	want := "| Formato | Soporte |\n| --- | --- |\n| PDF | Completo |\n| PNG | Completo |\n"
	if got != want {
		t.Fatalf("tabla inesperada:\n%s", got)
	}
}

func TestRenderMarkdownTableEscapesPipes(t *testing.T) {
	document := model.Document{Pages: []model.Page{{
		Number: 1,
		Blocks: []model.Block{model.Table{
			Headers: []string{"A | B"},
			Rows:    [][]string{{"c\nd"}},
		}},
	}}}

	got := string(renderMarkdown(document, ""))
	if !strings.Contains(got, `| A \| B |`) {
		t.Fatalf("no se escapó el pipe: %s", got)
	}
	if !strings.Contains(got, "| c d |") {
		t.Fatalf("no se normalizó el salto de línea: %s", got)
	}
}

func TestRenderMarkdownImages(t *testing.T) {
	document := model.Document{Pages: []model.Page{{
		Number: 2,
		Blocks: []model.Block{
			model.Image{FileName: "page-2-img-1.jpg", AltText: "Imagen 1"},
			model.Image{FileName: "page-2-img-2.png", AltText: "Imagen 2"},
		},
	}}}

	got := string(renderMarkdown(document, "assets/sample"))
	want := "![Imagen 1](assets/sample/page-2-img-1.jpg)\n\n![Imagen 2](assets/sample/page-2-img-2.png)\n"
	if got != want {
		t.Fatalf("imágenes inesperadas:\n%s", got)
	}
}

func TestRenderMarkdownPagesSeparated(t *testing.T) {
	document := model.Document{Pages: []model.Page{
		{Number: 1, Blocks: []model.Block{model.Paragraph{Content: "uno"}}},
		{Number: 2, Blocks: []model.Block{model.Paragraph{Content: "dos"}}},
	}}

	got := string(renderMarkdown(document, ""))
	want := "uno\n\n---\n\ndos\n"
	if got != want {
		t.Fatalf("separador inesperado: %q", got)
	}
	if strings.HasPrefix(got, "---") || strings.HasSuffix(got, "---\n") {
		t.Fatalf("el documento no debe empezar ni terminar con un separador: %q", got)
	}
	if count := strings.Count(got, "\n---\n"); count != 1 {
		t.Fatalf("se esperaba un único separador, se encontraron %d", count)
	}
}

func TestRenderMarkdownEmptyDocument(t *testing.T) {
	if got := string(renderMarkdown(model.Document{}, "")); got != "" {
		t.Fatalf("se esperaba salida vacía, se obtuvo %q", got)
	}
}

func TestAssetPath(t *testing.T) {
	cases := []struct {
		prefix string
		file   string
		want   string
	}{
		{"assets/sample", "page-1-img-1.png", "assets/sample/page-1-img-1.png"},
		{".", "page-1-img-1.png", "page-1-img-1.png"},
		{"../imagenes/x/", "page-2-img-1.jpg", "../imagenes/x/page-2-img-1.jpg"},
	}
	for _, testCase := range cases {
		if got := assetPath(testCase.prefix, testCase.file); got != testCase.want {
			t.Fatalf("assetPath(%q, %q) = %q, se esperaba %q", testCase.prefix, testCase.file, got, testCase.want)
		}
	}
}
