package dto

// ConvertPDFResult informa las rutas y contadores de una conversión exitosa.
type ConvertPDFResult struct {
	OutputPath      string
	PagesConverted  int
	ImagesExtracted int
	Warnings        []string
}
