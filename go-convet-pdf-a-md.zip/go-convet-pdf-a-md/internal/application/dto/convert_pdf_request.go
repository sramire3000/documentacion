package dto

// ConvertPDFRequest agrupa las rutas y opciones de una conversión.
type ConvertPDFRequest struct {
	InputPath  string
	OutputPath string // vacío ⇒ mismo nombre que el PDF con extensión .md
	AssetsDir  string // vacío ⇒ assets/<nombre-pdf>/ junto al .md
	Overwrite  bool
}
