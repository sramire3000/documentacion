package persistence

import (
	"math"
	"sort"
	"strings"

	"github.com/ledongthuc/pdf"

	"github.com/hsr/go-convet-pdf-a-md/internal/domain/model"
)

const (
	lineTolerance           = 1.0
	cellTolerance           = 1.5
	indentTolerance         = 2.0
	spaceGapFactor          = 0.2
	headingRatioOne         = 1.8
	headingRatioTwo         = 1.4
	headingRatioThree       = 1.1
	paragraphGapFactor      = 1.6
	minTableColumns         = 2
	minTableRows            = 2
	minRectanglesForWarning = 6
	minCellSize             = 1.0
)

// textAtom es un fragmento de texto ya normalizado a coordenadas con origen arriba-izquierda.
type textAtom struct {
	x        float64
	baseline float64
	size     float64
	text     string
}

// textLine agrupa los átomos que comparten línea base.
type textLine struct {
	left    float64
	top     float64
	size    float64
	content string
}

// cellRect es un rectángulo del PDF normalizado a origen arriba-izquierda.
type cellRect struct {
	left   float64
	right  float64
	top    float64
	bottom float64
}

type tableRow struct {
	top    float64
	bottom float64
	cells  []cellRect
}

type detectedTable struct {
	top     float64
	bottom  float64
	headers []string
	rows    [][]string
	cells   []cellRect
}

type placedBlock struct {
	top   float64
	block model.Block
}

// buildBlocks aplica las heurísticas de layout sobre los runs y rectángulos de una página.
// median es el tamaño de fuente mediano del documento completo.
func buildBlocks(runs []pdf.Text, rects []pdf.Rect, pageHeight, median float64) ([]model.Block, []string) {
	atoms := normalizeRuns(runs, pageHeight)
	cells := normalizeRects(rects, pageHeight)
	tables, warnings := detectTables(cells, atoms)

	used := make([]bool, len(atoms))
	entries := make([]placedBlock, 0, len(tables))
	for _, table := range tables {
		markAtomsInCells(atoms, used, table.cells)
		entries = append(entries, placedBlock{
			top:   table.top,
			block: model.Table{Headers: table.headers, Rows: table.rows},
		})
	}

	entries = append(entries, buildTextBlocks(groupLines(atoms, used), median)...)
	sort.SliceStable(entries, func(i, j int) bool { return entries[i].top < entries[j].top })

	blocks := make([]model.Block, len(entries))
	for i, entry := range entries {
		blocks[i] = entry.block
	}
	return blocks, warnings
}

// medianLineSize calcula la mediana de tamaños de fuente sobre todas las líneas del documento.
func medianLineSize(pages [][]textAtom) float64 {
	var sizes []float64
	for _, atoms := range pages {
		for _, line := range groupLines(atoms, nil) {
			sizes = append(sizes, line.size)
		}
	}
	if len(sizes) == 0 {
		return 0
	}
	sort.Float64s(sizes)
	middle := len(sizes) / 2
	if len(sizes)%2 == 0 {
		return (sizes[middle-1] + sizes[middle]) / 2
	}
	return sizes[middle]
}

func normalizeRuns(runs []pdf.Text, pageHeight float64) []textAtom {
	atoms := make([]textAtom, 0, len(runs))
	for _, run := range runs {
		if run.S == "" {
			continue
		}
		atoms = append(atoms, textAtom{
			x:        run.X,
			baseline: pageHeight - run.Y,
			size:     run.FontSize,
			text:     run.S,
		})
	}
	return atoms
}

func normalizeRects(rects []pdf.Rect, pageHeight float64) []cellRect {
	cells := make([]cellRect, 0, len(rects))
	for _, rect := range rects {
		cell := cellRect{
			left:   rect.Min.X,
			right:  rect.Max.X,
			top:    pageHeight - rect.Max.Y,
			bottom: pageHeight - rect.Min.Y,
		}
		if cell.right-cell.left < minCellSize || cell.bottom-cell.top < minCellSize {
			continue
		}
		cells = append(cells, cell)
	}
	return cells
}

// groupLines ordena los átomos por línea base y arma el texto de cada línea.
func groupLines(atoms []textAtom, used []bool) []textLine {
	indexes := make([]int, 0, len(atoms))
	for i := range atoms {
		if used == nil || !used[i] {
			indexes = append(indexes, i)
		}
	}
	sort.SliceStable(indexes, func(a, b int) bool {
		first, second := atoms[indexes[a]], atoms[indexes[b]]
		if first.baseline != second.baseline {
			return first.baseline < second.baseline
		}
		return first.x < second.x
	})

	var lines []textLine
	current := make([]textAtom, 0, 8)
	for _, index := range indexes {
		atom := atoms[index]
		if len(current) > 0 && atom.baseline-current[0].baseline > lineTolerance {
			lines = append(lines, buildLine(current))
			current = current[:0]
		}
		current = append(current, atom)
	}
	if len(current) > 0 {
		lines = append(lines, buildLine(current))
	}
	return lines
}

func buildLine(atoms []textAtom) textLine {
	line := textLine{left: atoms[0].x, top: atoms[0].baseline, size: atoms[0].size}
	var b strings.Builder
	previousX := atoms[0].x
	previousText := ""
	for i, atom := range atoms {
		if i > 0 {
			gap := atom.x - previousX
			threshold := math.Max(spaceGapFactor*atom.size, lineTolerance)
			if gap > threshold && !strings.HasSuffix(previousText, " ") && !strings.HasPrefix(atom.text, " ") {
				b.WriteString(" ")
			}
		}
		b.WriteString(atom.text)
		previousX = atom.x
		previousText = atom.text
		if atom.size > line.size {
			line.size = atom.size
		}
	}
	line.content = strings.TrimSpace(b.String())
	return line
}

// buildTextBlocks convierte las líneas libres en títulos, listas y párrafos.
func buildTextBlocks(lines []textLine, median float64) []placedBlock {
	entries := make([]placedBlock, 0, len(lines))
	var paragraph []textLine
	flush := func() {
		if len(paragraph) == 0 {
			return
		}
		entries = append(entries, placedBlock{
			top:   paragraph[0].top,
			block: model.Paragraph{Content: joinLines(paragraph)},
		})
		paragraph = nil
	}

	for _, line := range lines {
		if line.content == "" {
			continue
		}
		if level := headingLevel(line.size, median); level > 0 {
			flush()
			entries = append(entries, placedBlock{top: line.top, block: model.Heading{Level: level, Content: line.content}})
			continue
		}
		if marker, content, ok := parseListItem(line.content); ok {
			flush()
			entries = append(entries, placedBlock{top: line.top, block: model.ListItem{Marker: marker, Content: content}})
			continue
		}
		if len(paragraph) > 0 && !continuesParagraph(paragraph[len(paragraph)-1], line) {
			flush()
		}
		paragraph = append(paragraph, line)
	}
	flush()
	return entries
}

func joinLines(lines []textLine) string {
	parts := make([]string, 0, len(lines))
	for _, line := range lines {
		parts = append(parts, line.content)
	}
	return strings.Join(parts, " ")
}

func continuesParagraph(previous, current textLine) bool {
	gap := current.top - previous.top
	maxSize := math.Max(previous.size, current.size)
	if maxSize <= 0 || gap <= 0 {
		return false
	}
	return gap <= paragraphGapFactor*maxSize && math.Abs(current.left-previous.left) <= indentTolerance
}

func headingLevel(size, median float64) int {
	if median <= 0 {
		return 0
	}
	ratio := size / median
	switch {
	case ratio >= headingRatioOne:
		return 1
	case ratio >= headingRatioTwo:
		return 2
	case ratio >= headingRatioThree:
		return 3
	}
	return 0
}

// parseListItem reconoce viñetas y numeración al inicio de la línea.
func parseListItem(content string) (string, string, bool) {
	trimmed := strings.TrimLeft(content, " ")
	for _, marker := range []string{"•", "-", "*"} {
		if strings.HasPrefix(trimmed, marker+" ") {
			return marker, strings.TrimSpace(trimmed[len(marker)+1:]), true
		}
	}
	digits := 0
	for digits < len(trimmed) && trimmed[digits] >= '0' && trimmed[digits] <= '9' {
		digits++
	}
	if digits == 0 || digits+1 >= len(trimmed) {
		return "", "", false
	}
	if trimmed[digits] == '.' && trimmed[digits+1] == ' ' {
		return trimmed[:digits+1], strings.TrimSpace(trimmed[digits+2:]), true
	}
	return "", "", false
}

// detectTables agrupa rectángulos alineados en filas y columnas.
func detectTables(cells []cellRect, atoms []textAtom) ([]detectedTable, []string) {
	if len(cells) < minTableColumns*minTableRows {
		return nil, nil
	}
	rows := groupTableRows(cells)
	var builders []*tableBuilder
	for _, row := range rows {
		if len(row.cells) < minTableColumns {
			continue
		}
		if len(builders) > 0 {
			last := builders[len(builders)-1]
			if compatibleColumns(last.columns, row.cells) && math.Abs(row.top-last.bottom) <= cellTolerance {
				last.add(row)
				continue
			}
		}
		builders = append(builders, newTableBuilder(row))
	}

	tables := make([]detectedTable, 0, len(builders))
	for _, builder := range builders {
		table, ok := builder.build(atoms)
		if ok {
			tables = append(tables, table)
		}
	}
	if len(tables) == 0 && len(cells) >= minRectanglesForWarning {
		return nil, []string{"se detectaron rectángulos que no forman una tabla reconocible; el contenido se emite como texto"}
	}
	return tables, nil
}

func groupTableRows(cells []cellRect) []tableRow {
	sorted := make([]cellRect, len(cells))
	copy(sorted, cells)
	sort.SliceStable(sorted, func(i, j int) bool {
		if sorted[i].top != sorted[j].top {
			return sorted[i].top < sorted[j].top
		}
		return sorted[i].left < sorted[j].left
	})

	var rows []tableRow
	for _, cell := range sorted {
		if len(rows) > 0 && math.Abs(rows[len(rows)-1].top-cell.top) <= cellTolerance && math.Abs(rows[len(rows)-1].bottom-cell.bottom) <= cellTolerance {
			row := &rows[len(rows)-1]
			row.cells = append(row.cells, cell)
			row.bottom = math.Max(row.bottom, cell.bottom)
			continue
		}
		rows = append(rows, tableRow{top: cell.top, bottom: cell.bottom, cells: []cellRect{cell}})
	}
	for i := range rows {
		sort.SliceStable(rows[i].cells, func(a, b int) bool { return rows[i].cells[a].left < rows[i].cells[b].left })
	}
	return rows
}

type tableBuilder struct {
	rows    []tableRow
	columns []cellRect
	top     float64
	bottom  float64
}

func newTableBuilder(row tableRow) *tableBuilder {
	return &tableBuilder{rows: []tableRow{row}, columns: row.cells, top: row.top, bottom: row.bottom}
}

func (b *tableBuilder) add(row tableRow) {
	b.rows = append(b.rows, row)
	b.bottom = math.Max(b.bottom, row.bottom)
}

func (b *tableBuilder) build(atoms []textAtom) (detectedTable, bool) {
	if len(b.rows) < minTableRows {
		return detectedTable{}, false
	}
	table := detectedTable{top: b.top, bottom: b.bottom}
	table.headers = make([]string, 0, len(b.columns))
	for _, cell := range b.rows[0].cells {
		table.headers = append(table.headers, cellText(cell, atoms))
		table.cells = append(table.cells, cell)
	}
	for _, row := range b.rows[1:] {
		values := make([]string, 0, len(row.cells))
		for _, cell := range row.cells {
			values = append(values, cellText(cell, atoms))
			table.cells = append(table.cells, cell)
		}
		table.rows = append(table.rows, values)
	}
	return table, true
}

func compatibleColumns(columns, cells []cellRect) bool {
	if len(columns) != len(cells) {
		return false
	}
	for i := range columns {
		if math.Abs(columns[i].left-cells[i].left) > cellTolerance || math.Abs(columns[i].right-cells[i].right) > cellTolerance {
			return false
		}
	}
	return true
}

func markAtomsInCells(atoms []textAtom, used []bool, cells []cellRect) {
	for i, atom := range atoms {
		for _, cell := range cells {
			if atomInsideCell(atom, cell) {
				used[i] = true
				break
			}
		}
	}
}

func atomInsideCell(atom textAtom, cell cellRect) bool {
	return atom.baseline >= cell.top-cellTolerance && atom.baseline <= cell.bottom+cellTolerance &&
		atom.x >= cell.left-cellTolerance && atom.x <= cell.right+cellTolerance
}

func cellText(cell cellRect, atoms []textAtom) string {
	selected := make([]textAtom, 0, 8)
	for _, atom := range atoms {
		if atomInsideCell(atom, cell) {
			selected = append(selected, atom)
		}
	}
	if len(selected) == 0 {
		return ""
	}
	sort.SliceStable(selected, func(i, j int) bool {
		if selected[i].baseline != selected[j].baseline {
			return selected[i].baseline < selected[j].baseline
		}
		return selected[i].x < selected[j].x
	})
	return buildLine(selected).content
}
