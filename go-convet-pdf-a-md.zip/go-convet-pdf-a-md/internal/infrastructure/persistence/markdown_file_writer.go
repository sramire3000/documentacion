package persistence

import (
	"fmt"
	"os"
	"path/filepath"

	domainerrors "github.com/hsr/go-convet-pdf-a-md/internal/domain/errors"
	"github.com/hsr/go-convet-pdf-a-md/internal/domain/model"
)

const (
	filePermission      os.FileMode = 0o644
	directoryPermission os.FileMode = 0o755
)

// MarkdownFileWriter escribe el Markdown y las imágenes en disco.
type MarkdownFileWriter struct{}

// NewMarkdownFileWriter construye el escritor de salida.
func NewMarkdownFileWriter() *MarkdownFileWriter {
	return &MarkdownFileWriter{}
}

// Write escribe el .md y respeta la política de sobrescritura.
func (w *MarkdownFileWriter) Write(outputPath string, content []byte, overwrite bool) error {
	if _, err := os.Stat(outputPath); err == nil && !overwrite {
		return fmt.Errorf("%w: %s", domainerrors.ErrOutputExists, outputPath)
	}
	if dir := filepath.Dir(outputPath); dir != "" {
		if err := os.MkdirAll(dir, directoryPermission); err != nil {
			return fmt.Errorf("no se pudo crear el directorio %s: %w", dir, err)
		}
	}
	if err := os.WriteFile(outputPath, content, filePermission); err != nil {
		return fmt.Errorf("no se pudo escribir %s: %w", outputPath, err)
	}
	return nil
}

// WriteAssets escribe las imágenes; si no hay assets no crea el directorio.
func (w *MarkdownFileWriter) WriteAssets(dir string, assets []model.ImageAsset) error {
	if len(assets) == 0 {
		return nil
	}
	if err := os.MkdirAll(dir, directoryPermission); err != nil {
		return fmt.Errorf("no se pudo crear el directorio de imágenes %s: %w", dir, err)
	}
	for _, asset := range assets {
		target := filepath.Join(dir, asset.FileName)
		if err := os.WriteFile(target, asset.Data, filePermission); err != nil {
			return fmt.Errorf("no se pudo escribir la imagen %s: %w", target, err)
		}
	}
	return nil
}
