package persistence

import (
	"strings"
	"testing"

	"github.com/ledongthuc/pdf"

	"github.com/hsr/go-convet-pdf-a-md/internal/domain/model"
)

const testPageHeight = 800.0

// runsOf genera un run por carácter, igual que ledongthuc/pdf.
func runsOf(text string, x, baseline, size float64) []pdf.Text {
	runs := make([]pdf.Text, 0, len(text))
	for _, char := range text {
		runs = append(runs, pdf.Text{X: x, Y: testPageHeight - baseline, FontSize: size, S: string(char)})
	}
	return runs
}

// rectOf crea un rectángulo del PDF a partir de coordenadas con origen arriba-izquierda.
func rectOf(left, top, right, bottom float64) pdf.Rect {
	return pdf.Rect{
		Min: pdf.Point{X: left, Y: testPageHeight - bottom},
		Max: pdf.Point{X: right, Y: testPageHeight - top},
	}
}

func appendRuns(destination []pdf.Text, chunks ...[]pdf.Text) []pdf.Text {
	for _, chunk := range chunks {
		destination = append(destination, chunk...)
	}
	return destination
}

func TestGroupLinesByBaseline(t *testing.T) {
	runs := appendRuns(nil,
		runsOf("Hola", 72, 100, 10),
		runsOf("mundo", 140, 100, 10),
		runsOf("segunda línea", 72, 113, 10),
	)

	lines := groupLines(normalizeRuns(runs, testPageHeight), nil)
	if len(lines) != 2 {
		t.Fatalf("se esperaban 2 líneas, se obtuvieron %d: %+v", len(lines), lines)
	}
	if lines[0].content != "Hola mundo" {
		t.Fatalf("línea 1 inesperada: %q", lines[0].content)
	}
	if lines[1].content != "segunda línea" {
		t.Fatalf("línea 2 inesperada: %q", lines[1].content)
	}
}

func TestBuildBlocksHeadingLevels(t *testing.T) {
	runs := appendRuns(nil,
		runsOf("Título", 72, 100, 24),
		runsOf("Cuerpo del documento.", 72, 200, 10),
		runsOf("Sección", 72, 260, 16),
		runsOf("Subsección", 72, 300, 13),
	)

	blocks, warnings := buildBlocks(runs, nil, testPageHeight, 10)
	if len(warnings) != 0 {
		t.Fatalf("no se esperaban avisos: %v", warnings)
	}
	headings := map[int]string{}
	for _, block := range blocks {
		if heading, ok := block.(model.Heading); ok {
			headings[heading.Level] = heading.Content
		}
	}
	if headings[1] != "Título" || headings[2] != "Sección" || headings[3] != "Subsección" {
		t.Fatalf("niveles inesperados: %v", headings)
	}
}

func TestHeadingLevelUsesMedian(t *testing.T) {
	cases := []struct {
		size   float64
		median float64
		want   int
	}{
		{24, 10, 1},
		{16, 10, 2},
		{13, 10, 3},
		{10, 10, 0},
		{9, 10, 0},
		{12, 0, 0},
	}
	for _, testCase := range cases {
		if got := headingLevel(testCase.size, testCase.median); got != testCase.want {
			t.Fatalf("headingLevel(%v, %v) = %d, se esperaba %d", testCase.size, testCase.median, got, testCase.want)
		}
	}
}

func TestMedianLineSize(t *testing.T) {
	pages := [][]textAtom{
		normalizeRuns(appendRuns(nil,
			runsOf("uno", 72, 100, 10),
			runsOf("dos", 72, 200, 10),
			runsOf("tres", 72, 300, 24),
		), testPageHeight),
		normalizeRuns(appendRuns(nil,
			runsOf("cuatro", 72, 100, 10),
		), testPageHeight),
	}
	if got := medianLineSize(pages); got != 10 {
		t.Fatalf("mediana inesperada: %v", got)
	}
	if got := medianLineSize(nil); got != 0 {
		t.Fatalf("mediana de documento vacío inesperada: %v", got)
	}
}

func TestParseListItem(t *testing.T) {
	cases := []struct {
		line   string
		marker string
		text   string
		ok     bool
	}{
		{"• viñeta", "•", "viñeta", true},
		{"- guion", "-", "guion", true},
		{"* asterisco", "*", "asterisco", true},
		{"12. numerada", "12.", "numerada", true},
		{"Sin marcador", "", "", false},
		{"12.sin espacio", "", "", false},
		{"", "", "", false},
	}
	for _, testCase := range cases {
		marker, text, ok := parseListItem(testCase.line)
		if ok != testCase.ok || marker != testCase.marker || text != testCase.text {
			t.Fatalf("parseListItem(%q) = (%q, %q, %v)", testCase.line, marker, text, ok)
		}
	}
}

func TestBuildBlocksListItems(t *testing.T) {
	runs := appendRuns(nil,
		runsOf("• primero", 72, 100, 10),
		runsOf("- segundo", 72, 113, 10),
		runsOf("3. tercero", 72, 126, 10),
	)

	blocks, _ := buildBlocks(runs, nil, testPageHeight, 10)
	if len(blocks) != 3 {
		t.Fatalf("se esperaban 3 bloques, se obtuvieron %d: %+v", len(blocks), blocks)
	}
	first, ok := blocks[0].(model.ListItem)
	if !ok || first.Marker != "•" || first.Content != "primero" {
		t.Fatalf("primer elemento inesperado: %+v", blocks[0])
	}
	if third, ok := blocks[2].(model.ListItem); !ok || third.Marker != "3." {
		t.Fatalf("tercer elemento inesperado: %+v", blocks[2])
	}
}

func TestBuildBlocksMergesParagraphLines(t *testing.T) {
	runs := appendRuns(nil,
		runsOf("La primera línea termina", 72, 100, 10),
		runsOf("y continúa en la siguiente.", 72, 113, 10),
		runsOf("Otro párrafo separado.", 72, 160, 10),
	)

	blocks, _ := buildBlocks(runs, nil, testPageHeight, 10)
	if len(blocks) != 2 {
		t.Fatalf("se esperaban 2 párrafos, se obtuvieron %d: %+v", len(blocks), blocks)
	}
	paragraph, ok := blocks[0].(model.Paragraph)
	if !ok {
		t.Fatalf("el primer bloque no es un párrafo: %T", blocks[0])
	}
	if paragraph.Content != "La primera línea termina y continúa en la siguiente." {
		t.Fatalf("párrafo inesperado: %q", paragraph.Content)
	}
}

func TestBuildBlocksDetectsBorderedTable(t *testing.T) {
	rects := []pdf.Rect{
		rectOf(10, 100, 110, 120),
		rectOf(110, 100, 210, 120),
		rectOf(10, 120, 110, 140),
		rectOf(110, 120, 210, 140),
	}
	runs := appendRuns(nil,
		runsOf("Texto libre antes de la tabla.", 10, 60, 10),
		runsOf("A", 15, 112, 9),
		runsOf("B", 115, 112, 9),
		runsOf("C", 15, 132, 9),
		runsOf("D", 115, 132, 9),
	)

	blocks, warnings := buildBlocks(runs, rects, testPageHeight, 10)
	if len(warnings) != 0 {
		t.Fatalf("no se esperaban avisos: %v", warnings)
	}
	var table model.Table
	found := false
	for _, block := range blocks {
		if candidate, ok := block.(model.Table); ok {
			table = candidate
			found = true
		}
		if paragraph, ok := block.(model.Paragraph); ok && strings.Contains(paragraph.Content, "A") {
			t.Fatalf("el texto de la tabla quedó en un párrafo: %q", paragraph.Content)
		}
	}
	if !found {
		t.Fatalf("no se detectó la tabla: %+v", blocks)
	}
	if len(table.Headers) != 2 || table.Headers[0] != "A" || table.Headers[1] != "B" {
		t.Fatalf("encabezados inesperados: %v", table.Headers)
	}
	if len(table.Rows) != 1 || table.Rows[0][0] != "C" || table.Rows[0][1] != "D" {
		t.Fatalf("filas inesperadas: %v", table.Rows)
	}
}

func TestBuildBlocksFallsBackWhenRectanglesAreNotATable(t *testing.T) {
	rects := []pdf.Rect{
		rectOf(10, 100, 40, 110),
		rectOf(60, 105, 100, 120),
		rectOf(10, 140, 50, 155),
		rectOf(120, 130, 160, 145),
		rectOf(200, 300, 240, 320),
		rectOf(260, 305, 300, 325),
	}
	runs := appendRuns(nil,
		runsOf("Texto dentro del primer rectángulo.", 12, 108, 10),
		runsOf("Texto libre.", 10, 60, 10),
	)

	blocks, warnings := buildBlocks(runs, rects, testPageHeight, 10)
	if len(warnings) != 1 {
		t.Fatalf("se esperaba un aviso de tabla no reconocida: %v", warnings)
	}
	for _, block := range blocks {
		if _, ok := block.(model.Table); ok {
			t.Fatalf("no debía detectarse una tabla: %+v", blocks)
		}
	}
	joined := ""
	for _, block := range blocks {
		if paragraph, ok := block.(model.Paragraph); ok {
			joined += paragraph.Content
		}
	}
	if !strings.Contains(joined, "Texto dentro del primer rectángulo.") || !strings.Contains(joined, "Texto libre.") {
		t.Fatalf("el fallback perdió texto: %+v", blocks)
	}
}

func TestBuildBlocksOrdersTableBetweenParagraphs(t *testing.T) {
	rects := []pdf.Rect{
		rectOf(10, 100, 110, 120),
		rectOf(110, 100, 210, 120),
		rectOf(10, 120, 110, 140),
		rectOf(110, 120, 210, 140),
	}
	runs := appendRuns(nil,
		runsOf("Antes.", 10, 60, 10),
		runsOf("A", 15, 112, 9),
		runsOf("B", 115, 112, 9),
		runsOf("C", 15, 132, 9),
		runsOf("D", 115, 132, 9),
		runsOf("Después.", 10, 200, 10),
	)

	blocks, _ := buildBlocks(runs, rects, testPageHeight, 10)
	if len(blocks) != 3 {
		t.Fatalf("se esperaban 3 bloques, se obtuvieron %d: %+v", len(blocks), blocks)
	}
	if _, ok := blocks[0].(model.Paragraph); !ok {
		t.Fatalf("el primer bloque debería ser un párrafo: %T", blocks[0])
	}
	if _, ok := blocks[1].(model.Table); !ok {
		t.Fatalf("el segundo bloque debería ser la tabla: %T", blocks[1])
	}
	if _, ok := blocks[2].(model.Paragraph); !ok {
		t.Fatalf("el tercer bloque debería ser un párrafo: %T", blocks[2])
	}
}
