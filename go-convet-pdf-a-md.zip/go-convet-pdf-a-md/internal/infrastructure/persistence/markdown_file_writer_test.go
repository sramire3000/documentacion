package persistence

import (
	"errors"
	"os"
	"path/filepath"
	"testing"

	domainerrors "github.com/hsr/go-convet-pdf-a-md/internal/domain/errors"
	"github.com/hsr/go-convet-pdf-a-md/internal/domain/model"
)

func TestMarkdownFileWriterWritesNewFile(t *testing.T) {
	writer := NewMarkdownFileWriter()
	outputPath := filepath.Join(t.TempDir(), "salida.md")

	if err := writer.Write(outputPath, []byte("# Hola\n"), false); err != nil {
		t.Fatalf("Write devolvió error: %v", err)
	}
	content, err := os.ReadFile(outputPath)
	if err != nil {
		t.Fatalf("no se pudo leer la salida: %v", err)
	}
	if string(content) != "# Hola\n" {
		t.Fatalf("contenido inesperado: %q", content)
	}
}

func TestMarkdownFileWriterCreatesMissingDirectories(t *testing.T) {
	writer := NewMarkdownFileWriter()
	outputPath := filepath.Join(t.TempDir(), "nested", "salida.md")

	if err := writer.Write(outputPath, []byte("x"), false); err != nil {
		t.Fatalf("Write devolvió error: %v", err)
	}
	if _, err := os.Stat(outputPath); err != nil {
		t.Fatalf("no se creó el archivo: %v", err)
	}
}

func TestMarkdownFileWriterRefusesOverwrite(t *testing.T) {
	writer := NewMarkdownFileWriter()
	outputPath := filepath.Join(t.TempDir(), "salida.md")
	if err := os.WriteFile(outputPath, []byte("original"), 0o644); err != nil {
		t.Fatalf("no se pudo preparar el archivo: %v", err)
	}

	err := writer.Write(outputPath, []byte("nuevo"), false)
	if !errors.Is(err, domainerrors.ErrOutputExists) {
		t.Fatalf("se esperaba ErrOutputExists, se obtuvo %v", err)
	}
	content, readErr := os.ReadFile(outputPath)
	if readErr != nil {
		t.Fatalf("no se pudo leer el archivo: %v", readErr)
	}
	if string(content) != "original" {
		t.Fatalf("el archivo original se modificó: %q", content)
	}
}

func TestMarkdownFileWriterOverwritesWhenAllowed(t *testing.T) {
	writer := NewMarkdownFileWriter()
	outputPath := filepath.Join(t.TempDir(), "salida.md")
	if err := os.WriteFile(outputPath, []byte("original"), 0o644); err != nil {
		t.Fatalf("no se pudo preparar el archivo: %v", err)
	}

	if err := writer.Write(outputPath, []byte("nuevo"), true); err != nil {
		t.Fatalf("Write devolvió error: %v", err)
	}
	content, err := os.ReadFile(outputPath)
	if err != nil {
		t.Fatalf("no se pudo leer el archivo: %v", err)
	}
	if string(content) != "nuevo" {
		t.Fatalf("no se sobrescribió el archivo: %q", content)
	}
}

func TestMarkdownFileWriterSkipsAssetsDirectoryWhenEmpty(t *testing.T) {
	writer := NewMarkdownFileWriter()
	assetsDir := filepath.Join(t.TempDir(), "assets")

	if err := writer.WriteAssets(assetsDir, nil); err != nil {
		t.Fatalf("WriteAssets devolvió error: %v", err)
	}
	if _, err := os.Stat(assetsDir); !os.IsNotExist(err) {
		t.Fatalf("no se debía crear el directorio de assets")
	}
}

func TestMarkdownFileWriterWritesAssets(t *testing.T) {
	writer := NewMarkdownFileWriter()
	assetsDir := filepath.Join(t.TempDir(), "assets", "sample")
	assets := []model.ImageAsset{
		{Page: 1, Index: 1, Format: "jpg", Data: []byte("jpg-data"), FileName: "page-1-img-1.jpg"},
		{Page: 1, Index: 2, Format: "png", Data: []byte("png-data"), FileName: "page-1-img-2.png"},
	}

	if err := writer.WriteAssets(assetsDir, assets); err != nil {
		t.Fatalf("WriteAssets devolvió error: %v", err)
	}
	for _, asset := range assets {
		content, err := os.ReadFile(filepath.Join(assetsDir, asset.FileName))
		if err != nil {
			t.Fatalf("no se escribió %s: %v", asset.FileName, err)
		}
		if string(content) != string(asset.Data) {
			t.Fatalf("contenido inesperado en %s: %q", asset.FileName, content)
		}
	}
}
