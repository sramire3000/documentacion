package persistence

import (
	"context"
	"errors"
	"fmt"
	"io"
	"os"
	"path/filepath"
	"sort"
	"strings"

	"github.com/ledongthuc/pdf"
	pdfapi "github.com/pdfcpu/pdfcpu/pkg/api"
	"github.com/pdfcpu/pdfcpu/pkg/pdfcpu"
	pdfmodel "github.com/pdfcpu/pdfcpu/pkg/pdfcpu/model"

	domainerrors "github.com/hsr/go-convet-pdf-a-md/internal/domain/errors"
	"github.com/hsr/go-convet-pdf-a-md/internal/domain/model"
)

// supportedImageFilters mapea el último filtro del stream a la extensión escrita.
var supportedImageFilters = map[string]string{
	"DCTDecode":       "jpg",
	"FlateDecode":     "png",
	"LZWDecode":       "png",
	"RunLengthDecode": "png",
}

// unsupportedImageFilters nombra los formatos que este spec decide omitir.
var unsupportedImageFilters = map[string]string{
	"JPXDecode":      "JPX",
	"JBIG2Decode":    "JBIG2",
	"CCITTFaxDecode": "CCITT",
}

const defaultPageHeight = 842.0 // A4 en puntos, usado si MediaBox no es legible.

// PDFDocumentReader implementa repository.DocumentReader sobre ledongthuc/pdf y pdfcpu.
type PDFDocumentReader struct {
	warnings []string
}

// NewPDFDocumentReader construye el lector de PDF.
func NewPDFDocumentReader() *PDFDocumentReader {
	return &PDFDocumentReader{}
}

// Warnings devuelve los avisos acumulados en la última lectura.
func (r *PDFDocumentReader) Warnings() []string {
	return append([]string(nil), r.warnings...)
}

type pageContent struct {
	runs   []pdf.Text
	rects  []pdf.Rect
	height float64
}

type extractedImage struct {
	format string
	data   []byte
	name   string
}

// Read abre el PDF, valida cifrado y capa de texto, y arma el documento intermedio.
func (r *PDFDocumentReader) Read(inputPath string) (model.Document, error) {
	r.warnings = nil
	if inputPath == "" {
		return model.Document{}, fmt.Errorf("%w: ruta vacía", domainerrors.ErrInputNotFound)
	}
	info, err := os.Stat(inputPath)
	if err != nil || info.IsDir() {
		return model.Document{}, fmt.Errorf("%w: %s", domainerrors.ErrInputNotFound, inputPath)
	}
	if !strings.EqualFold(filepath.Ext(inputPath), ".pdf") {
		return model.Document{}, fmt.Errorf("%w: %s", domainerrors.ErrUnsupportedFormat, inputPath)
	}

	imagesByPage, err := r.extractImages(inputPath)
	if err != nil {
		return model.Document{}, err
	}
	contents, err := readPageContents(inputPath)
	if err != nil {
		return model.Document{}, err
	}
	if !hasText(contents) {
		return model.Document{}, fmt.Errorf("%w: %s", domainerrors.ErrNoTextContent, inputPath)
	}

	atomsPerPage := make([][]textAtom, len(contents))
	for i, content := range contents {
		atomsPerPage[i] = normalizeRuns(content.runs, content.height)
	}
	median := medianLineSize(atomsPerPage)

	document := model.Document{Pages: make([]model.Page, 0, len(contents))}
	for i, content := range contents {
		blocks, warnings := buildBlocks(content.runs, content.rects, content.height, median)
		r.warnings = append(r.warnings, warnings...)
		pageNumber := i + 1
		blocks = append(blocks, imageBlocks(pageNumber, imagesByPage[pageNumber], &document)...)
		document.Pages = append(document.Pages, model.Page{Number: pageNumber, Blocks: blocks})
	}
	return document, nil
}

// imageBlocks crea los bloques de imagen y registra los assets de la página.
func imageBlocks(pageNumber int, images []extractedImage, document *model.Document) []model.Block {
	blocks := make([]model.Block, 0, len(images))
	for i, image := range images {
		fileName := fmt.Sprintf("page-%d-img-%d.%s", pageNumber, i+1, image.format)
		document.Assets = append(document.Assets, model.ImageAsset{
			Page:     pageNumber,
			Index:    i + 1,
			Format:   image.format,
			Data:     image.data,
			FileName: fileName,
		})
		blocks = append(blocks, model.Image{
			FileName: fileName,
			AltText:  fmt.Sprintf("Imagen extraída de la página %d", pageNumber),
		})
	}
	return blocks
}

func hasText(contents []pageContent) bool {
	for _, content := range contents {
		for _, run := range content.runs {
			if strings.TrimSpace(run.S) != "" {
				return true
			}
		}
	}
	return false
}

// readPageContents interpreta el texto y los rectángulos de cada página.
func readPageContents(inputPath string) ([]pageContent, error) {
	file, reader, err := pdf.Open(inputPath)
	if err != nil {
		return nil, fmt.Errorf("%w: %s", domainerrors.ErrUnsupportedFormat, inputPath)
	}
	defer file.Close()

	contents := make([]pageContent, 0, reader.NumPage())
	for pageNumber := 1; pageNumber <= reader.NumPage(); pageNumber++ {
		page := reader.Page(pageNumber)
		content, err := safeContent(page)
		if err != nil {
			return nil, fmt.Errorf("no se pudo interpretar la página %d: %w", pageNumber, err)
		}
		contents = append(contents, pageContent{
			runs:   content.Text,
			rects:  content.Rect,
			height: pageHeight(page),
		})
	}
	return contents, nil
}

// safeContent convierte un panic del parser en error de negocio con la página.
func safeContent(page pdf.Page) (content pdf.Content, err error) {
	defer func() {
		if recovered := recover(); recovered != nil {
			err = fmt.Errorf("%w: %v", domainerrors.ErrUnsupportedFormat, recovered)
		}
	}()
	return page.Content(), nil
}

func pageHeight(page pdf.Page) float64 {
	var box pdf.Value
	for value := page.V; !value.IsNull(); value = value.Key("Parent") {
		if candidate := value.Key("MediaBox"); !candidate.IsNull() {
			box = candidate
			break
		}
	}
	if box.Len() >= 4 {
		if height := box.Index(3).Float64(); height > 0 {
			return height
		}
	}
	return defaultPageHeight
}

// extractImages extrae solo JPEG y PNG; el resto se omite con aviso.
func (r *PDFDocumentReader) extractImages(inputPath string) (map[int][]extractedImage, error) {
	file, err := os.Open(inputPath)
	if err != nil {
		return nil, fmt.Errorf("%w: %s", domainerrors.ErrUnsupportedFormat, inputPath)
	}
	defer file.Close()

	conf := pdfmodel.NewDefaultConfiguration()
	conf.Cmd = pdfmodel.EXTRACTIMAGES
	ctx, err := pdfapi.ReadValidateAndOptimize(context.Background(), file, conf, nil)
	if err != nil {
		if errors.Is(err, pdfcpu.ErrEncrypted) || errors.Is(err, pdfcpu.ErrWrongPassword) {
			return nil, fmt.Errorf("%w: %s", domainerrors.ErrEncryptedPDF, inputPath)
		}
		return nil, fmt.Errorf("%w: %s", domainerrors.ErrUnsupportedFormat, inputPath)
	}

	images := make(map[int][]extractedImage, ctx.PageCount)
	for pageNumber := 1; pageNumber <= ctx.PageCount; pageNumber++ {
		pageImages, err := r.extractPageImages(ctx, pageNumber)
		if err != nil {
			return nil, err
		}
		if len(pageImages) > 0 {
			images[pageNumber] = pageImages
		}
	}
	return images, nil
}

func (r *PDFDocumentReader) extractPageImages(ctx *pdfmodel.Context, pageNumber int) ([]extractedImage, error) {
	stubs, err := pdfcpu.ExtractPageImages(context.Background(), ctx, pageNumber, true)
	if err != nil && !errors.Is(err, pdfcpu.ErrUnsupportedResource) {
		return nil, fmt.Errorf("página %d: no se pudieron inspeccionar las imágenes: %w", pageNumber, err)
	}

	objectNumbers := make([]int, 0, len(stubs))
	for objectNumber := range stubs {
		objectNumbers = append(objectNumbers, objectNumber)
	}
	sort.Ints(objectNumbers)

	images := make([]extractedImage, 0, len(objectNumbers))
	for _, objectNumber := range objectNumbers {
		stub := stubs[objectNumber]
		filter := lastFilter(stub.Filter)
		if label, ok := unsupportedImageFilters[filter]; ok {
			r.warnings = append(r.warnings, unsupportedImageWarning(pageNumber, stub.Name, label))
			continue
		}
		expectedFormat, ok := supportedImageFilters[filter]
		if !ok {
			r.warnings = append(r.warnings, unsupportedImageWarning(pageNumber, stub.Name, filterLabel(filter)))
			continue
		}

		imageObject := ctx.Optimize.ImageObjects[objectNumber]
		if imageObject == nil {
			continue
		}
		image, err := pdfcpu.ExtractImage(context.Background(), ctx, imageObject.ImageDict, false, stub.Name, objectNumber, false)
		if err != nil {
			return nil, fmt.Errorf("página %d: no se pudo extraer la imagen %s: %w", pageNumber, stub.Name, err)
		}
		if image == nil || image.Reader == nil {
			continue
		}
		data, err := io.ReadAll(image.Reader)
		if err != nil {
			return nil, fmt.Errorf("página %d: no se pudo leer la imagen %s: %w", pageNumber, stub.Name, err)
		}
		format := image.FileType
		if format == "" {
			format = expectedFormat
		}
		images = append(images, extractedImage{format: format, data: data, name: stub.Name})
	}
	return images, nil
}

func lastFilter(filters string) string {
	if filters == "" {
		return ""
	}
	parts := strings.Split(filters, ",")
	return strings.TrimSpace(parts[len(parts)-1])
}

// unsupportedImageWarning arma el aviso para formatos de imagen fuera de alcance.
func unsupportedImageWarning(page int, name, format string) string {
	return fmt.Sprintf("página %d: imagen %s omitida (formato %s no soportado)", page, name, format)
}

func filterLabel(filter string) string {
	if filter == "" {
		return "desconocido"
	}
	return strings.TrimSuffix(filter, "Decode")
}
