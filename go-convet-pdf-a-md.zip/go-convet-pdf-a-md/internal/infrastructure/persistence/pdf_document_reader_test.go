package persistence

import (
	"bytes"
	"context"
	"errors"
	"fmt"
	"os"
	"path/filepath"
	"strings"
	"testing"

	pdfapi "github.com/pdfcpu/pdfcpu/pkg/api"
	pdfmodel "github.com/pdfcpu/pdfcpu/pkg/pdfcpu/model"

	domainerrors "github.com/hsr/go-convet-pdf-a-md/internal/domain/errors"
	"github.com/hsr/go-convet-pdf-a-md/internal/domain/model"
)

const samplePDFPath = "testdata/sample.pdf"

func TestReadSamplePDF(t *testing.T) {
	reader := NewPDFDocumentReader()
	document, err := reader.Read(samplePDFPath)
	if err != nil {
		t.Fatalf("Read devolvió error: %v", err)
	}
	if len(document.Pages) != 2 {
		t.Fatalf("se esperaban 2 páginas, se obtuvieron %d", len(document.Pages))
	}
	if len(reader.Warnings()) != 0 {
		t.Fatalf("el fixture no debería generar avisos: %v", reader.Warnings())
	}

	firstPage := document.Pages[0]
	if len(firstPage.Blocks) == 0 {
		t.Fatalf("la primera página no tiene bloques")
	}
	title, ok := firstPage.Blocks[0].(model.Heading)
	if !ok || title.Level != 1 || title.Content != "Convertidor de PDF a Markdown" {
		t.Fatalf("título inesperado: %+v", firstPage.Blocks[0])
	}

	var section model.Heading
	var table model.Table
	for _, block := range firstPage.Blocks {
		switch typed := block.(type) {
		case model.Heading:
			if typed.Level == 2 {
				section = typed
			}
		case model.Table:
			table = typed
		}
	}
	if section.Content != "Alcance del proyecto" {
		t.Fatalf("no se detectó el título de nivel 2: %+v", firstPage.Blocks)
	}
	if len(table.Headers) != 3 || table.Headers[0] != "Formato" || table.Headers[1] != "Soporte" || table.Headers[2] != "Notas" {
		t.Fatalf("encabezados de tabla inesperados: %v", table.Headers)
	}
	if len(table.Rows) != 2 || table.Rows[0][0] != "PDF" || table.Rows[1][0] != "JPEG" {
		t.Fatalf("filas de tabla inesperadas: %v", table.Rows)
	}

	secondPage := document.Pages[1]
	var heading model.Heading
	listItems := 0
	images := 0
	for _, block := range secondPage.Blocks {
		switch typed := block.(type) {
		case model.Heading:
			heading = typed
		case model.ListItem:
			listItems++
		case model.Image:
			images++
		}
	}
	if heading.Level != 3 || heading.Content != "Lista de tareas" {
		t.Fatalf("no se detectó el título de nivel 3: %+v", secondPage.Blocks)
	}
	if listItems != 3 {
		t.Fatalf("se esperaban 3 elementos de lista, se obtuvieron %d", listItems)
	}
	if images != 2 {
		t.Fatalf("se esperaban 2 imágenes, se obtuvieron %d", images)
	}
	if len(document.Assets) != 2 {
		t.Fatalf("se esperaban 2 assets, se obtuvieron %d", len(document.Assets))
	}
	if document.Assets[0].Format != "jpg" || document.Assets[0].FileName != "page-2-img-1.jpg" {
		t.Fatalf("asset 1 inesperado: %+v", document.Assets[0])
	}
	if document.Assets[1].Format != "png" || document.Assets[1].FileName != "page-2-img-2.png" {
		t.Fatalf("asset 2 inesperado: %+v", document.Assets[1])
	}
}

func TestReadMissingFile(t *testing.T) {
	reader := NewPDFDocumentReader()
	missing := filepath.Join(t.TempDir(), "no-existe.pdf")
	_, err := reader.Read(missing)
	if !errors.Is(err, domainerrors.ErrInputNotFound) {
		t.Fatalf("se esperaba ErrInputNotFound, se obtuvo %v", err)
	}
	if !strings.Contains(err.Error(), missing) {
		t.Fatalf("el error debe nombrar la ruta recibida: %v", err)
	}
}

func TestReadUnsupportedExtension(t *testing.T) {
	path := filepath.Join(t.TempDir(), "documento.txt")
	if err := os.WriteFile(path, []byte("no es un pdf"), 0o644); err != nil {
		t.Fatalf("no se pudo preparar el archivo: %v", err)
	}
	_, err := NewPDFDocumentReader().Read(path)
	if !errors.Is(err, domainerrors.ErrUnsupportedFormat) {
		t.Fatalf("se esperaba ErrUnsupportedFormat, se obtuvo %v", err)
	}
}

func TestReadEncryptedPDF(t *testing.T) {
	target := filepath.Join(t.TempDir(), "encrypted.pdf")
	conf := pdfmodel.NewDefaultConfiguration()
	conf.Cmd = pdfmodel.ENCRYPT
	conf.UserPW = "user"
	conf.OwnerPW = "owner"
	conf.EncryptUsingAES = true
	conf.EncryptKeyLength = 128
	if err := pdfapi.EncryptFile(context.Background(), samplePDFPath, target, conf); err != nil {
		t.Fatalf("no se pudo cifrar el fixture: %v", err)
	}

	_, err := NewPDFDocumentReader().Read(target)
	if !errors.Is(err, domainerrors.ErrEncryptedPDF) {
		t.Fatalf("se esperaba ErrEncryptedPDF, se obtuvo %v", err)
	}
	if !strings.Contains(err.Error(), "protegido") {
		t.Fatalf("el error debe indicar que el PDF está protegido: %v", err)
	}
}

func TestReadPDFWithoutTextLayer(t *testing.T) {
	content := "0 0 0 RG 20 20 100 100 re S"
	path := writeSyntheticPDF(t, []string{
		"<< /Type /Catalog /Pages 2 0 R >>",
		"<< /Type /Pages /Kids [3 0 R] /Count 1 >>",
		"<< /Type /Page /Parent 2 0 R /MediaBox [0 0 300 300] /Resources << >> /Contents 4 0 R >>",
		streamObject("", content),
	})

	_, err := NewPDFDocumentReader().Read(path)
	if !errors.Is(err, domainerrors.ErrNoTextContent) {
		t.Fatalf("se esperaba ErrNoTextContent, se obtuvo %v", err)
	}
	if !strings.Contains(err.Error(), "texto extraíble") {
		t.Fatalf("el error debe indicar que no hay texto: %v", err)
	}
}

func TestReadPDFWithUnsupportedImageWarnsAndContinues(t *testing.T) {
	image := "\x00\x00\x00\x0cjP  \r\n\x87\n" + strings.Repeat("\x00", 64)
	content := "BT /F1 12 Tf 20 150 Td (Hola JPX) Tj ET\nq 64 0 0 64 20 40 cm /Im1 Do Q"
	path := writeSyntheticPDF(t, []string{
		"<< /Type /Catalog /Pages 2 0 R >>",
		"<< /Type /Pages /Kids [3 0 R] /Count 1 >>",
		"<< /Type /Page /Parent 2 0 R /MediaBox [0 0 200 200] /Resources << /Font << /F1 4 0 R >> /XObject << /Im1 5 0 R >> >> /Contents 6 0 R >>",
		"<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica /Encoding /WinAnsiEncoding >>",
		streamObject("/Type /XObject /Subtype /Image /Width 8 /Height 8 /ColorSpace /DeviceRGB /BitsPerComponent 8 /Filter /JPXDecode", image),
		streamObject("", content),
	})

	reader := NewPDFDocumentReader()
	document, err := reader.Read(path)
	if err != nil {
		t.Fatalf("Read devolvió error: %v", err)
	}
	if len(document.Assets) != 0 {
		t.Fatalf("no se debía extraer la imagen JPX: %+v", document.Assets)
	}
	warnings := reader.Warnings()
	if len(warnings) != 1 || !strings.Contains(warnings[0], "JPX") || !strings.Contains(warnings[0], "omitida") {
		t.Fatalf("aviso inesperado: %v", warnings)
	}
}

func TestReadSamplePDFTwiceResetsWarnings(t *testing.T) {
	reader := NewPDFDocumentReader()
	if _, err := reader.Read(samplePDFPath); err != nil {
		t.Fatalf("primera lectura: %v", err)
	}
	if _, err := reader.Read(samplePDFPath); err != nil {
		t.Fatalf("segunda lectura: %v", err)
	}
	if warnings := reader.Warnings(); len(warnings) != 0 {
		t.Fatalf("los avisos deben reiniciarse por lectura: %v", warnings)
	}
}

func streamObject(dictExtra, data string) string {
	if dictExtra != "" {
		dictExtra += " "
	}
	return fmt.Sprintf("<< %s/Length %d >>\nstream\n%s\nendstream", dictExtra, len(data), data)
}

// writeSyntheticPDF arma un PDF mínimo con xref válida para los tests.
func writeSyntheticPDF(t *testing.T, objects []string) string {
	t.Helper()
	var buffer bytes.Buffer
	buffer.WriteString("%PDF-1.4\n")
	offsets := make([]int, len(objects))
	for i, object := range objects {
		offsets[i] = buffer.Len()
		fmt.Fprintf(&buffer, "%d 0 obj\n%s\nendobj\n", i+1, object)
	}
	startXref := buffer.Len()
	fmt.Fprintf(&buffer, "xref\n0 %d\n0000000000 65535 f \n", len(objects)+1)
	for _, offset := range offsets {
		fmt.Fprintf(&buffer, "%010d 00000 n \n", offset)
	}
	fmt.Fprintf(&buffer, "trailer\n<< /Size %d /Root 1 0 R >>\nstartxref\n%d\n%%%%EOF\n", len(objects)+1, startXref)

	path := filepath.Join(t.TempDir(), "synthetic.pdf")
	if err := os.WriteFile(path, buffer.Bytes(), 0o644); err != nil {
		t.Fatalf("no se pudo escribir el PDF sintético: %v", err)
	}
	return path
}
