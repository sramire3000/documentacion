package cli

import (
	"errors"
	"flag"
	"fmt"
	"io"
	"strings"

	"github.com/hsr/go-convet-pdf-a-md/internal/application/dto"
	domainerrors "github.com/hsr/go-convet-pdf-a-md/internal/domain/errors"
)

const (
	exitSuccess     = 0
	exitFailure     = 1
	exitInputError  = 2
	exitOutputError = 3
)

// Converter es la operación que el comando ejecuta.
type Converter interface {
	Execute(request dto.ConvertPDFRequest) (dto.ConvertPDFResult, error)
}

// ConvertCommand implementa la CLI pdf2md.
type ConvertCommand struct {
	converter Converter
}

// NewConvertCommand construye el comando con el caso de uso inyectado.
func NewConvertCommand(converter Converter) *ConvertCommand {
	return &ConvertCommand{converter: converter}
}

// Run parsea los argumentos, ejecuta la conversión y devuelve el código de salida.
func (c *ConvertCommand) Run(args []string, stdout, stderr io.Writer) int {
	flags := flag.NewFlagSet("pdf2md", flag.ContinueOnError)
	flags.SetOutput(stderr)

	var outputPath, assetsDir string
	var overwrite bool
	flags.StringVar(&outputPath, "o", "", "ruta del archivo Markdown de salida")
	flags.StringVar(&outputPath, "output", "", "ruta del archivo Markdown de salida")
	flags.StringVar(&assetsDir, "assets-dir", "", "directorio donde se escriben las imágenes extraídas")
	flags.BoolVar(&overwrite, "overwrite", false, "sobrescribe el archivo de salida si ya existe")
	flags.Usage = func() { printUsage(stderr) }

	if err := flags.Parse(orderArgs(args)); err != nil {
		if errors.Is(err, flag.ErrHelp) {
			return exitSuccess
		}
		return exitFailure
	}
	if flags.NArg() != 1 {
		printUsage(stderr)
		return exitFailure
	}

	request := dto.ConvertPDFRequest{
		InputPath:  flags.Arg(0),
		OutputPath: outputPath,
		AssetsDir:  assetsDir,
		Overwrite:  overwrite,
	}
	result, err := c.converter.Execute(request)
	if err != nil {
		fmt.Fprintf(stderr, "pdf2md: %v\n", err)
		return exitCode(err)
	}
	for _, warning := range result.Warnings {
		fmt.Fprintf(stderr, "pdf2md: advertencia: %s\n", warning)
	}
	fmt.Fprintf(stdout, "%s (%d páginas, %d imágenes)\n", result.OutputPath, result.PagesConverted, result.ImagesExtracted)
	return exitSuccess
}

func printUsage(w io.Writer) {
	fmt.Fprintln(w, "Uso: pdf2md <archivo.pdf> [-o <salida.md>] [--assets-dir <directorio>] [--overwrite]")
}

// flagsWithValue son las opciones que consumen el argumento siguiente.
var flagsWithValue = map[string]bool{"-o": true, "--output": true, "--assets-dir": true}

// orderArgs mueve las opciones al principio para aceptarlas después del PDF.
func orderArgs(args []string) []string {
	ordered := make([]string, 0, len(args))
	var positional []string
	for i := 0; i < len(args); i++ {
		arg := args[i]
		if strings.HasPrefix(arg, "-") && arg != "-" {
			ordered = append(ordered, arg)
			if flagsWithValue[arg] && i+1 < len(args) {
				i++
				ordered = append(ordered, args[i])
			}
			continue
		}
		positional = append(positional, arg)
	}
	return append(ordered, positional...)
}

func exitCode(err error) int {
	switch {
	case errors.Is(err, domainerrors.ErrInputNotFound):
		return exitInputError
	case errors.Is(err, domainerrors.ErrOutputExists):
		return exitOutputError
	default:
		return exitFailure
	}
}
