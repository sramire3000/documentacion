package cli

import (
	"bytes"
	"errors"
	"os"
	"path/filepath"
	"strings"
	"testing"

	"github.com/hsr/go-convet-pdf-a-md/internal/application/dto"
	"github.com/hsr/go-convet-pdf-a-md/internal/application/usecase"
	domainerrors "github.com/hsr/go-convet-pdf-a-md/internal/domain/errors"
	"github.com/hsr/go-convet-pdf-a-md/internal/infrastructure/persistence"
)

type stubConverter struct {
	result   dto.ConvertPDFResult
	err      error
	requests []dto.ConvertPDFRequest
}

func (s *stubConverter) Execute(request dto.ConvertPDFRequest) (dto.ConvertPDFResult, error) {
	s.requests = append(s.requests, request)
	return s.result, s.err
}

func run(t *testing.T, converter Converter, args ...string) (int, string, string) {
	t.Helper()
	var stdout, stderr bytes.Buffer
	code := NewConvertCommand(converter).Run(args, &stdout, &stderr)
	return code, stdout.String(), stderr.String()
}

func TestRunWithoutArguments(t *testing.T) {
	code, _, stderr := run(t, &stubConverter{})
	if code != exitFailure {
		t.Fatalf("se esperaba código %d, se obtuvo %d", exitFailure, code)
	}
	if !strings.Contains(stderr, "Uso: pdf2md") {
		t.Fatalf("se esperaba la ayuda en stderr: %q", stderr)
	}
}

func TestRunHelp(t *testing.T) {
	code, _, stderr := run(t, &stubConverter{}, "-h")
	if code != exitSuccess {
		t.Fatalf("se esperaba código 0, se obtuvo %d", code)
	}
	if !strings.Contains(stderr, "Uso: pdf2md") {
		t.Fatalf("se esperaba la ayuda: %q", stderr)
	}
}

func TestRunSuccessPrintsResultAndWarnings(t *testing.T) {
	converter := &stubConverter{result: dto.ConvertPDFResult{
		OutputPath:      "/tmp/salida.md",
		PagesConverted:  2,
		ImagesExtracted: 1,
		Warnings:        []string{"página 1: imagen Im1 omitida (formato JBIG2 no soportado)"},
	}}
	code, stdout, stderr := run(t, converter, "/tmp/entrada.pdf")
	if code != exitSuccess {
		t.Fatalf("se esperaba código 0, se obtuvo %d", code)
	}
	if !strings.Contains(stdout, "/tmp/salida.md") {
		t.Fatalf("salida estándar inesperada: %q", stdout)
	}
	if !strings.Contains(stderr, "advertencia") || !strings.Contains(stderr, "JBIG2") {
		t.Fatalf("el aviso debía ir a stderr: %q", stderr)
	}
	if len(converter.requests) != 1 || converter.requests[0].InputPath != "/tmp/entrada.pdf" {
		t.Fatalf("petición inesperada: %+v", converter.requests)
	}
}

func TestRunMapsBusinessErrorsToExitCodes(t *testing.T) {
	cases := []struct {
		name string
		err  error
		want int
	}{
		{"entrada inexistente", domainerrors.ErrInputNotFound, exitInputError},
		{"salida existente", domainerrors.ErrOutputExists, exitOutputError},
		{"pdf cifrado", domainerrors.ErrEncryptedPDF, exitFailure},
		{"pdf sin texto", domainerrors.ErrNoTextContent, exitFailure},
		{"error genérico", errors.New("boom"), exitFailure},
	}
	for _, testCase := range cases {
		t.Run(testCase.name, func(t *testing.T) {
			code, stdout, stderr := run(t, &stubConverter{err: testCase.err}, "/tmp/entrada.pdf")
			if code != testCase.want {
				t.Fatalf("se esperaba código %d, se obtuvo %d", testCase.want, code)
			}
			if stdout != "" {
				t.Fatalf("no se esperaba salida estándar: %q", stdout)
			}
			if !strings.Contains(stderr, testCase.err.Error()) {
				t.Fatalf("el error debía ir a stderr: %q", stderr)
			}
		})
	}
}

func TestRunAcceptsFlagsBeforeAndAfterInput(t *testing.T) {
	converter := &stubConverter{}
	code, _, stderr := run(t, converter,
		"/tmp/entrada.pdf",
		"-o", "/tmp/salida.md",
		"--assets-dir", "/tmp/imagenes",
		"--overwrite",
	)
	if code != exitSuccess {
		t.Fatalf("se esperaba código 0, se obtuvo %d (%s)", code, stderr)
	}
	request := converter.requests[0]
	if request.OutputPath != "/tmp/salida.md" || request.AssetsDir != "/tmp/imagenes" || !request.Overwrite {
		t.Fatalf("flags no interpretadas: %+v", request)
	}
}

func TestRunAcceptsLongOutputFlag(t *testing.T) {
	converter := &stubConverter{}
	if code, _, _ := run(t, converter, "--output=/tmp/salida.md", "/tmp/entrada.pdf"); code != exitSuccess {
		t.Fatalf("se esperaba código 0, se obtuvo %d", code)
	}
	if converter.requests[0].OutputPath != "/tmp/salida.md" {
		t.Fatalf("--output no interpretado: %+v", converter.requests[0])
	}
}

func TestRunConvertsFixturePDF(t *testing.T) {
	fixture := filepath.Join("..", "..", "persistence", "testdata", "sample.pdf")
	if _, err := os.Stat(fixture); err != nil {
		t.Fatalf("no se encontró el fixture: %v", err)
	}
	outputPath := filepath.Join(t.TempDir(), "sample.md")
	converter := usecase.NewConvertPDFUseCase(persistence.NewPDFDocumentReader(), persistence.NewMarkdownFileWriter())

	code, stdout, stderr := run(t, converter, fixture, "-o", outputPath)
	if code != exitSuccess {
		t.Fatalf("se esperaba código 0, se obtuvo %d (%s)", code, stderr)
	}
	if stderr != "" {
		t.Fatalf("no se esperaban avisos: %q", stderr)
	}
	if !strings.Contains(stdout, outputPath) {
		t.Fatalf("salida estándar inesperada: %q", stdout)
	}

	content, err := os.ReadFile(outputPath)
	if err != nil {
		t.Fatalf("no se pudo leer el Markdown: %v", err)
	}
	markdown := string(content)
	for _, expected := range []string{
		"# Convertidor de PDF a Markdown",
		"## Alcance del proyecto",
		"### Lista de tareas",
		"| Formato | Soporte | Notas |",
		"| --- | --- | --- |",
		"\n---\n",
		"- Revisar el fixture",
		"![Imagen extraída de la página 2](assets/sample/page-2-img-1.jpg)",
		"![Imagen extraída de la página 2](assets/sample/page-2-img-2.png)",
	} {
		if !strings.Contains(markdown, expected) {
			t.Fatalf("falta %q en el Markdown:\n%s", expected, markdown)
		}
	}
	if strings.HasPrefix(markdown, "---") || strings.HasSuffix(strings.TrimSpace(markdown), "---") {
		t.Fatalf("el documento no debe empezar ni terminar con un separador:\n%s", markdown)
	}
	for _, asset := range []string{"page-2-img-1.jpg", "page-2-img-2.png"} {
		assetPath := filepath.Join(filepath.Dir(outputPath), "assets", "sample", asset)
		if _, err := os.Stat(assetPath); err != nil {
			t.Fatalf("no se escribió %s: %v", assetPath, err)
		}
	}
}
