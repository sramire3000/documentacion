# Estructura del proyecto (Go)

Este documento es la fuente de verdad de la organización del código. Todo artefacto nuevo o modificado debe ubicarse en la capa y subcapa que se define aquí. Si algo no encaja, se consulta antes de inventar un paquete.

## Reglas generales

- El módulo se declara en `go.mod` en la raíz. El código privado de la aplicación vive bajo `internal/`; solo lo estrictamente reutilizable y público va a `pkg/`.
- `cmd/<binario>/main.go` es el **composition root**: lee configuración, construye dependencias y arranca el entrypoint. No contiene reglas de negocio.
- Las dependencias apuntan hacia adentro: `infrastructure` → `application` → `domain`. El dominio no importa `application`, `infrastructure`, `configuration` ni librerías de framework.
- Los tests viven junto al archivo que prueban (`<archivo>_test.go`), en el mismo paquete o en `<paquete>_test`.

## Árbol de directorios

```text
.
├── go.mod
├── go.sum
├── cmd/
│   └── <binario>/
│       └── main.go
└── internal/
    ├── domain/
    │   ├── model/
    │   ├── errors/
    │   └── repository/
    ├── application/
    │   ├── usecase/
    │   └── dto/
    ├── infrastructure/
    │   ├── entrypoints/
    │   │   ├── http/
    │   │   │   ├── dto/
    │   │   │   └── mapper/
    │   │   └── cli/
    │   ├── persistence/
    │   ├── client/
    │   └── security/
    └── configuration/
```

## Capas

### `internal/domain/`

Núcleo del negocio, sin dependencias externas.

- `model/` — entidades, value objects y reglas invariantes.
- `errors/` — errores de negocio (`ErrNotFound`, `ErrInvalidInput`, …) que los adaptadores traducen a su propio formato.
- `repository/` — puertos: interfaces pequeñas que el dominio necesita para persistir o recuperar datos.

### `internal/application/`

Orquesta casos de uso. Depende de `domain` y de los puertos, nunca de implementaciones concretas.

- `usecase/` — un archivo por caso de uso (`create_user_usecase.go`) con su struct y su método principal.
- `dto/` — estructuras de entrada/salida propias de la aplicación, sin etiquetas de transporte (JSON, form, etc.).

### `internal/infrastructure/`

Adaptadores que conectan el núcleo con el mundo exterior.

- `entrypoints/http/` — handlers HTTP, rutas y middleware; `dto/` y `mapper/` para el contrato de la API.
- `entrypoints/cli/` — comandos y flags cuando la app expone una CLI.
- `persistence/` — implementaciones de los puertos (`<x>_repository.go`), SQL, archivos o almacenamiento en memoria.
- `client/` — clientes de servicios externos.
- `security/` — autenticación, autorización y utilidades criptográficas.

### `internal/configuration/`

Carga de configuración (variables de entorno, archivos), validación y funciones de wiring compartidas. No contiene lógica de negocio.

## Mapeo de artefactos

| Artefacto                  | Ruta                                                        |
| -------------------------- | ----------------------------------------------------------- |
| Entrypoint / `main`        | `cmd/<binario>/main.go`                                     |
| Handler HTTP               | `internal/infrastructure/entrypoints/http/<x>_handler.go`   |
| DTO HTTP / mapper          | `.../entrypoints/http/dto/`, `.../entrypoints/http/mapper/` |
| Comando CLI                | `internal/infrastructure/entrypoints/cli/<x>_command.go`    |
| Caso de uso                | `internal/application/usecase/<x>_usecase.go`               |
| DTO de aplicación          | `internal/application/dto/`                                 |
| Modelo de dominio          | `internal/domain/model/`                                    |
| Error de negocio           | `internal/domain/errors/`                                   |
| Puerto de repositorio      | `internal/domain/repository/`                               |
| Adaptador de persistencia  | `internal/infrastructure/persistence/<x>_repository.go`     |
| Cliente externo            | `internal/infrastructure/client/`                           |
| Seguridad                  | `internal/infrastructure/security/`                         |
| Configuración y wiring     | `internal/configuration/`                                   |
| Test                       | Junto al archivo probado: `<archivo>_test.go`               |

## Convenciones de nombres

- Paquetes en minúsculas, una sola palabra, sin guiones ni guiones bajos (`usecase`, `persistence`, `httpclient`).
- Archivos en `snake_case` (`create_user_usecase.go`).
- Identificadores exportados en inglés y en `PascalCase`; no exportados en `camelCase`.
- Puertos de dominio con el nombre del recurso (`UserRepository`) y adaptadores concretos con el mecanismo (`PostgresUserRepository`, `FileUserRepository`).
- Constructores `New<Type>` que devuelven el tipo concreto o la interfaz cuando el consumidor la define.
- Errores centinela en `domain/errors`; el resto se envuelve con `fmt.Errorf("...: %w", err)`.

## Reglas de dependencia

1. `domain` no importa ninguna otra capa ni librerías de framework.
2. `application` importa `domain`; recibe implementaciones por inyección (interfaces).
3. `infrastructure` importa `application` y `domain`; nunca al revés.
4. `configuration` puede importar todas las capas para cablear dependencias.
5. `cmd/<binario>` solo importa `configuration` y los entrypoints.

## Tests

- Un archivo `_test.go` por archivo relevante, en el mismo directorio y paquete.
- Tablas de casos (`tests := []struct{...}`) cuando se evalúan varios escenarios.
- Dobles de prueba mediante interfaces propias; sin frameworks de mocking salvo necesidad justificada.
- Comandos de verificación: `gofmt -w .`, `go vet ./...`, `go build ./...`, `go test ./...`.

## Anti-patrones prohibidos

- Paquetes planos `internal/controller`, `internal/service`, `internal/repository`, `internal/dto`.
- Lógica de negocio en `main.go`, handlers o repositorios.
- Uso de `pkg/` para código privado de la aplicación.
- Dependencias circulares entre capas.
- `panic` para errores esperados o de validación.

## Checklist para un cambio

- [ ] Cada archivo nuevo está en la capa y subcapa correctas.
- [ ] Las dependencias respetan la dirección `infrastructure` → `application` → `domain`.
- [ ] `main.go` solo cablea dependencias.
- [ ] Hay tests junto al código modificado y pasan con `go test ./...`.
- [ ] `gofmt`, `go vet` y `go build` terminan sin errores.
