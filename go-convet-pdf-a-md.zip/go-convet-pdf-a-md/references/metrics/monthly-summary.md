# Resumen mensual

> Actualizado: 20/11/2026 00:22

## Acumulado por mes

| Mes | Tareas | Input | Output | Total | Promedio/tarea | LOC | Tests | Duración prom. | Costo |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| 2026-11 | 1 | 4.035 | 852 | 4.887 | 4.887 | 0 | 0 | 0 min | $0,0000 |

## Detalle 2026-11

| Fecha | Spec | Épica | Tokens | LOC | Tests | Duración | Estado |
| --- | --- | --- | ---: | ---: | ---: | ---: | --- |
| 2026-11-20 | 01-pdf-to-markdown |  | 4.887 | 0 | 0 | 0 min | completado |
