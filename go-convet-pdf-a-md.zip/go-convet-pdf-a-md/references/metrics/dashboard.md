# Engineering Metrics Dashboard

> Actualizado: 20/11/2026 00:22
> Fuente: `references/metrics/spec-metrics.csv`

## Resumen general

| Métrica | Valor |
| --- | ---: |
| Tareas registradas | 1 |
| Specs completados | 1 |
| Épicas trabajadas | 0 |
| Ramas | 0 |
| Duración promedio | 0 min |

## Tokens

| Métrica | Valor |
| --- | ---: |
| Input | 4.035 |
| Output | 852 |
| **Total (input + output)** | **4.887** |
| Caché leída | 508.288 |
| Caché escrita | 0 |
| Procesados con caché | 513.175 |
| Promedio por tarea | 4.887 |
| Costo acumulado | $0,0000 |
| Mayor consumo | 01-pdf-to-markdown (4.887) |
| Menor consumo | 01-pdf-to-markdown (4.887) |

## Productividad

| Métrica | Valor |
| --- | ---: |
| LOC agregadas | 0 |
| LOC eliminadas | 0 |
| LOC netas | 0 |
| LOC por 1.000 tokens | 0,00 |
| Archivos creados | 0 |
| Archivos modificados | 1 |
| Tests generados | 0 |
| Tests por 100 LOC | 0,00 |

## Por épica

| Épica | Specs | Tokens | Promedio | LOC | Tests |
| --- | ---: | ---: | ---: | ---: | ---: |
| Sin épica | 1 | 4.887 | 4.887 | 0 | 0 |

## Top 10 tareas por consumo

| # | Spec | Épica | Input | Output | Total | LOC | Tests | Duración |
| ---: | --- | --- | ---: | ---: | ---: | ---: | ---: | ---: |
| 1 | 01-pdf-to-markdown |  | 4.035 | 852 | 4.887 | 0 | 0 | 0 min |

## Últimos specs

| Fecha | Spec | Rama | Estado | Tokens | LOC | Tests |
| --- | --- | --- | --- | ---: | ---: | ---: |
| 2026-11-20 | 01-pdf-to-markdown |  | completado | 4.887 | 0 | 0 |
