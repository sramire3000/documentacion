# SPEC 01 — Convertidor de PDF a Markdown

> **Estado:** Implementado
> **Depende de:** —
> **Fecha:** 2026-11-20
> **Objetivo:** Convertir un PDF de texto, imágenes y tablas en un `.md` con las imágenes extraídas a `assets/`, usando solo librerías Go puras sin CGO.

## Alcance

**Dentro:**

- CLI `pdf2md <archivo.pdf>` que genera `<archivo>.md` en el mismo directorio del PDF.
- Flags `-o/--output`, `--assets-dir` y `--overwrite`; ayuda y errores por `stderr` con código de salida ≠ 0.
- Lectura de texto con posición y tamaño de fuente (`ledongthuc/pdf`).
- Títulos `#`, `##`, `###` por tamaño de fuente relativo a la mediana del documento.
- Párrafos reconstruidos agrupando runs por línea base y orden de lectura.
- Listas cuando la línea empieza con `•`, `-`, `*` o `N.`.
- Tablas GFM detectadas por rectángulos `re` y alineación de columnas, con fallback a texto por líneas.
- Imágenes JPEG y PNG extraídas a `assets/<nombre-pdf>/page-<n>-img-<k>.<ext>` y referenciadas en orden de aparición.
- Separador `---` entre páginas.
- Tests unitarios de heurísticas y render, y test de integración con un PDF fixture incluido en el repo.

**Fuera de alcance (para specs futuros):**

- OCR y PDFs escaneados sin capa de texto: se devuelve error de negocio claro.
- PDFs cifrados o con contraseña: error de negocio claro, sin intentar descifrar.
- Negrita, cursiva, enlaces, código, notas al pie y numeración automática de secciones.
- Imágenes JBIG2, JPX y CCITT: se omiten y se avisa por `stderr`.
- Tablas anidadas o con celdas combinadas: caen al fallback de texto.
- Eliminación de cabeceras/pies repetidos y maquetación multicolumna avanzada.
- Conversión por lotes, modo watch y servidor HTTP.

## Modelo de datos

```go
// internal/domain/model/document.go
package model

// Document es la representación intermedia, independiente del PDF y del Markdown.
type Document struct {
	Pages  []Page
	Assets []ImageAsset
}

type Page struct {
	Number int
	Blocks []Block
}

// Block es la suma cerrada de bloques que el renderer sabe escribir.
type Block interface{ isBlock() }

type Heading struct {
	Level   int // 1..3
	Content string
}

type Paragraph struct {
	Content string
}

type ListItem struct {
	Marker  string // "•", "-", "*" o "N."
	Content string
}

type Table struct {
	Headers []string
	Rows    [][]string
}

type Image struct {
	FileName string // page-3-img-1.png, relativo a assets/
	AltText  string
}

type ImageAsset struct {
	Page     int
	Index    int
	Format   string // "png" | "jpg"
	Data     []byte
	FileName string
}
```

```go
// internal/application/dto/convert_pdf_request.go
package dto

type ConvertPDFRequest struct {
	InputPath  string
	OutputPath string // vacío ⇒ mismo nombre que el PDF con extensión .md
	AssetsDir  string // vacío ⇒ assets/<nombre-pdf>/ junto al .md
	Overwrite  bool
}

type ConvertPDFResult struct {
	OutputPath      string
	PagesConverted  int
	ImagesExtracted int
	Warnings        []string
}
```

```go
// internal/domain/repository/document_reader.go
package repository

type DocumentReader interface {
	Read(inputPath string) (model.Document, error)
}

// internal/domain/repository/output_writer.go
type OutputWriter interface {
	Write(outputPath string, content []byte, overwrite bool) error
	WriteAssets(dir string, assets []model.ImageAsset) error
}
```

Convenciones:

- Coordenadas normalizadas a origen arriba-izquierda en el adaptador; tamaños en puntos.
- `Heading.Level` solo admite 1–3.
- `Image.FileName` es siempre relativo a `AssetsDir`.

Esta feature no persiste nada entre ejecuciones: el estado es el `.md` y los assets que se escriben en disco.

## Archivos y ubicación

| Archivo                                                            | Capa / paquete                          | Acción     |
| ------------------------------------------------------------------ | --------------------------------------- | ---------- |
| `go.mod`                                                           | raíz (módulo)                           | Modificado |
| `go.sum`                                                           | raíz (módulo)                           | Nuevo      |
| `cmd/pdf2md/main.go`                                               | composition root                        | Nuevo      |
| `main.go`                                                          | raíz                                    | Eliminado  |
| `internal/domain/model/document.go`                                | `domain/model`                          | Nuevo      |
| `internal/domain/errors/errors.go`                                 | `domain/errors`                         | Nuevo      |
| `internal/domain/repository/document_reader.go`                    | `domain/repository`                     | Nuevo      |
| `internal/domain/repository/output_writer.go`                      | `domain/repository`                     | Nuevo      |
| `internal/application/dto/convert_pdf_request.go`                  | `application/dto`                       | Nuevo      |
| `internal/application/dto/convert_pdf_result.go`                   | `application/dto`                       | Nuevo      |
| `internal/application/usecase/convert_pdf_usecase.go`              | `application/usecase`                   | Nuevo      |
| `internal/application/usecase/convert_pdf_usecase_test.go`         | `application/usecase` (test)            | Nuevo      |
| `internal/application/usecase/markdown_renderer.go`                | `application/usecase`                   | Nuevo      |
| `internal/application/usecase/markdown_renderer_test.go`           | `application/usecase` (test)            | Nuevo      |
| `internal/infrastructure/persistence/pdf_document_reader.go`       | `infrastructure/persistence`            | Nuevo      |
| `internal/infrastructure/persistence/pdf_document_reader_test.go`  | `infrastructure/persistence` (test)     | Nuevo      |
| `internal/infrastructure/persistence/text_layout.go`               | `infrastructure/persistence`            | Nuevo      |
| `internal/infrastructure/persistence/text_layout_test.go`          | `infrastructure/persistence` (test)     | Nuevo      |
| `internal/infrastructure/persistence/markdown_file_writer.go`      | `infrastructure/persistence`            | Nuevo      |
| `internal/infrastructure/persistence/markdown_file_writer_test.go` | `infrastructure/persistence` (test)     | Nuevo      |
| `internal/infrastructure/persistence/testdata/sample.pdf`          | `infrastructure/persistence` (fixture)  | Nuevo      |
| `internal/infrastructure/entrypoints/cli/convert_command.go`       | `infrastructure/entrypoints/cli`        | Nuevo      |
| `internal/infrastructure/entrypoints/cli/convert_command_test.go`  | `infrastructure/entrypoints/cli` (test) | Nuevo      |

`internal/infrastructure/persistence/text_layout.go` contiene las heurísticas de título, párrafo, lista y tabla sobre `[]pdf.Text` y `[]pdf.Rect`: son lógica de interpretación del PDF, no del dominio.

## Plan de implementación

1. Actualizar `go.mod` con `github.com/pdfcpu/pdfcpu` y `github.com/ledongthuc/pdf`, y generar `go.sum` con `go mod tidy`. Verificación: `go build ./...`.
2. Crear `internal/domain/model/document.go` con los tipos de la sección "Modelo de datos" e `internal/domain/errors/errors.go` con `ErrInputNotFound`, `ErrUnsupportedFormat`, `ErrEncryptedPDF`, `ErrNoTextContent` y `ErrOutputExists`. Verificación: `go build ./...`.
3. Crear `internal/domain/repository/document_reader.go` y `internal/domain/repository/output_writer.go` con los dos puertos. Verificación: `go build ./...`.
4. Crear `internal/application/usecase/markdown_renderer.go` con `renderMarkdown(doc model.Document, assetsPrefix string) []byte` y `internal/application/usecase/markdown_renderer_test.go`, cubriendo títulos, párrafos, listas, tablas, imágenes, escapado GFM y separador de página. Verificación: `go test ./internal/application/usecase`.
5. Crear `internal/infrastructure/persistence/text_layout.go` y `internal/infrastructure/persistence/text_layout_test.go`: agrupación por línea base, mediana de tamaños para niveles 1–3, listas por prefijo, detección de tabla por rectángulos y columnas, y fallback a texto. Verificación: `go test ./internal/infrastructure/persistence`.
6. Crear `internal/infrastructure/persistence/pdf_document_reader.go` y `internal/infrastructure/persistence/pdf_document_reader_test.go` con `internal/infrastructure/persistence/testdata/sample.pdf`: abre el PDF, valida cifrado y ausencia de texto, mapea páginas a `model.Document`, extrae JPEG y PNG con `pdfcpu` y agrega warnings para formatos omitidos. Verificación: `go test ./internal/infrastructure/persistence`.
7. Crear `internal/infrastructure/persistence/markdown_file_writer.go` y `internal/infrastructure/persistence/markdown_file_writer_test.go`: escribe el `.md` respetando `overwrite` (`ErrOutputExists` si existe y no se permite) y crea `AssetsDir` solo si hay assets. Verificación: `go test ./internal/infrastructure/persistence`.
8. Crear `internal/application/usecase/convert_pdf_usecase.go` con `Execute(dto.ConvertPDFRequest) (dto.ConvertPDFResult, error)`: resuelve rutas por defecto, lee, renderiza, escribe y agrega warnings; `internal/application/usecase/convert_pdf_usecase_test.go` usa dobles de los dos puertos. Verificación: `go test ./internal/application/usecase`.
9. Crear `internal/infrastructure/entrypoints/cli/convert_command.go` y `internal/infrastructure/entrypoints/cli/convert_command_test.go`: parsea `-o/--output`, `--assets-dir` y `--overwrite`, imprime errores por `stderr` y traduce errores de negocio a códigos de salida (`ErrInputNotFound` → 2, `ErrOutputExists` → 3, resto → 1). Verificación: `go test ./internal/infrastructure/entrypoints/cli`.
10. Crear `cmd/pdf2md/main.go` cableando el comando con los adaptadores, y eliminar `main.go` de la raíz. Verificación: `go run ./cmd/pdf2md internal/infrastructure/persistence/testdata/sample.pdf` genera `sample.md` con contenido.

## Criterios de aceptación

- [x] `gofmt -l .` no devuelve archivos, y `go vet ./...` termina sin errores.
- [x] `go build ./...` y `go test ./...` terminan sin errores.
- [x] `go run ./cmd/pdf2md internal/infrastructure/persistence/testdata/sample.pdf` crea `sample.md` junto al PDF y termina con código 0.
- [x] Cada página del PDF queda separada por una línea `---` y el documento no empieza ni termina con un separador suelto.
- [x] La línea con mayor tamaño de fuente del fixture se emite como encabezado `#`, y los niveles 2 y 3 se emiten como `##` y `###`.
- [x] La tabla con bordes del fixture se emite como tabla GFM con encabezado y fila separadora `| --- |`.
- [x] Cada imagen JPEG o PNG del fixture se escribe en `assets/<nombre-pdf>/page-<n>-img-<k>.<ext>` y el `.md` la referencia con esa ruta relativa, que existe en disco.
- [x] Una imagen JBIG2, JPX o CCITT se omite, se informa por `stderr` y la ejecución termina con código 0.
- [x] Sin `--overwrite`, ejecutar sobre un `.md` existente devuelve código 3, escribe el mensaje por `stderr` y deja el `.md` original intacto.
- [x] Con un PDF inexistente, la salida es código 2 y el mensaje por `stderr` nombra la ruta recibida.
- [x] Con un PDF cifrado, la salida es código 1 y el mensaje por `stderr` indica que el PDF está protegido.
- [x] Con un PDF sin capa de texto, la salida es código 1 y el mensaje por `stderr` indica que no hay texto extraíble.
- [x] `-o/--output` y `--assets-dir` escriben exactamente en las rutas indicadas, incluidas rutas absolutas.
- [x] `cmd/pdf2md/main.go` solo construye dependencias y arranca el comando; no contiene reglas de negocio.
- [x] Todos los archivos viven en `domain/`, `application/` o `infrastructure/` según `references/estructura/estructura.md`, sin paquetes planos ni `pkg/`.
- [x] Los identificadores están en inglés y los comentarios en español, sin código duplicado entre `text_layout.go` y `markdown_renderer.go`.

## Decisiones

- **Sí:** `pdfcpu` para imágenes y `ledongthuc/pdf` para texto y posiciones. Ambas son Go puro, sin CGO, y cubren lo que la stdlib no ofrece.
- **No:** parser PDF propio sobre stdlib. Reimplementar xref, content streams y fuentes cuesta más que el valor que aporta y retrasa la feature.
- **No:** `unipdf`, porque exige licencia comercial.
- **No:** binarios externos (`pdftotext`, `mutool`, ImageMagick). Rompen la promesa de un único binario portable.
- **Sí:** pipeline en dos etapas, `model.Document` intermedio y luego render Markdown. Permite testear extracción y formato por separado, y habilita otros formatos de salida en el futuro.
- **Sí:** heurísticas de layout en `text_layout.go` (infraestructura). Dependen de coordenadas del PDF, no son reglas de negocio.
- **Sí:** suma cerrada de bloques por interface con método no exportado. El renderer hace `type switch` y el compilador obliga a contemplar todo bloque nuevo.
- **Sí:** solo JPEG y PNG. JBIG2, JPX y CCITT se omiten con aviso porque requieren decodificadores desproporcionados para este alcance.
- **Sí:** tablas por rectángulos `re` más alineación de columnas, con fallback a texto. Las celdas combinadas quedan fuera.
- **No:** OCR de PDFs escaneados. Necesita modelos y binarios externos; va en su propio spec.
- **No:** negrita y cursiva por nombre de fuente. La heurística es ruidosa y ensucia la salida más de lo que aporta.
- **Sí:** `--overwrite` explícito con `ErrOutputExists` por defecto. Evita sobrescribir trabajo del usuario sin permiso.
- **Sí:** `.md` junto al PDF y `assets/<nombre-pdf>/` por defecto. Es el comportamiento de menor sorpresa y `-o`/`--assets-dir` lo cambian.
- **No:** imágenes en base64 dentro del `.md`. Genera archivos enormes e ilegibles.
- **No:** paquete `configuration/`. Los flags de la CLI son toda la configuración necesaria.

## Riesgos

| Riesgo                                                             | Mitigación                                                                                        |
| ------------------------------------------------------------------ | ------------------------------------------------------------------------------------------------- |
| Tablas sin rectángulos ni columnas alineadas no se detectan        | Fallback a texto por líneas, con aviso por `stderr`; la tabla nunca se pierde, se degrada.        |
| Fuentes sin tabla `ToUnicode` producen texto ilegible o vacío      | Se detecta ausencia total de texto y se devuelve `ErrNoTextContent` en lugar de un `.md` vacío.   |
| Content streams malformados hacen panic dentro de `ledongthuc/pdf` | `recover()` en `pdf_document_reader.go` que convierte el panic en error de negocio con la página. |
| PDFs multicolumna intercalan líneas de ambas columnas              | Fuera de alcance por decisión explícita; se documenta en este spec y se detecta a mano.           |
| PDFs grandes consumen memoria                                      | Se procesa una página por vez y las imágenes se escriben antes de pasar a la siguiente.           |

## Lo que **no** está en este spec

- OCR de PDFs escaneados.
- Descifrado de PDFs protegidos.
- Negrita, cursiva, enlaces, bloques de código y notas al pie.
- Imágenes JBIG2, JPX y CCITT.
- Tablas anidadas o con celdas combinadas.
- Eliminación de cabeceras y pies repetidos.
- Maquetación multicolumna.
- Conversión por lotes, modo watch y servidor HTTP.
- Salidas HTML, DOCX u otros formatos distintos de Markdown.
- Limpieza o registro de assets huérfanos de ejecuciones anteriores.

Cada uno de esos, si llega, va en su propio spec.
