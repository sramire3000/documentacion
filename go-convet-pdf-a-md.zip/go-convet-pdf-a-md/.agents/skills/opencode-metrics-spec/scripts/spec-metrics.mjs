#!/usr/bin/env node
/**
 * opencode-metrics-spec
 *
 * Registra las métricas de implementación de un spec:
 *   - tokens reales de la sesión de OpenCode (opencode.db)
 *   - archivos y líneas tocadas (git diff contra la base del spec)
 *   - tests generados (declaraciones añadidas)
 *   - duración de la implementación
 *
 * Uso:
 *   node spec-metrics.mjs start    --spec 01-mvp-arkanoid
 *   node spec-metrics.mjs finish   --spec 01-mvp-arkanoid
 *   node spec-metrics.mjs finalize --spec 01-mvp-arkanoid
 *   node spec-metrics.mjs status
 *
 * finish escribe la fila con lo consumido hasta ese instante. Como el agente
 * sigue trabajando después de invocarlo, la sesión queda abierta: finalize
 * recalcula la fila con los totales definitivos de la sesión y borra la línea
 * base. Sin git, finalize cuenta archivos/LOC/tests por fecha de creación o
 * modificación dentro de la ventana de la sesión.
 *
 * Tanto finish como finalize suman la sesión base y toda sesión creada después
 * de `start` en el mismo directorio, así que los subagentes (por ejemplo
 * spec-verifier) y las verificaciones manuales quedan incluidos sin registrar
 * su id. No ejecutes finalize antes de la verificación: borra la línea base y
 * esos tokens ya no se pueden atribuir.
 *
 * Opciones de finish:
 *   --observaciones "texto"   Nota libre para el CSV
 *   --tipo feature|fix|refactor|docs|test
 *   --epic "Nombre"           Sobrescribe la épica leída del spec
 *   --prioridad Alta          Sobrescribe la prioridad leída del spec
 *   --base <ref>              Commit/rama base para el diff
 *   --session <ses_id>        Sesión de OpenCode a medir (default: OPENCODE_SESSION_ID)
 *   --duration N              Forzar duración en minutos
 *   --input N --output N      Forzar tokens (si no hay acceso a opencode.db)
 *   --reasoning N --cache-read N --cache-write N --cost N
 *   --dry-run                 Calcular sin escribir archivos
 *
 * Opciones de finalize:
 *   --session <ses_id>        Sobrescribe la sesión medida
 *   --duration N              Sobrescribe la duración registrada por finish
 *   --end <ms|ISO>            Fin de la ventana para contar archivos sin git
 */

import { spawnSync } from 'node:child_process';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';

const ROOT = process.cwd();
const METRICS_DIR = path.join(ROOT, 'references', 'metrics');
const STATE_DIR = path.join(METRICS_DIR, '.state');
const CSV_PATH = path.join(METRICS_DIR, 'spec-metrics.csv');
const DASHBOARD_PATH = path.join(METRICS_DIR, 'dashboard.md');
const MONTHLY_PATH = path.join(METRICS_DIR, 'monthly-summary.md');

const CSV_COLUMNS = [
  'fecha',
  'proyecto',
  'spec',
  'rama',
  'epic',
  'tipo',
  'prioridad',
  'modelo',
  'sesiones',
  'input_tokens',
  'output_tokens',
  'reasoning_tokens',
  'cache_read_tokens',
  'cache_write_tokens',
  'total_tokens',
  'costo_usd',
  'archivos_creados',
  'archivos_modificados',
  'archivos_eliminados',
  'test_files',
  'test_generados',
  'loc_agregadas',
  'loc_eliminadas',
  'duracion_min',
  'estado',
  'observaciones',
];

const TEST_FILE_RE =
  /(^|\/)(__tests__|tests?|e2e|cypress|integration-tests?)\/|(^|\/)test_[^/]+\.py$|(^|\/)[^/]+(Test|Tests|IT)\.(java|kt|cs|php)$|\.(test|spec|e2e)\.[cm]?[jt]sx?$/i;

const TEST_CASE_RES = [
  /^\+\s*(it|test|specify)(\.(only|skip|todo|each|concurrent))?\s*\(/,
  /^\+\s*(def\s+test_|class\s+Test)/,
  /^\+\s*func\s+Test/,
  /^\+\s*@(Test|ParameterizedTest|RepeatedTest|TestFactory)\b/,
  /^\+\s*\[(Fact|Theory|Test|TestMethod)\]/,
  /^\+\s*(test|it)\s+["'][^"']+["']\s*(do|:)/,
];

const intFmt = new Intl.NumberFormat('es-ES', {
  maximumFractionDigits: 0,
  useGrouping: 'always',
});

function n(value) {
  const parsed = Number(value);
  return Number.isFinite(parsed) ? parsed : 0;
}

function fmtInt(value) {
  return intFmt.format(Math.round(n(value)));
}

function fmtDec(value, digits = 2) {
  return new Intl.NumberFormat('es-ES', {
    minimumFractionDigits: digits,
    maximumFractionDigits: digits,
    useGrouping: 'always',
  }).format(n(value));
}

function fmtDuration(minutes) {
  const total = Math.max(0, Math.round(n(minutes)));
  if (total < 60) return `${total} min`;
  const hours = Math.floor(total / 60);
  const rest = total % 60;
  return rest ? `${hours} h ${rest} min` : `${hours} h`;
}

function today() {
  const date = new Date();
  return [
    date.getFullYear(),
    String(date.getMonth() + 1).padStart(2, '0'),
    String(date.getDate()).padStart(2, '0'),
  ].join('-');
}

function mdCell(value) {
  return String(value ?? '').replace(/\|/g, '\\|').replace(/\r?\n/g, ' ');
}

function parseArgs(argv) {
  const args = { _: [] };
  for (let i = 0; i < argv.length; i += 1) {
    const token = argv[i];
    if (!token.startsWith('--')) {
      args._.push(token);
      continue;
    }
    const body = token.slice(2);
    const eq = body.indexOf('=');
    if (eq >= 0) {
      args[body.slice(0, eq)] = body.slice(eq + 1);
    } else if (argv[i + 1] && !argv[i + 1].startsWith('--')) {
      args[body] = argv[i + 1];
      i += 1;
    } else {
      args[body] = true;
    }
  }
  return args;
}

function warn(message) {
  console.error(`⚠️  ${message}`);
}

function fail(message) {
  console.error(`❌ ${message}`);
  process.exit(1);
}

function git(args) {
  const result = spawnSync('git', args, {
    cwd: ROOT,
    encoding: 'utf8',
    maxBuffer: 64 * 1024 * 1024,
  });
  if (result.status !== 0) return null;
  return result.stdout.trim();
}

function exists(file) {
  return fs.existsSync(file);
}

function normalizeDir(dir) {
  return path.resolve(dir).replace(/\\/g, '/').replace(/\/+$/, '').toLowerCase();
}

function ensureMetricsDir() {
  fs.mkdirSync(STATE_DIR, { recursive: true });
  const gitignore = path.join(METRICS_DIR, '.gitignore');
  const wanted = '.state/\n';
  if (!exists(gitignore)) {
    fs.writeFileSync(gitignore, wanted, 'utf8');
  } else {
    const current = fs.readFileSync(gitignore, 'utf8');
    if (!current.split(/\r?\n/).includes('.state/')) {
      fs.writeFileSync(gitignore, `${current.replace(/\s*$/, '')}\n${wanted}`, 'utf8');
    }
  }
}

function statePath(spec) {
  return path.join(STATE_DIR, `${spec}.json`);
}

function loadState(spec) {
  const file = statePath(spec);
  if (!exists(file)) return null;
  try {
    return JSON.parse(fs.readFileSync(file, 'utf8'));
  } catch {
    return null;
  }
}

function saveState(spec, state) {
  ensureMetricsDir();
  fs.writeFileSync(statePath(spec), `${JSON.stringify(state, null, 2)}\n`, 'utf8');
}

function normalizeSpec(value) {
  return String(value || '')
    .replace(/\\/g, '/')
    .replace(/^specs\//, '')
    .replace(/\.md$/i, '')
    .trim();
}

function findSpecFile(spec) {
  const specsDir = path.join(ROOT, 'specs');
  if (!exists(specsDir)) return null;
  const wanted = normalizeSpec(spec);
  if (!wanted) return null;
  const files = fs
    .readdirSync(specsDir)
    .filter((file) => file.toLowerCase().endsWith('.md'))
    .sort();
  const lower = wanted.toLowerCase();
  const exact = files.find((file) => file.replace(/\.md$/i, '').toLowerCase() === lower);
  if (exact) return path.join(specsDir, exact);
  const byPrefix = files.filter((file) => file.toLowerCase().startsWith(`${lower}-`));
  if (byPrefix.length === 1) return path.join(specsDir, byPrefix[0]);
  const byNumber = files.filter((file) => file.toLowerCase().startsWith(lower));
  if (byNumber.length === 1) return path.join(specsDir, byNumber[0]);
  const bySlug = files.filter((file) => file.toLowerCase().includes(lower));
  if (bySlug.length === 1) return path.join(specsDir, bySlug[0]);
  return null;
}

function stripAccents(value) {
  return String(value)
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .toLowerCase();
}

function readSpecMetadata(specFile) {
  if (!specFile || !exists(specFile)) return {};
  const text = fs.readFileSync(specFile, 'utf8');

  const grab = (labels) => {
    const wanted = labels.map(stripAccents);
    for (const line of text.split(/\r?\n/)) {
      const normalized = stripAccents(line);
      for (const label of wanted) {
        const marker = `**${label}:`;
        const index = normalized.indexOf(marker);
        if (index < 0) continue;
        const tail = line.slice(index + marker.length);
        const value = tail.replace(/^\s*\*{0,2}\s*/, '').trim();
        if (value) return value;
      }
    }
    return '';
  };

  return {
    titulo: (text.match(/^#\s+(.+)$/m) || [])[1]?.trim() || '',
    estado: grab(['Estado', 'Status', 'État', 'Stato']),
    epic: grab(['Épica', 'Epica', 'Epic', 'Épico']),
    prioridad: grab(['Prioridad', 'Priority', 'Priorité', 'Priorita']),
    objetivo: grab(['Objetivo', 'Objective', 'Objectif']),
  };
}

function projectName() {
  for (const file of ['package.json', 'pubspec.yaml', 'pom.xml', 'build.gradle', 'go.mod']) {
    if (!exists(path.join(ROOT, file))) continue;
    try {
      if (file === 'package.json') {
        const pkg = JSON.parse(fs.readFileSync(path.join(ROOT, file), 'utf8'));
        if (pkg.name) return pkg.name;
      }
      if (file === 'pubspec.yaml') {
        const match = fs
          .readFileSync(path.join(ROOT, file), 'utf8')
          .match(/^name:\s*(.+)$/m);
        if (match) return match[1].trim();
      }
    } catch {
      // seguimos con el nombre de la carpeta
    }
  }
  return path.basename(ROOT);
}

function currentBranch() {
  return git(['branch', '--show-current']) || '';
}

function currentSessionId(args) {
  return (
    args.session ||
    process.env.OPENCODE_SESSION_ID ||
    (args['session-id'] ? String(args['session-id']) : '') ||
    ''
  );
}

function findOpencodeDb() {
  const candidates = [];
  if (process.env.OPENCODE_DB) candidates.push(process.env.OPENCODE_DB);
  if (process.env.XDG_DATA_HOME) {
    candidates.push(path.join(process.env.XDG_DATA_HOME, 'opencode', 'opencode.db'));
  }
  candidates.push(path.join(os.homedir(), '.local', 'share', 'opencode', 'opencode.db'));
  if (process.platform === 'win32') {
    if (process.env.LOCALAPPDATA) {
      candidates.push(path.join(process.env.LOCALAPPDATA, 'opencode', 'opencode.db'));
    }
    if (process.env.APPDATA) {
      candidates.push(path.join(process.env.APPDATA, 'opencode', 'opencode.db'));
    }
  }
  if (process.platform === 'darwin') {
    candidates.push(
      path.join(os.homedir(), 'Library', 'Application Support', 'opencode', 'opencode.db'),
    );
  }
  return candidates.find((candidate) => exists(candidate)) || null;
}

function sessionSnapshot(row) {
  return {
    input: n(row.tokens_input),
    output: n(row.tokens_output),
    reasoning: n(row.tokens_reasoning),
    cacheRead: n(row.tokens_cache_read),
    cacheWrite: n(row.tokens_cache_write),
    cost: n(row.cost),
  };
}

function sessionLabel(row) {
  try {
    const model = JSON.parse(row.model || '{}');
    if (model.providerID && model.id) return `${model.providerID}/${model.id}`;
    if (model.id) return model.id;
  } catch {
    // sin modelo identificable
  }
  return '';
}

async function readSessionRows(ids, since) {
  const dbPath = findOpencodeDb();
  if (!dbPath) {
    throw new Error(
      'No encontré opencode.db. Usá --input/--output/--cache-read/--cache-write o definí OPENCODE_DB.',
    );
  }

  let DatabaseSync;
  try {
    ({ DatabaseSync } = await import('node:sqlite'));
  } catch {
    throw new Error(
      'Tu Node no expone node:sqlite (requiere Node >= 22.5). Actualizá Node o pasá los tokens con --input/--output.',
    );
  }

  const db = new DatabaseSync(dbPath, { readOnly: true });
  try {
    db.exec('PRAGMA busy_timeout = 3000');
    const rows = new Map();

    for (const id of ids.filter(Boolean)) {
      const row = db.prepare('select * from session_v2 where id = ?').get(id);
      if (row) rows.set(row.id, row);
    }

    if (since) {
      const recent = db
        .prepare('select * from session_v2 where time_created >= ?')
        .all(Math.floor(since));
      const root = normalizeDir(ROOT);
      for (const row of recent) {
        if (!row.directory) continue;
        if (normalizeDir(row.directory) === root) rows.set(row.id, row);
      }
    }

    return { rows: [...rows.values()], dbPath };
  } finally {
    db.close();
  }
}

function detectBase() {
  for (const ref of ['origin/HEAD', 'main', 'master', 'develop']) {
    const verify = git(['rev-parse', '--verify', '--quiet', ref]);
    if (!verify) continue;
    const mergeBase = git(['merge-base', 'HEAD', ref]);
    if (mergeBase) return mergeBase;
  }
  return git(['rev-parse', 'HEAD']) || '';
}

function countLines(file) {
  try {
    const buffer = fs.readFileSync(path.join(ROOT, file));
    if (buffer.includes(0)) return 0;
    const text = buffer.toString('utf8');
    if (!text) return 0;
    return text.split(/\r?\n/).length - (text.endsWith('\n') ? 1 : 0);
  } catch {
    return 0;
  }
}

function isMetricsPath(file) {
  const normalized = String(file).replace(/\\/g, '/');
  // Las métricas viven en references/metrics/ y los reportes de cambios en
  // references/reports/; ambos se excluyen para que no inflen archivos ni LOC
  // del spec. Se mantienen las rutas sin `references/` por compatibilidad.
  return (
    normalized === 'metrics' ||
    normalized.startsWith('metrics/') ||
    normalized === 'references/metrics' ||
    normalized.startsWith('references/metrics/') ||
    normalized === 'reports' ||
    normalized.startsWith('reports/') ||
    normalized === 'references/reports' ||
    normalized.startsWith('references/reports/')
  );
}

const SKIP_DIRS = new Set([
  '.git',
  'node_modules',
  'target',
  'build',
  'dist',
  'out',
  '.gradle',
  '.idea',
  '.vscode',
  'metrics',
  '.state',
]);

function countTestCases(absolutePath) {
  try {
    const text = fs.readFileSync(absolutePath, 'utf8');
    let total = 0;
    for (const row of text.split(/\r?\n/)) {
      if (TEST_CASE_RES.some((regex) => regex.test(`+${row}`))) total += 1;
    }
    return total;
  } catch {
    return 0;
  }
}

function statsFromFilesystem(start, end) {
  const stats = {
    filesCreated: 0,
    filesModified: 0,
    filesDeleted: 0,
    testFiles: 0,
    testCases: 0,
    locAdd: 0,
    locDel: 0,
  };

  if (!start || !end || end < start) return stats;

  const lower = start - 1000;
  const upper = end + 1000;

  const walk = (directory) => {
    let entries;
    try {
      entries = fs.readdirSync(directory, { withFileTypes: true });
    } catch {
      return;
    }
    for (const entry of entries) {
      if (entry.isSymbolicLink()) continue;
      const absolute = path.join(directory, entry.name);
      const relative = path.relative(ROOT, absolute).replace(/\\/g, '/');
      if (entry.isDirectory()) {
        if (SKIP_DIRS.has(entry.name)) continue;
        walk(absolute);
        continue;
      }
      if (!entry.isFile()) continue;

      let stat;
      try {
        stat = fs.statSync(absolute);
      } catch {
        continue;
      }
      const birth = stat.birthtimeMs || stat.ctimeMs || 0;
      const created = birth >= lower && birth <= upper;
      const modified = stat.mtimeMs >= lower && stat.mtimeMs <= upper;
      if (!created && !modified) continue;
      if (isMetricsPath(relative)) continue;

      if (created) {
        stats.filesCreated += 1;
        if (TEST_FILE_RE.test(relative)) stats.testFiles += 1;
        const lines = countLines(relative);
        stats.locAdd += lines;
        if (lines > 0) stats.testCases += countTestCases(absolute);
      } else {
        stats.filesModified += 1;
      }
    }
  };

  walk(ROOT);
  return stats;
}

function gitStats(base, window) {
  const stats = {
    filesCreated: 0,
    filesModified: 0,
    filesDeleted: 0,
    testFiles: 0,
    testCases: 0,
    locAdd: 0,
    locDel: 0,
  };

  const hasGit = git(['rev-parse', '--is-inside-work-tree']) === 'true';
  if (!base || !hasGit) {
    const fallback = statsFromFilesystem(window?.start, window?.end);
    if (fallback.filesCreated || fallback.filesModified) {
      warn(
        'Sin diff de git: conté archivos, LOC y tests por fecha de creación/modificación dentro de la sesión.',
      );
      return fallback;
    }
    if (!base) {
      warn('No hay commit base para calcular el diff; archivos y LOC quedan en 0.');
    }
    return stats;
  }

  const nameStatus = git(['diff', '--name-status', '-M', base]);
  if (nameStatus !== null) {
    for (const line of nameStatus.split('\n').filter(Boolean)) {
      const [rawStatus, first, second] = line.split('\t');
      const status = rawStatus?.[0];
      const file = status === 'R' || status === 'C' ? second : first;
      if (!file || isMetricsPath(file)) continue;
      if (status === 'A') {
        stats.filesCreated += 1;
        if (TEST_FILE_RE.test(file)) stats.testFiles += 1;
      } else if (status === 'D') {
        stats.filesDeleted += 1;
      } else {
        stats.filesModified += 1;
      }
    }
  }

  const numstat = git(['diff', '--numstat', '-M', base]);
  if (numstat !== null) {
    for (const line of numstat.split('\n').filter(Boolean)) {
      const [add, del, file] = line.split('\t');
      if (!file || isMetricsPath(file)) continue;
      if (add === '-' || del === '-') continue;
      stats.locAdd += n(add);
      stats.locDel += n(del);
    }
  }

  const untracked = git(['ls-files', '--others', '--exclude-standard']);
  if (untracked !== null) {
    for (const file of untracked.split('\n').filter(Boolean)) {
      if (isMetricsPath(file)) continue;
      stats.filesCreated += 1;
      if (TEST_FILE_RE.test(file)) stats.testFiles += 1;
      const lines = countLines(file);
      stats.locAdd += lines;
      if (lines > 0) {
        try {
          const text = fs.readFileSync(path.join(ROOT, file), 'utf8');
          for (const row of text.split(/\r?\n/)) {
            if (TEST_CASE_RES.some((regex) => regex.test(`+${row}`))) stats.testCases += 1;
          }
        } catch {
          // archivo ilegible: no cuenta tests
        }
      }
    }
  }

  const addedDiff = git(['diff', '--unified=0', '--no-color', base]);
  if (addedDiff !== null) {
    let currentFile = null;
    for (const line of addedDiff.split('\n')) {
      if (line.startsWith('+++ ')) {
        const target = line.slice(4).trim();
        if (target === '/dev/null') {
          currentFile = null;
        } else {
          currentFile = target.replace(/^b\//, '');
          if (isMetricsPath(currentFile)) currentFile = null;
        }
        continue;
      }
      if (!currentFile || !line.startsWith('+') || line.startsWith('+++')) continue;
      if (TEST_CASE_RES.some((regex) => regex.test(line))) stats.testCases += 1;
    }
  }

  return stats;
}

function csvEscape(value) {
  const text = String(value ?? '');
  if (/[",\r\n]/.test(text)) return `"${text.replace(/"/g, '""')}"`;
  return text;
}

function parseCsv(text) {
  const clean = text.replace(/^\uFEFF/, '');
  const rows = [];
  let row = [];
  let field = '';
  let quoted = false;

  for (let i = 0; i < clean.length; i += 1) {
    const char = clean[i];
    if (quoted) {
      if (char === '"' && clean[i + 1] === '"') {
        field += '"';
        i += 1;
      } else if (char === '"') {
        quoted = false;
      } else {
        field += char;
      }
    } else if (char === '"') {
      quoted = true;
    } else if (char === ',') {
      row.push(field);
      field = '';
    } else if (char === '\n') {
      row.push(field);
      rows.push(row);
      row = [];
      field = '';
    } else if (char !== '\r') {
      field += char;
    }
  }
  if (field.length || row.length) {
    row.push(field);
    rows.push(row);
  }

  if (!rows.length) return [];
  const header = rows[0].map((name) => name.trim());
  return rows
    .slice(1)
    .filter((cells) => cells.some((cell) => cell.trim() !== ''))
    .map((cells) => {
      const record = {};
      header.forEach((name, index) => {
        record[name] = cells[index] ?? '';
      });
      return record;
    });
}

function readRows() {
  if (!exists(CSV_PATH)) return [];
  return parseCsv(fs.readFileSync(CSV_PATH, 'utf8'));
}

function writeRows(rows) {
  ensureMetricsDir();
  const lines = [CSV_COLUMNS.join(',')];
  for (const row of rows) {
    lines.push(CSV_COLUMNS.map((column) => csvEscape(row[column] ?? '')).join(','));
  }
  fs.writeFileSync(CSV_PATH, `\uFEFF${lines.join('\n')}\n`, 'utf8');
}

function groupBy(rows, keyFn) {
  const groups = new Map();
  for (const row of rows) {
    const key = keyFn(row);
    if (!groups.has(key)) groups.set(key, []);
    groups.get(key).push(row);
  }
  return groups;
}

function sum(rows, column) {
  return rows.reduce((total, row) => total + n(row[column]), 0);
}

function unique(rows, column) {
  return new Set(rows.map((row) => String(row[column] || '').trim()).filter(Boolean));
}

function renderDashboard(rows) {
  const now = new Date();
  const stamps = `${now.toLocaleDateString('es-ES')} ${now.toLocaleTimeString('es-ES', {
    hour: '2-digit',
    minute: '2-digit',
  })}`;

  if (!rows.length) {
    return [
      '# Engineering Metrics Dashboard',
      '',
      `> Actualizado: ${stamps}`,
      '> Fuente: `references/metrics/spec-metrics.csv`',
      '',
      '_Todavía no hay specs registrados._',
      '',
      'Ejecutá `node .agents/skills/opencode-metrics-spec/scripts/spec-metrics.mjs finish --spec NN-slug`.',
      '',
    ].join('\n');
  }

  const totalTokens = sum(rows, 'total_tokens');
  const totalInput = sum(rows, 'input_tokens');
  const totalOutput = sum(rows, 'output_tokens');
  const totalCacheRead = sum(rows, 'cache_read_tokens');
  const totalCacheWrite = sum(rows, 'cache_write_tokens');
  const totalCost = sum(rows, 'costo_usd');
  const locAdd = sum(rows, 'loc_agregadas');
  const locDel = sum(rows, 'loc_eliminadas');
  const tests = sum(rows, 'test_generados');
  const filesCreated = sum(rows, 'archivos_creados');
  const filesModified = sum(rows, 'archivos_modificados');
  const averageTokens = totalTokens / rows.length;
  const locPer1k = totalTokens > 0 ? locAdd / (totalTokens / 1000) : 0;
  const testsPer100Loc = locAdd > 0 ? (tests / locAdd) * 100 : 0;
  const specs = unique(rows, 'spec');
  const epics = unique(rows, 'epic');
  const branches = unique(rows, 'rama');
  const avgMinutes = sum(rows, 'duracion_min') / rows.length;

  const sorted = [...rows].sort((a, b) => n(b.total_tokens) - n(a.total_tokens));
  const top = sorted.slice(0, 10);
  const max = sorted[0];
  const min = sorted[sorted.length - 1];

  const epicGroups = groupBy(rows, (row) => String(row.epic || 'Sin épica').trim() || 'Sin épica');

  const out = [];
  out.push('# Engineering Metrics Dashboard', '');
  out.push(`> Actualizado: ${stamps}`);
  out.push('> Fuente: `references/metrics/spec-metrics.csv`', '');

  out.push('## Resumen general', '');
  out.push('| Métrica | Valor |');
  out.push('| --- | ---: |');
  out.push(`| Tareas registradas | ${fmtInt(rows.length)} |`);
  out.push(`| Specs completados | ${fmtInt(specs.size)} |`);
  out.push(`| Épicas trabajadas | ${fmtInt(epics.size)} |`);
  out.push(`| Ramas | ${fmtInt(branches.size)} |`);
  out.push(`| Duración promedio | ${fmtDuration(avgMinutes)} |`);
  out.push('');

  out.push('## Tokens', '');
  out.push('| Métrica | Valor |');
  out.push('| --- | ---: |');
  out.push(`| Input | ${fmtInt(totalInput)} |`);
  out.push(`| Output | ${fmtInt(totalOutput)} |`);
  out.push(`| **Total (input + output)** | **${fmtInt(totalTokens)}** |`);
  out.push(`| Caché leída | ${fmtInt(totalCacheRead)} |`);
  out.push(`| Caché escrita | ${fmtInt(totalCacheWrite)} |`);
  out.push(`| Procesados con caché | ${fmtInt(totalInput + totalOutput + totalCacheRead + totalCacheWrite)} |`);
  out.push(`| Promedio por tarea | ${fmtInt(averageTokens)} |`);
  out.push(`| Costo acumulado | $${fmtDec(totalCost, 4)} |`);
  out.push(`| Mayor consumo | ${mdCell(max.spec)} (${fmtInt(max.total_tokens)}) |`);
  out.push(`| Menor consumo | ${mdCell(min.spec)} (${fmtInt(min.total_tokens)}) |`);
  out.push('');

  out.push('## Productividad', '');
  out.push('| Métrica | Valor |');
  out.push('| --- | ---: |');
  out.push(`| LOC agregadas | ${fmtInt(locAdd)} |`);
  out.push(`| LOC eliminadas | ${fmtInt(locDel)} |`);
  out.push(`| LOC netas | ${fmtInt(locAdd - locDel)} |`);
  out.push(`| LOC por 1.000 tokens | ${fmtDec(locPer1k)} |`);
  out.push(`| Archivos creados | ${fmtInt(filesCreated)} |`);
  out.push(`| Archivos modificados | ${fmtInt(filesModified)} |`);
  out.push(`| Tests generados | ${fmtInt(tests)} |`);
  out.push(`| Tests por 100 LOC | ${fmtDec(testsPer100Loc)} |`);
  out.push('');

  out.push('## Por épica', '');
  out.push('| Épica | Specs | Tokens | Promedio | LOC | Tests |');
  out.push('| --- | ---: | ---: | ---: | ---: | ---: |');
  for (const [epic, group] of [...epicGroups.entries()].sort(
    (a, b) => sum(b[1], 'total_tokens') - sum(a[1], 'total_tokens'),
  )) {
    const tokens = sum(group, 'total_tokens');
    out.push(
      `| ${mdCell(epic)} | ${fmtInt(unique(group, 'spec').size)} | ${fmtInt(tokens)} | ${fmtInt(
        tokens / group.length,
      )} | ${fmtInt(sum(group, 'loc_agregadas'))} | ${fmtInt(sum(group, 'test_generados'))} |`,
    );
  }
  out.push('');

  out.push('## Top 10 tareas por consumo', '');
  out.push('| # | Spec | Épica | Input | Output | Total | LOC | Tests | Duración |');
  out.push('| ---: | --- | --- | ---: | ---: | ---: | ---: | ---: | ---: |');
  top.forEach((row, index) => {
    out.push(
      `| ${index + 1} | ${mdCell(row.spec)} | ${mdCell(row.epic)} | ${fmtInt(
        row.input_tokens,
      )} | ${fmtInt(row.output_tokens)} | ${fmtInt(row.total_tokens)} | ${fmtInt(
        row.loc_agregadas,
      )} | ${fmtInt(row.test_generados)} | ${fmtDuration(row.duracion_min)} |`,
    );
  });
  out.push('');

  out.push('## Últimos specs', '');
  out.push('| Fecha | Spec | Rama | Estado | Tokens | LOC | Tests |');
  out.push('| --- | --- | --- | --- | ---: | ---: | ---: |');
  for (const row of [...rows].sort((a, b) => String(b.fecha).localeCompare(String(a.fecha))).slice(0, 10)) {
    out.push(
      `| ${mdCell(row.fecha)} | ${mdCell(row.spec)} | ${mdCell(row.rama)} | ${mdCell(
        row.estado,
      )} | ${fmtInt(row.total_tokens)} | ${fmtInt(row.loc_agregadas)} | ${fmtInt(
        row.test_generados,
      )} |`,
    );
  }
  out.push('');

  return `${out.join('\n')}`;
}

function renderMonthly(rows) {
  const now = new Date();
  const stamps = `${now.toLocaleDateString('es-ES')} ${now.toLocaleTimeString('es-ES', {
    hour: '2-digit',
    minute: '2-digit',
  })}`;

  if (!rows.length) {
    return [
      '# Resumen mensual',
      '',
      `> Actualizado: ${stamps}`,
      '',
      '_Sin datos todavía._',
      '',
    ].join('\n');
  }

  const groups = [...groupBy(rows, (row) => String(row.fecha).slice(0, 7)).entries()].sort((a, b) =>
    b[0].localeCompare(a[0]),
  );

  const out = ['# Resumen mensual', '', `> Actualizado: ${stamps}`, ''];

  out.push('## Acumulado por mes', '');
  out.push(
    '| Mes | Tareas | Input | Output | Total | Promedio/tarea | LOC | Tests | Duración prom. | Costo |',
  );
  out.push('| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |');
  for (const [month, group] of groups) {
    const tokens = sum(group, 'total_tokens');
    out.push(
      `| ${month} | ${fmtInt(group.length)} | ${fmtInt(sum(group, 'input_tokens'))} | ${fmtInt(
        sum(group, 'output_tokens'),
      )} | ${fmtInt(tokens)} | ${fmtInt(tokens / group.length)} | ${fmtInt(
        sum(group, 'loc_agregadas'),
      )} | ${fmtInt(sum(group, 'test_generados'))} | ${fmtDuration(
        sum(group, 'duracion_min') / group.length,
      )} | $${fmtDec(sum(group, 'costo_usd'), 4)} |`,
    );
  }
  out.push('');

  const currentMonth = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}`;
  const detail = rows.filter((row) => String(row.fecha).startsWith(currentMonth));
  out.push(`## Detalle ${currentMonth}`, '');
  if (!detail.length) {
    out.push('_Sin specs registrados este mes._', '');
  } else {
    out.push('| Fecha | Spec | Épica | Tokens | LOC | Tests | Duración | Estado |');
    out.push('| --- | --- | --- | ---: | ---: | ---: | ---: | --- |');
    for (const row of [...detail].sort((a, b) => String(a.fecha).localeCompare(String(b.fecha)))) {
      out.push(
        `| ${mdCell(row.fecha)} | ${mdCell(row.spec)} | ${mdCell(row.epic)} | ${fmtInt(
          row.total_tokens,
        )} | ${fmtInt(row.loc_agregadas)} | ${fmtInt(row.test_generados)} | ${fmtDuration(
          row.duracion_min,
        )} | ${mdCell(row.estado)} |`,
      );
    }
    out.push('');
  }

  return out.join('\n');
}

function buildRow({ project, spec, branch, meta, args, stats, tokens, duration, sessions }) {
  return {
    fecha: today(),
    proyecto: project,
    spec,
    rama: branch,
    epic: args.epic || meta.epic || '',
    tipo: args.tipo || 'feature',
    prioridad: args.prioridad || meta.prioridad || '',
    modelo: sessions.model || '',
    sesiones: sessions.count,
    input_tokens: Math.round(tokens.input),
    output_tokens: Math.round(tokens.output),
    reasoning_tokens: Math.round(tokens.reasoning),
    cache_read_tokens: Math.round(tokens.cacheRead),
    cache_write_tokens: Math.round(tokens.cacheWrite),
    total_tokens: Math.round(tokens.input + tokens.output),
    costo_usd: Number(tokens.cost.toFixed(6)),
    archivos_creados: stats.filesCreated,
    archivos_modificados: stats.filesModified,
    archivos_eliminados: stats.filesDeleted,
    test_files: stats.testFiles,
    test_generados: stats.testCases,
    loc_agregadas: stats.locAdd,
    loc_eliminadas: stats.locDel,
    duracion_min: Number(duration.toFixed(1)),
    estado: args.estado || 'completado',
    observaciones: args.observaciones || '',
  };
}

async function cmdStart(args) {
  const rawSpec = args.spec || args._[0];
  if (!rawSpec) fail('Falta --spec (por ejemplo: --spec 01-mvp-arkanoid).');
  const spec = normalizeSpec(rawSpec);
  const specFile = args['spec-file'] || findSpecFile(spec);
  const existing = loadState(spec);
  if (existing && !args.force) {
    console.log(`ℹ️  Ya existe una línea base para ${spec}.`);
    console.log(`   Inicio: ${new Date(existing.started_at).toLocaleString('es-ES')}`);
    console.log(`   Base git: ${existing.base_commit || '(sin commit)'}`);
    console.log('   Usá --force para reiniciarla.');
    return;
  }

  const base = args.base ? git(['rev-parse', args.base]) || args.base : detectBase();
  const sessionId = currentSessionId(args);
  const startedAt = Date.now();

  let sessionEntry = null;
  let model = '';
  if (sessionId) {
    try {
      const { rows } = await readSessionRows([sessionId], null);
      const row = rows.find((candidate) => candidate.id === sessionId);
      if (row) {
        sessionEntry = sessionSnapshot(row);
        model = sessionLabel(row);
      }
    } catch (error) {
      warn(`No pude leer la sesión de OpenCode: ${error.message}`);
    }
  }

  const state = {
    spec,
    spec_file: specFile ? path.relative(ROOT, specFile).replace(/\\/g, '/') : '',
    branch: currentBranch(),
    base_commit: base,
    started_at: startedAt,
    session_id: sessionId,
    sessions: sessionEntry ? { [sessionId]: sessionEntry } : {},
    model,
  };

  saveState(spec, state);

  console.log('✅ Línea base de métricas creada.');
  console.log(`   Spec:     ${spec}`);
  console.log(`   Archivo:  ${state.spec_file || '(no encontrado)'}`);
  console.log(`   Rama:     ${state.branch || '(sin rama)'}`);
  console.log(`   Base git: ${base ? base.slice(0, 12) : '(sin git)'}`);
  console.log(`   Sesión:   ${sessionId || '(sin OPENCODE_SESSION_ID)'}`);
  console.log(`   Modelo:   ${model || '(desconocido)'}`);
}

/**
 * Suma los tokens de la sesión base y de toda sesión creada después de `start`
 * en el mismo directorio: subagentes (spec-verifier) y sesiones manuales de
 * verificación entran sin necesidad de registrar su id.
 */
async function sumSessions(state, currentId = '') {
  const ids = [...Object.keys(state?.sessions || {}), state?.session_id, state?.finished_session, currentId]
    .filter(Boolean);
  const startedAt = state?.started_at || Date.now();
  const tokens = { input: 0, output: 0, reasoning: 0, cacheRead: 0, cacheWrite: 0, cost: 0 };
  let included = 0;
  let model = state?.model || '';
  let end = 0;

  const { rows } = await readSessionRows(ids, startedAt);
  for (const [id, snapshot] of Object.entries(state?.sessions || {})) {
    const row = rows.find((candidate) => candidate.id === id);
    if (!row) {
      warn(`La sesión base ${id} ya no está en opencode.db; no se puede calcular su delta.`);
      continue;
    }
    const current = sessionSnapshot(row);
    tokens.input += Math.max(0, current.input - snapshot.input);
    tokens.output += Math.max(0, current.output - snapshot.output);
    tokens.reasoning += Math.max(0, current.reasoning - snapshot.reasoning);
    tokens.cacheRead += Math.max(0, current.cacheRead - snapshot.cacheRead);
    tokens.cacheWrite += Math.max(0, current.cacheWrite - snapshot.cacheWrite);
    tokens.cost += Math.max(0, current.cost - snapshot.cost);
    included += 1;
    end = Math.max(end, n(row.time_updated));
    if (!model) model = sessionLabel(row);
  }

  for (const row of rows) {
    if (state?.sessions?.[row.id]) continue;
    const isCurrent = row.id === currentId;
    if (isCurrent && n(row.time_created) < startedAt - 1000) {
      warn(
        `La sesión actual ${row.id} empezó antes de la línea base; sumo su acumulado completo (aproximado).`,
      );
    }
    const snapshot = sessionSnapshot(row);
    tokens.input += snapshot.input;
    tokens.output += snapshot.output;
    tokens.reasoning += snapshot.reasoning;
    tokens.cacheRead += snapshot.cacheRead;
    tokens.cacheWrite += snapshot.cacheWrite;
    tokens.cost += snapshot.cost;
    included += 1;
    end = Math.max(end, n(row.time_updated));
    if (!model) model = sessionLabel(row);
  }

  if (currentId && !rows.some((row) => row.id === currentId)) {
    warn(`No encontré la sesión actual ${currentId} en opencode.db.`);
  }

  return { tokens, included, model, end };
}

async function sessionDelta(state) {
  return sumSessions(state, state?.finished_session || '');
}

function parseTimestamp(value) {
  if (value === undefined || value === null || value === '') return 0;
  if (/^\d+$/.test(String(value))) return n(value);
  const parsed = Date.parse(String(value));
  return Number.isFinite(parsed) ? parsed : 0;
}

async function cmdFinish(args) {
  const rawSpec = args.spec || args._[0];
  if (!rawSpec) fail('Falta --spec (por ejemplo: --spec 01-mvp-arkanoid).');
  const spec = normalizeSpec(rawSpec);

  const state = loadState(spec);
  const explicitSpecFile = args['spec-file'];
  const stateSpecFile = state?.spec_file ? path.resolve(ROOT, state.spec_file) : null;
  const specFile = explicitSpecFile
    ? path.resolve(ROOT, explicitSpecFile)
    : stateSpecFile || findSpecFile(spec);
  const meta = readSpecMetadata(specFile);

  let base = args.base ? git(['rev-parse', args.base]) || args.base : state?.base_commit;
  if (!base) {
    base = detectBase();
    if (state) {
      warn('La línea base no tiene commit (repo sin git); archivos y LOC se calculan por fecha.');
    } else {
      warn(`Sin línea base para ${spec}; uso ${base ? base.slice(0, 12) : '(ninguna)'} como base del diff.`);
      warn('Para la próxima, ejecutá `start` al comenzar la implementación.');
    }
  }

  const branch = state?.branch || currentBranch();
  const startedAt = state?.started_at || Date.now();
  const duration =
    args.duration !== undefined
      ? n(args.duration)
      : Math.max(0, (Date.now() - startedAt) / 60000);
  const sessionId = currentSessionId(args);
  const manualTokens = args.input !== undefined || args.output !== undefined;

  let tokens = {
    input: 0,
    output: 0,
    reasoning: 0,
    cacheRead: 0,
    cacheWrite: 0,
    cost: 0,
  };
  let sessionsInfo = { count: 0, model: state?.model || '' };
  let tokenSource = 'db';

  if (manualTokens) {
    tokens = {
      input: n(args.input),
      output: n(args.output),
      reasoning: n(args.reasoning),
      cacheRead: n(args['cache-read']),
      cacheWrite: n(args['cache-write']),
      cost: n(args.cost),
    };
    sessionsInfo.count = 1;
  } else {
    try {
      const delta = await sumSessions(state, sessionId);
      tokens = delta.tokens;
      sessionsInfo = { count: delta.included, model: delta.model || sessionsInfo.model };
      if (!delta.included) {
        warn('No se pudo atribuir ninguna sesión al spec; los tokens quedaron en 0.');
        warn('Pasá --input/--output o ejecutá `start` dentro de la sesión donde implementás.');
      }
    } catch (error) {
      tokenSource = 'error';
      warn(`No pude leer tokens de OpenCode: ${error.message}`);
      warn('El spec no se cerrará sin tokens. Pasá --input/--output con números reales.');
    }
  }

  if (!manualTokens && tokenSource === 'error' && !args['allow-zero']) {
    fail(
      'No pude leer tokens reales de OpenCode. No cierro el spec con métricas en 0.\n' +
        '   Opciones:\n' +
        '   1. Repetí `start` dentro de la sesión de implementación y después `finish`.\n' +
        '   2. Pasá los números reales: --input N --output N [--cache-read N --cache-write N --cost N].\n' +
        '   3. Si de verdad corresponde 0, agregá --allow-zero.',
    );
  }

  if (!manualTokens && tokenSource === 'db' && sessionsInfo.count === 0 && !args['allow-zero']) {
    fail(
      'No pude atribuir ninguna sesión de OpenCode a este spec. No cierro con 0 tokens.\n' +
        '   Verificá OPENCODE_SESSION_ID o pasá --session <ses_id>; si no hay acceso a opencode.db,\n' +
        '   usá --input N --output N con números reales (o --allow-zero si corresponde).',
    );
  }

  if (!manualTokens && sessionsInfo.count > 0 && tokens.input + tokens.output === 0) {
    warn(
      'El delta de tokens es 0. Si ejecutaste `start` y `finish` en el mismo paso, repetí `finish` para capturar el consumo real.',
    );
  }

  const stats = gitStats(base, { start: startedAt, end: Date.now() });
  const project = projectName();
  const row = buildRow({
    project,
    spec,
    branch,
    meta,
    args,
    stats,
    tokens,
    duration,
    sessions: sessionsInfo,
  });

  if (args['dry-run']) {
    console.log(JSON.stringify(row, null, 2));
    return;
  }

  const rows = readRows();
  const index = rows.findIndex(
    (candidate) => String(candidate.spec) === spec && String(candidate.rama) === String(branch),
  );
  if (index >= 0) {
    rows[index] = row;
    warn(`La fila de ${spec} ya existía; la reemplacé.`);
  } else {
    rows.push(row);
  }

  writeRows(rows);
  fs.writeFileSync(DASHBOARD_PATH, renderDashboard(rows), 'utf8');
  fs.writeFileSync(MONTHLY_PATH, renderMonthly(rows), 'utf8');

  const aggregateTokens = rows.reduce((total, item) => total + n(item.total_tokens), 0);
  const aggregateLoc = rows.reduce((total, item) => total + n(item.loc_agregadas), 0);
  const averageTokens = rows.length ? aggregateTokens / rows.length : 0;

  console.log('');
  console.log('---');
  console.log('');
  console.log('TAREA FINALIZADA (SPEC)');
  console.log('');
  console.log(`Proyecto: ${project}`);
  console.log(`Spec:     ${spec}`);
  console.log(`Epic:     ${row.epic || '—'}`);
  console.log(`Rama:     ${branch || '—'}`);
  console.log(`Modelo:   ${row.modelo || '—'}`);
  console.log('');
  console.log(`Input tokens:    ${fmtInt(row.input_tokens)}`);
  console.log(`Output tokens:   ${fmtInt(row.output_tokens)}`);
  console.log(`Total tokens:    ${fmtInt(row.total_tokens)}`);
  console.log(`Cache leída:     ${fmtInt(row.cache_read_tokens)}`);
  console.log(`Cache escrita:   ${fmtInt(row.cache_write_tokens)}`);
  console.log(`Costo:           $${fmtDec(row.costo_usd, 4)}`);
  console.log('');
  console.log(`Archivos creados:    ${fmtInt(row.archivos_creados)}`);
  console.log(`Archivos modificados:${fmtInt(row.archivos_modificados)}`);
  console.log(`LOC agregadas:       ${fmtInt(row.loc_agregadas)}`);
  console.log(`LOC eliminadas:      ${fmtInt(row.loc_eliminadas)}`);
  console.log(`Test generados:      ${fmtInt(row.test_generados)} (en ${fmtInt(row.test_files)} archivos nuevos)`);
  console.log(`Duración:            ${fmtDuration(row.duracion_min)}`);
  console.log('');
  console.log(`Acumulado tokens: ${fmtInt(aggregateTokens)}`);
  console.log('');
  console.log(`Total specs:        ${fmtInt(rows.length)}`);
  console.log(`Total tokens:       ${fmtInt(aggregateTokens)}`);
  console.log(`Promedio tokens:    ${fmtInt(averageTokens)}`);
  console.log(`LOC totales:        ${fmtInt(aggregateLoc)}`);
  console.log('');
  console.log(`Filas actualizadas: ${CSV_PATH}`);
  console.log(`Dashboard:          ${DASHBOARD_PATH}`);
  console.log(`Resumen mensual:    ${MONTHLY_PATH}`);

  if (state) {
    saveState(spec, {
      ...state,
      finished_at: Date.now(),
      duration_min: row.duracion_min,
      finalized: false,
    });
    console.log('');
    console.log(
      `Línea base conservada para ${spec}: cuando termine la sesión, ejecutá ` +
        `\`finalize --spec ${spec}\` para registrar los tokens definitivos.`,
    );
  }
}

async function cmdFinalize(args) {
  const rawSpec = args.spec || args._[1];
  if (!rawSpec) fail('Falta --spec (por ejemplo: --spec 01-endpoint-bienvenida).');
  const spec = normalizeSpec(rawSpec);

  const state = loadState(spec);
  if (!state) {
    fail(`No hay línea base para ${spec}. Ejecutá start al comenzar y finish al cerrar.`);
  }

  const rows = readRows();
  const branch = state.branch || currentBranch();
  const index = rows.findIndex(
    (candidate) => String(candidate.spec) === spec && String(candidate.rama) === String(branch),
  );
  if (index < 0) {
    fail(`No hay fila de ${spec} en references/metrics/spec-metrics.csv. Ejecutá finish antes de finalize.`);
  }

  let delta;
  try {
    delta = await sessionDelta(state);
  } catch (error) {
    fail(
      `No pude leer los tokens definitivos de OpenCode: ${error.message}\n` +
        '   Corregí el acceso a opencode.db y volvé a ejecutar finalize.',
    );
  }

  const startedAt = state.started_at || 0;
  const finishedAt = state.finished_at || Date.now();
  const overrideEnd = parseTimestamp(args.end);
  const end = Math.max(finishedAt, delta.end || 0, overrideEnd);
  const stats = gitStats(state.base_commit || '', { start: startedAt, end });
  const duration =
    args.duration !== undefined
      ? n(args.duration)
      : n(state.duration_min ?? Math.max(0, (finishedAt - startedAt) / 60000));

  const previous = rows[index];
  const row = {
    ...previous,
    input_tokens: Math.round(delta.tokens.input),
    output_tokens: Math.round(delta.tokens.output),
    reasoning_tokens: Math.round(delta.tokens.reasoning),
    cache_read_tokens: Math.round(delta.tokens.cacheRead),
    cache_write_tokens: Math.round(delta.tokens.cacheWrite),
    total_tokens: Math.round(delta.tokens.input + delta.tokens.output),
    costo_usd: Number(delta.tokens.cost.toFixed(6)),
    archivos_creados: stats.filesCreated,
    archivos_modificados: stats.filesModified,
    archivos_eliminados: stats.filesDeleted,
    test_files: stats.testFiles,
    test_generados: stats.testCases,
    loc_agregadas: stats.locAdd,
    loc_eliminadas: stats.locDel,
    duracion_min: Number(duration.toFixed(1)),
    modelo: delta.model || previous.modelo,
    sesiones: delta.included || previous.sesiones,
  };

  rows[index] = row;
  writeRows(rows);
  fs.writeFileSync(DASHBOARD_PATH, renderDashboard(rows), 'utf8');
  fs.writeFileSync(MONTHLY_PATH, renderMonthly(rows), 'utf8');
  fs.rmSync(statePath(spec), { force: true });

  console.log('');
  console.log('---');
  console.log('');
  console.log('SPEC FINALIZADO (MÉTRICAS DEFINITIVAS)');
  console.log('');
  console.log(`Spec:     ${spec}`);
  console.log(`Rama:     ${branch || '—'}`);
  console.log(`Modelo:   ${row.modelo || '—'}`);
  console.log(`Sesiones: ${row.sesiones}`);
  console.log('');
  console.log(`Input tokens:    ${fmtInt(row.input_tokens)}`);
  console.log(`Output tokens:   ${fmtInt(row.output_tokens)}`);
  console.log(`Total tokens:    ${fmtInt(row.total_tokens)}`);
  console.log(`Cache leída:     ${fmtInt(row.cache_read_tokens)}`);
  console.log(`Cache escrita:   ${fmtInt(row.cache_write_tokens)}`);
  console.log(`Costo:           $${fmtDec(row.costo_usd, 4)}`);
  console.log('');
  console.log(`Archivos creados:     ${fmtInt(row.archivos_creados)}`);
  console.log(`Archivos modificados: ${fmtInt(row.archivos_modificados)}`);
  console.log(`LOC agregadas:        ${fmtInt(row.loc_agregadas)}`);
  console.log(`LOC eliminadas:       ${fmtInt(row.loc_eliminadas)}`);
  console.log(`Test generados:       ${fmtInt(row.test_generados)} (en ${fmtInt(row.test_files)} archivos nuevos)`);
  console.log(`Duración:             ${fmtDuration(row.duracion_min)}`);
  console.log('');
  console.log(`Fila actualizada: ${CSV_PATH}`);
  console.log(`Dashboard:        ${DASHBOARD_PATH}`);
  console.log(`Resumen mensual:  ${MONTHLY_PATH}`);
}

function cmdStatus() {
  const files = exists(STATE_DIR)
    ? fs.readdirSync(STATE_DIR).filter((file) => file.endsWith('.json'))
    : [];
  if (!files.length) {
    console.log('No hay líneas base pendientes.');
    return;
  }
  console.log('Líneas base pendientes:');
  for (const file of files) {
    const state = JSON.parse(fs.readFileSync(path.join(STATE_DIR, file), 'utf8'));
    console.log(
      `- ${state.spec} | inicio ${new Date(state.started_at).toLocaleString('es-ES')} | base ${
        state.base_commit ? state.base_commit.slice(0, 12) : '—'
      } | rama ${state.branch || '—'}${
        state.finalized === false ? ' | pendiente de finalize' : ''
      }`,
    );
  }
}

async function main() {
  const args = parseArgs(process.argv.slice(2));
  const command = args._[0] || 'status';

  if (command === 'start') {
    await cmdStart(args);
    return;
  }
  if (command === 'finish') {
    await cmdFinish(args);
    return;
  }
  if (command === 'finalize') {
    await cmdFinalize(args);
    return;
  }
  if (command === 'status') {
    cmdStatus();
    return;
  }

  fail(`Comando desconocido: ${command}. Usá start, finish o status.`);
}

main().catch((error) => fail(error.stack || error.message));
