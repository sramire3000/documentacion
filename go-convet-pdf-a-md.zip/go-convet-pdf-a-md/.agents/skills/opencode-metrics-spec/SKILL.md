---
name: opencode-metrics-spec
description: Registra las métricas reales de implementación de un spec de OpenCode (tokens de la sesión, archivos, LOC, tests y duración) y actualiza references/metrics/. Se ejecuta desde /spec-impl en la fase previa a marcar el spec como Implementado.
argument-hint: <NN-slug>
allowed-tools: Bash(node:*), Bash(git:*), Read, Write, Edit
---

# opencode-metrics-spec — cierre medible de un spec

Registra **una fila por spec**. Es el último paso de `/spec-impl`: se ejecuta después de verificar los criterios de aceptación y **antes** de cambiar el estado del spec a `Implementado`.

## Flujo obligatorio

### 1. Al empezar la implementación

```bash
node .agents/skills/opencode-metrics-spec/scripts/spec-metrics.mjs start --spec NN-slug
```

Guarda la línea base: commit de partida, rama, sesión de OpenCode y contadores de tokens. Sin esta línea base no se puede calcular el consumo real del spec.

### 2. Antes de completar

Si el spec se va a verificar con `/verify-spec`, ejecutalo **antes** de este paso (en esta misma sesión, como subagente, o manualmente en el mismo directorio). El verificador corre en una sesión nueva del proyecto y sus tokens entran solos en la medición.

```bash
node .agents/skills/opencode-metrics-spec/scripts/spec-metrics.mjs finish --spec NN-slug
```

Calcula el delta desde la línea base, escribe los tres archivos de `references/metrics/`, imprime el resumen y **conserva la línea base** (la sesión del agente sigue consumiendo después de este comando). **Solo después de que este comando termine bien** se cambia el estado a `Implementado` y se hace el commit final.

Si la verificación se ejecutó **después** de un `finish`, repetí `finish` para el mismo `spec` + `rama`: la fila se reemplaza (no se duplica) e incluye la sesión del verificador. **No ejecutes `finalize` antes de verificar**: borra la línea base y los tokens del verificador ya no se pueden atribuir.

### 3. Cuando termina la sesión

```bash
node .agents/skills/opencode-metrics-spec/scripts/spec-metrics.mjs finalize --spec NN-slug
```

Recalcula la fila con los totales definitivos de la sesión (incluye el último turno y las sesiones del verificador), vuelve a contar archivos/LOC/tests y borra la línea base. Si no se ejecuta, la fila queda con los tokens consumidos hasta `finish` y el dashboard subestima el costo real.

Si el comando sale con error, el spec **no se cierra**.

## Opciones de `finish`

| Opción                                                  | Uso                                                         |
| ------------------------------------------------------- | ----------------------------------------------------------- |
| `--observaciones "texto"`                               | Nota libre para el CSV.                                     |
| `--tipo feature\|fix\|refactor\|docs\|test`             | Tipo de trabajo. Default: `feature`.                        |
| `--epic "Nombre"`                                       | Sobrescribe la épica leída del spec.                        |
| `--prioridad Alta`                                      | Sobrescribe la prioridad leída del spec.                    |
| `--base <ref>`                                          | Fuerza el commit/rama base del diff.                        |
| `--session <ses_id>`                                    | Sesión de OpenCode a medir. Default: `OPENCODE_SESSION_ID`. |
| `--duration N`                                          | Fuerza la duración en minutos (útil al recalcular).         |
| `--input N --output N`                                  | Fuerza tokens cuando no hay acceso a `opencode.db`.         |
| `--reasoning N --cache-read N --cache-write N --cost N` | Complementa los tokens forzados.                            |
| `--allow-zero`                                          | Permite cerrar con 0 tokens (solo si no hubo consumo real). |
| `--dry-run`                                             | Calcula y muestra la fila sin escribir archivos.            |

### Opciones de `finalize`

| Opción               | Uso                                                       |
| -------------------- | --------------------------------------------------------- |
| `--session <ses_id>` | Sobrescribe la sesión medida.                             |
| `--duration N`       | Sobrescribe la duración que registró `finish`.            |
| `--end <ms\|ISO>`    | Fin de la ventana para contar archivos cuando no hay git. |

`status` lista las líneas base pendientes. `start --force` reinicia una línea base existente.

## De dónde sale cada métrica

| Métrica                                     | Fuente                          | Cálculo                                                                                                                                                                                   |
| ------------------------------------------- | ------------------------------- | ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| Input / Output tokens                       | `opencode.db` → `session_v2`    | Delta de la sesión base entre `start` y `finish` + sesiones nuevas del mismo directorio creadas después de `start` (subagentes como `spec-verifier` y verificaciones manuales incluidas). |
| Sesiones (`sesiones`)                       | `opencode.db` → `session_v2`    | Cantidad de sesiones sumadas: la base más cada sesión hija/manual del mismo directorio creada después de `start`.                                                                         |
| Total tokens                                | —                               | `input + output`. La caché se informa aparte y **no** se suma.                                                                                                                            |
| Archivos creados / modificados / eliminados | `git diff --name-status <base>` | Incluye archivos sin trackear (`git ls-files --others`). Sin git: fecha de creación/modificación dentro de `[start, fin de sesión]`.                                                      |
| LOC agregadas / eliminadas                  | `git diff --numstat <base>`     | Los archivos nuevos sin trackear suman sus líneas. Sin git: líneas de los archivos creados en la ventana.                                                                                 |
| Tests generados                             | Diff añadido                    | Declaraciones `it/test/@Test/[Fact]/func Test/def test_` en líneas nuevas. Sin git: se cuentan en los archivos creados.                                                                   |
| Archivos de test nuevos                     | `git diff`                      | Rutas `tests/`, `__tests__/`, `e2e/`, `*.test.*`, `*.spec.*`, `*Test.java`, etc.                                                                                                          |
| Duración                                    | Reloj                           | Minutos entre `start` y `finish` (incluye pausas).                                                                                                                                        |
| Épica / prioridad                           | Encabezado del spec             | `**Épica:**` y `**Prioridad:**` (acepta inglés y variantes sin acento).                                                                                                                   |

Los directorios `references/metrics/` (métricas) y `references/reports/` (reporte de cambios) se excluyen del diff para que los propios reportes no inflen las métricas. El reporte de cambios (`opencode-report-change-object`) se genera antes de `finish`, así que esta exclusión es obligatoria.

## Archivos que escribe

```text
references/metrics/spec-metrics.csv      # histórico, una fila por spec
references/metrics/dashboard.md          # indicadores y top 10
references/metrics/monthly-summary.md    # acumulado por mes
references/metrics/.state/               # línea base temporal (ignorada por git)
```

Columnas del CSV:

```text
fecha,proyecto,spec,rama,epic,tipo,prioridad,modelo,sesiones,input_tokens,output_tokens,reasoning_tokens,cache_read_tokens,cache_write_tokens,total_tokens,costo_usd,archivos_creados,archivos_modificados,archivos_eliminados,test_files,test_generados,loc_agregadas,loc_eliminadas,duracion_min,estado,observaciones
```

Repetir `finish` para el mismo `spec` + `rama` **reemplaza** la fila; no duplica.

## Si no se pueden leer los tokens

Ocurre si `node:sqlite` no está disponible (Node < 22.5), si `opencode.db` no está en la ruta esperada o si se ejecuta fuera de OpenCode.

1. Obtené números reales con `opencode stats --json --project . --days 1`.
2. Repetí el cierre con:

```bash
node .agents/skills/opencode-metrics-spec/scripts/spec-metrics.mjs finish --spec NN-slug \
  --input 120000 --output 8000 --cache-read 450000 --cache-write 1200 --cost 0.35
```

3. Si de verdad corresponde 0 consumo, agregá `--allow-zero` y anotá el motivo en `--observaciones`. **Nunca inventes tokens.**

Si `start` falló o no se ejecutó, `finish` usa como base el `merge-base` con `main`/`master`/`develop` y suma las sesiones del directorio. Avisa por stderr; es un cálculo aproximado.

## Reglas duras

- No ejecutes `finish` antes de que pasen los criterios de aceptación.
- Si se verifica con `/verify-spec`, hacelo antes de `finish`; si ya corriste `finish`, volvé a ejecutarlo para que la sesión del verificador reemplace la fila.
- No ejecutes `finalize` antes de la verificación: borra la línea base y los tokens del verificador quedan sin atribuir.
- No marques el spec como `Implementado` si `finish` falló o quedaron tokens sin registrar.
- No edites el CSV a mano: corregí y volvé a ejecutar `finish` (o `finalize`).
- Ejecutá `finalize` cuando la sesión del agente termine: `finish` solo mide hasta el instante en que se invoca.
- Un `start` por spec. Si cambiaste de rama o de sesión, mantené la misma línea base.
- Commiteá `references/metrics/` junto con el cambio de estado del spec.
- Mostrá el bloque `TAREA FINALIZADA (SPEC)` tal como lo imprime el script.

## Salida esperada

El script imprime un bloque como este; es el que se muestra al usuario:

```text
TAREA FINALIZADA (SPEC)

Proyecto: mi-proyecto
Spec:     01-mvp-arkanoid
Epic:     Checkout
Rama:     spec-01-mvp-arkanoid
Modelo:   opencode-go/deepseek-v4.1-flash

Input tokens:    120.000
Output tokens:   8.000
Total tokens:    128.000
Cache leída:     450.000
Cache escrita:   1.200
Costo:           $0,3500

Archivos creados:    4
Archivos modificados: 3
LOC agregadas:       210
LOC eliminadas:      18
Test generados:      6 (en 2 archivos nuevos)
Duración:            42 min

Acumulado tokens: 1.420.000

Total specs:        7
Total tokens:       1.420.000
Promedio tokens:    202.857
LOC totales:        3.180
```
