---
name: opencode-report-change-object
description: Genera el reporte CSV de los objetos (archivos) creados, modificados y eliminados durante la implementación de un spec, con el propósito global del spec, fecha y hora. Se ejecuta al final de /spec-impl, antes de registrar las métricas, o manualmente con /opencode-report-change-object.
argument-hint: <NN-slug>
allowed-tools: Bash(node:*), Bash(git:*), Read, Write, Edit
---

# opencode-report-change-object — reporte de cambios por objeto

Genera **un CSV por spec** con todos los objetos de código que cambiaron para implementarlo. Es el penúltimo paso de `/spec-impl`: se ejecuta **después de verificar los criterios y antes de las métricas**, para que el reporte refleje solo la implementación y `references/reports/` entre en el commit final.

Fichero de apoyo del mismo directorio:

- `scripts/spec-changes-report.mjs` — calcula los cambios con `git diff` y escribe el CSV.

## Flujo obligatorio

### 1. Identificar el spec

Aceptá el número (`01`), el slug (`endpoint-bienvenida`), el nombre completo (`01-endpoint-bienvenida`) o la ruta (`specs/01-endpoint-bienvenida.md`). El script resuelve cualquiera de esas formas contra `specs/` y usa **el nombre del archivo del spec** para nombrar el reporte:

```text
specs/01-endpoint-bienvenida.md  →  references/reports/01-endpoint-bienvenida.csv
```

Si el spec no existe, el script falla y lista los disponibles. No inventes el nombre del archivo.

### 2. Generar el reporte

Desde la raíz del proyecto:

```bash
node .agents/skills/opencode-report-change-object/scripts/spec-changes-report.mjs --spec NN-slug
```

El script:

1. Toma el commit base del spec desde `references/metrics/.state/<spec>.json` (la línea base que creó `/spec-impl`). Si ya se ejecutó `finalize`, cae a `origin/HEAD`, `main`, `master` o `develop`; también podés pasar `--base <ref>`.
2. Lista los cambios con `git diff --name-status -M <base>` y suma los archivos sin trackear (`git ls-files --others`).
3. Excluye `specs/`, `metrics/`, `reports/`, `references/reports/`, `.agents/`, `.opencode/`, `.github/`, `.mvn/`, los directorios de build y la documentación (`.md`, `.txt`, `.rst`). Usá `--include-all` solo si querés verlos.
4. Clasifica cada objeto como `Nuevo`, `Modificado` o `Eliminado`.
5. Repite en cada fila el **propósito global** leído del encabezado del spec (`**Objetivo:**` / `**Objective:**` / equivalente) junto con la fecha y la hora de generación.

Opciones útiles:

| Opción               | Uso                                                                |
| -------------------- | ------------------------------------------------------------------ |
| `--base <ref>`       | Fuerza el commit/rama base del diff.                               |
| `--head <ref>`       | Limita el diff a ese commit (por defecto usa el árbol de trabajo). |
| `--comentario "..."` | Sobrescribe el propósito global del spec.                          |
| `--out <ruta>`       | Cambia la ruta del CSV (default `references/reports/<spec>.csv`).  |
| `--include-all`      | Incluye también specs, métricas, reportes, herramientas y `.md`.   |
| `--dry-run`          | Muestra las filas sin escribir el archivo.                         |

### 3. Validar antes de cerrar

1. Confirmá que el script terminó con `✅ Reporte de cambios generado.` y mostró la ruta.
2. Leé el CSV y comprobá:
   - Encabezado exacto: `fecha,hora,ruta,objeto,tipo,comentario`.
   - Una fila por objeto, sin duplicados de `ruta`.
   - `tipo` solo con valores `Nuevo`, `Modificado` o `Eliminado`.
   - `comentario` con el propósito global (no vacío) y `fecha`/`hora` completas.
3. Si el reporte sale vacío, **no lo maquilles**: revisá la base del diff. Si el spec se implementó en otra rama o el `base_commit` no corresponde, pasá `--base` con el commit correcto y volvé a generar.
4. No edites el CSV a mano: corregí la base o el código y volvé a ejecutar el script (sobrescribe el archivo).

## Formato del CSV

| Columna      | Contenido                                                                   |
| ------------ | --------------------------------------------------------------------------- |
| `fecha`      | Fecha de generación en `YYYY-MM-DD`.                                        |
| `hora`       | Hora local de generación en `HH:MM:SS`.                                     |
| `ruta`       | Ruta del objeto relativa a la raíz, con `/` (`src/main/java/...`).          |
| `objeto`     | Nombre del objeto: clase sin extensión para código; archivo completo si no. |
| `tipo`       | `Nuevo`, `Modificado` o `Eliminado`.                                        |
| `comentario` | Propósito global del spec, idéntico en todas las filas.                     |

Se escribe en UTF-8 con BOM y saltos `\n` para que Excel lo abra sin romper acentos.

## Reglas duras

- No generes el reporte antes de terminar la implementación: reflejaría cambios parciales.
- En `/spec-impl`, ejecutalo **después de verificar los criterios y antes de `finish` de métricas**, así el reporte refleja solo la implementación. El script de métricas excluye `references/reports/` del diff, por lo que el CSV no infla archivos ni LOC.
- No agregues filas a mano ni omitas archivos: el reporte es la evidencia de lo que tocó el spec.
- No incluyas `specs/`, `metrics/` ni `references/reports/` (el propio reporte) salvo que se pida con `--include-all`.
- Si el script falla, el spec no se cierra: corregí la causa y volvé a ejecutarlo.
- Los identificadores del CSV van en español (`Nuevo`/`Modificado`/`Eliminado`) porque son valores de reporte, no de código.

## Salida esperada

```text
✅ Reporte de cambios generado.
   Spec:       01-endpoint-bienvenida
   Archivo:    references/reports/01-endpoint-bienvenida.csv
   Base git:   86e47b4b068e
   Propósito:  Exponer GET /api/welcome que responde 200 OK con el texto plano Bienvenidos a Spring boot.
   Objetos:    2 (2 nuevos, 0 modificados, 0 eliminados)
```
