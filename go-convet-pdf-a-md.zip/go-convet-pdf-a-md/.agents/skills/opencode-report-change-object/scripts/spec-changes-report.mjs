#!/usr/bin/env node
/**
 * opencode-report-change-object
 *
 * Genera el reporte CSV de objetos (archivos) que cambiaron durante la
 * implementación de un spec:
 *   - detecta los cambios con `git diff --name-status` contra el commit base
 *     del spec (references/metrics/.state/<spec>.json) o contra main/master/develop
 *   - clasifica cada objeto como Nuevo, Modificado o Eliminado
 *   - repite el propósito global del spec en cada fila, con fecha y hora
 *
 * Uso:
 *   node spec-changes-report.mjs --spec 01-endpoint-bienvenida
 *   node spec-changes-report.mjs 01-endpoint-bienvenida
 *
 * Opciones:
 *   --spec <NN-slug>       Spec a reportar (también acepta el argumento posicional)
 *   --base <ref>           Commit/rama base para el diff
 *   --head <ref>           Limita el diff a ese commit (default: árbol de trabajo)
 *   --comentario "texto"   Sobrescribe el propósito global (default: Objetivo del spec)
 *   --out <ruta>           Sobrescribe la ruta del CSV (default: references/reports/<spec>.csv)
 *   --include-all          Incluye specs/, metrics/, reports/, referencias y documentación
 *   --dry-run              Calcula y muestra las filas sin escribir el archivo
 */

import { spawnSync } from 'node:child_process';
import fs from 'node:fs';
import path from 'node:path';

const ROOT = process.cwd();
const REPORTS_DIR = path.join(ROOT, 'references', 'reports');
const STATE_DIR = path.join(ROOT, 'references', 'metrics', '.state');

const CSV_COLUMNS = ['fecha', 'hora', 'ruta', 'objeto', 'tipo', 'comentario'];

const TYPE_ORDER = { Nuevo: 0, Modificado: 1, Eliminado: 2 };

const CODE_EXTENSIONS = new Set([
  'java',
  'kt',
  'kts',
  'groovy',
  'scala',
  'ts',
  'tsx',
  'js',
  'jsx',
  'mjs',
  'cjs',
  'vue',
  'py',
  'rb',
  'go',
  'rs',
  'php',
  'cs',
  'fs',
  'c',
  'h',
  'cpp',
  'hpp',
  'cc',
  'swift',
  'sql',
  'sh',
  'ps1',
]);

// Rutas que nunca forman parte del código de la implementación.
const IGNORED_PREFIXES = [
  '.git/',
  '.agents/',
  '.opencode/',
  '.github/',
  '.mvn/',
  '.idea/',
  '.vscode/',
  'metrics/',
  'reports/',
  'references/metrics/',
  'references/reports/',
  'specs/',
  'target/',
  'build/',
  'out/',
  'dist/',
  'node_modules/',
];

// Documentación: no es código de programación. Se incluye con --include-all.
const IGNORED_EXTENSIONS = new Set(['md', 'mdx', 'txt', 'rst', 'adoc']);

function parseArgs(argv) {
  const args = { _: [] };
  for (let i = 0; i < argv.length; i += 1) {
    const token = argv[i];
    if (!token.startsWith('--')) {
      args._.push(token);
      continue;
    }
    const body = token.slice(2);
    const eq = body.indexOf('=');
    if (eq >= 0) {
      args[body.slice(0, eq)] = body.slice(eq + 1);
    } else if (argv[i + 1] && !argv[i + 1].startsWith('--')) {
      args[body] = argv[i + 1];
      i += 1;
    } else {
      args[body] = true;
    }
  }
  return args;
}

function warn(message) {
  console.error(`⚠️  ${message}`);
}

function fail(message) {
  console.error(`❌ ${message}`);
  process.exit(1);
}

function git(args) {
  const result = spawnSync('git', args, {
    cwd: ROOT,
    encoding: 'utf8',
    maxBuffer: 64 * 1024 * 1024,
  });
  if (result.status !== 0) return null;
  return result.stdout.trim();
}

function normalizeSpec(value) {
  return String(value || '')
    .replace(/\\/g, '/')
    .replace(/^specs\//, '')
    .replace(/\.md$/i, '')
    .trim();
}

function findSpecFile(spec) {
  const specsDir = path.join(ROOT, 'specs');
  if (!fs.existsSync(specsDir)) return null;
  const wanted = normalizeSpec(spec);
  if (!wanted) return null;
  const files = fs
    .readdirSync(specsDir)
    .filter((file) => file.toLowerCase().endsWith('.md'))
    .sort();
  const lower = wanted.toLowerCase();
  const exact = files.find((file) => file.replace(/\.md$/i, '').toLowerCase() === lower);
  if (exact) return path.join(specsDir, exact);
  const byPrefix = files.filter((file) => file.toLowerCase().startsWith(`${lower}-`));
  if (byPrefix.length === 1) return path.join(specsDir, byPrefix[0]);
  const byNumber = files.filter((file) => file.toLowerCase().startsWith(lower));
  if (byNumber.length === 1) return path.join(specsDir, byNumber[0]);
  const bySlug = files.filter((file) => file.toLowerCase().includes(lower));
  if (bySlug.length === 1) return path.join(specsDir, bySlug[0]);
  return null;
}

function stripInlineMarkdown(text) {
  return String(text || '')
    .replace(/`/g, '')
    .replace(/\*\*/g, '')
    .replace(/\s+/g, ' ')
    .trim();
}

function readSpecPurpose(specFile) {
  const text = fs.readFileSync(specFile, 'utf8');
  const lines = text.split(/\r?\n/);
  const meta = /^\s*>\s*\*\*([^*]+)\*\*\s*:?\s*(.+?)\s*$/;
  for (const line of lines) {
    const match = line.match(meta);
    if (!match) continue;
    if (!/(objetiv|objectiv|objectif|ziel|obiettivo)/i.test(match[1])) continue;
    const purpose = stripInlineMarkdown(match[2]);
    if (purpose) return purpose;
  }
  for (const line of lines) {
    if (/^#\s+/.test(line)) return stripInlineMarkdown(line.replace(/^#\s+/, ''));
  }
  return '';
}

function loadMetricsState(spec) {
  const file = path.join(STATE_DIR, `${spec}.json`);
  if (!fs.existsSync(file)) return null;
  try {
    return JSON.parse(fs.readFileSync(file, 'utf8'));
  } catch {
    return null;
  }
}

function detectBase() {
  for (const ref of ['origin/HEAD', 'main', 'master', 'develop']) {
    const verify = git(['rev-parse', '--verify', '--quiet', ref]);
    if (!verify) continue;
    const mergeBase = git(['merge-base', 'HEAD', ref]);
    if (mergeBase) return mergeBase;
  }
  return git(['rev-parse', 'HEAD']) || '';
}

function normalizePath(file) {
  return String(file || '').replace(/\\/g, '/');
}

function isIgnoredPath(file) {
  const normalized = normalizePath(file);
  if (
    IGNORED_PREFIXES.some(
      (prefix) => normalized === prefix.slice(0, -1) || normalized.startsWith(prefix)
    )
  ) {
    return true;
  }
  const dot = normalized.lastIndexOf('.');
  if (dot > normalized.lastIndexOf('/')) {
    const extension = normalized.slice(dot + 1).toLowerCase();
    if (IGNORED_EXTENSIONS.has(extension)) return true;
  }
  return false;
}

function objectName(file) {
  const base = path.posix.basename(normalizePath(file));
  const dot = base.lastIndexOf('.');
  if (dot <= 0) return base;
  const extension = base.slice(dot + 1).toLowerCase();
  if (CODE_EXTENSIONS.has(extension)) return base.slice(0, dot);
  return base;
}

function changedObjects(base, includeAll, head) {
  const entries = new Map();

  const range = head ? [base, head] : [base];
  const nameStatus = git(['diff', '--name-status', '-M', ...range]);
  if (nameStatus === null) {
    fail(`No pude calcular el diff del rango "${range.join('..')}". ¿Existen esos commits?`);
  }

  for (const line of nameStatus.split('\n').filter(Boolean)) {
    const parts = line.split('\t');
    const status = parts[0] || '';
    let file;
    let type;
    if (status.startsWith('R') || status.startsWith('C')) {
      file = parts[2];
      type = status.startsWith('C') ? 'Nuevo' : 'Modificado';
    } else if (status.startsWith('A')) {
      file = parts[1];
      type = 'Nuevo';
    } else if (status.startsWith('D')) {
      file = parts[1];
      type = 'Eliminado';
    } else {
      file = parts[1];
      type = 'Modificado';
    }
    if (!file) continue;
    file = normalizePath(file);
    if (!includeAll && isIgnoredPath(file)) continue;
    entries.set(file, type);
  }

  const untracked = head ? '' : git(['ls-files', '--others', '--exclude-standard']) || '';
  for (const raw of untracked.split('\n').filter(Boolean)) {
    const file = normalizePath(raw);
    if (!includeAll && isIgnoredPath(file)) continue;
    if (!entries.has(file)) entries.set(file, 'Nuevo');
  }

  return [...entries.entries()]
    .map(([file, type]) => ({ ruta: file, objeto: objectName(file), tipo: type }))
    .sort((a, b) => TYPE_ORDER[a.tipo] - TYPE_ORDER[b.tipo] || a.ruta.localeCompare(b.ruta));
}

function nowParts(date = new Date()) {
  const pad = (value) => String(value).padStart(2, '0');
  return {
    fecha: `${date.getFullYear()}-${pad(date.getMonth() + 1)}-${pad(date.getDate())}`,
    hora: `${pad(date.getHours())}:${pad(date.getMinutes())}:${pad(date.getSeconds())}`,
  };
}

function csvEscape(value) {
  const text = String(value ?? '');
  if (/[",\r\n]/.test(text)) return `"${text.replace(/"/g, '""')}"`;
  return text;
}

function writeReport(outFile, rows) {
  fs.mkdirSync(path.dirname(outFile), { recursive: true });
  const lines = [CSV_COLUMNS.join(',')];
  for (const row of rows) {
    lines.push(CSV_COLUMNS.map((column) => csvEscape(row[column] ?? '')).join(','));
  }
  fs.writeFileSync(outFile, `\uFEFF${lines.join('\n')}\n`, 'utf8');
}

function main() {
  const args = parseArgs(process.argv.slice(2));
  const rawSpec = args.spec || args._[0];
  if (!rawSpec) fail('Falta el spec (por ejemplo: --spec 01-endpoint-bienvenida).');

  const spec = normalizeSpec(rawSpec);
  const specFile = findSpecFile(spec);
  if (!specFile) {
    const specsDir = path.join(ROOT, 'specs');
    const available = fs.existsSync(specsDir)
      ? fs
          .readdirSync(specsDir)
          .filter((file) => file.toLowerCase().endsWith('.md'))
          .join(', ')
      : '(la carpeta specs/ no existe)';
    fail(`No encontré el spec "${rawSpec}". Disponibles: ${available}`);
  }

  if (git(['rev-parse', '--is-inside-work-tree']) !== 'true') {
    fail('Este reporte necesita git para calcular los objetos cambiados.');
  }

  // El nombre del reporte sale del archivo del spec, no del argumento:
  // `--spec 01` y `--spec endpoint-bienvenida` deben producir el mismo CSV.
  const specName = path.basename(specFile, path.extname(specFile));

  const state = loadMetricsState(specName);
  const base = args.base
    ? git(['rev-parse', args.base]) || args.base
    : state?.base_commit || detectBase();
  if (!base) fail('No pude determinar el commit base del spec. Pasá --base <ref>.');

  const head = args.head ? git(['rev-parse', args.head]) || args.head : null;

  const purpose = args.comentario
    ? String(args.comentario)
    : readSpecPurpose(specFile) || `Implementación del spec ${specName}`;

  const { fecha, hora } = nowParts();
  const objects = changedObjects(base, Boolean(args['include-all']), head);
  const rows = objects.map((object) => ({ fecha, hora, ...object, comentario: purpose }));

  const outFile = args.out
    ? path.resolve(ROOT, String(args.out))
    : path.join(REPORTS_DIR, `${specName}.csv`);
  const relativeOut = path.relative(ROOT, outFile).replace(/\\/g, '/');

  if (args['dry-run']) {
    console.log('🧪 Dry run: no se escribió el archivo.');
    console.log(`   Spec:      ${specName}`);
    console.log(`   Base git:  ${base.slice(0, 12)}`);
    if (head) console.log(`   Hasta:     ${head.slice(0, 12)}`);
    console.log(`   Archivo:   ${relativeOut}`);
    console.log(`   Propósito: ${purpose}`);
    for (const row of rows) {
      console.log(`   - ${row.tipo.padEnd(10)} ${row.ruta} (${row.objeto})`);
    }
    return;
  }

  writeReport(outFile, rows);

  const counts = { Nuevo: 0, Modificado: 0, Eliminado: 0 };
  for (const row of rows) counts[row.tipo] += 1;

  console.log('✅ Reporte de cambios generado.');
  console.log(`   Spec:       ${specName}`);
  console.log(`   Archivo:    ${relativeOut}`);
  console.log(`   Base git:   ${base.slice(0, 12)}`);
  if (head) console.log(`   Hasta:      ${head.slice(0, 12)}`);
  console.log(`   Propósito:  ${purpose}`);
  console.log(
    `   Objetos:    ${rows.length} (${counts.Nuevo} nuevos, ${counts.Modificado} modificados, ${counts.Eliminado} eliminados)`
  );
  if (rows.length === 0) {
    warn('No se detectaron cambios de código contra la base del spec.');
  }
}

try {
  main();
} catch (error) {
  fail(error.stack || error.message);
}
