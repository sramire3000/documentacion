# Plantilla para un buen spec

Este archivo es la referencia que consulta la skill `/spec` al generar specs. Cada sección incluye su propósito y un ejemplo mínimo. **No es texto para copiar literalmente** — es la forma que la skill debe respetar.

---

## Encabezado

Todo spec empieza con metadatos en formato blockquote (sin tablas, sin bloques, simple como se muestra abajo):

```markdown
# SPEC NN — Título corto y descriptivo

> **Estado:** Borrador
> **Depende de:** SPEC 01, SPEC 02
> **Fecha:** AAAA-MM-DD
> **Objetivo:** Una sola oración. Si necesitás dos oraciones, la feature es demasiado grande.
```

**Estados válidos:** `Borrador`, `En revisión`, `Aprobado`, `Implementado`, `Obsoleto`.

> Las etiquetas de arriba son las de por defecto en inglés. Las skills también aceptan equivalentes en cualquier idioma (p. ej. inglés `Draft` / `In review` / `Approved` / `Implemented` / `Obsolete`). Elegí un juego por repo y mantenete consistente.

**Regla del objetivo:** una oración que un humano lee en 5 segundos y entiende qué se va a construir. Si no entra en una oración, dividí la feature.

---

## Sección 1 — Por qué existe este spec (opcional)

Para specs que toman decisiones no obvias o rompen los patrones del proyecto, una sección breve que explique el **por qué** del trabajo. No el qué — el qué viene después.

Para specs simples, omitila.

---

## Sección 2 — Alcance

Dos sub-bloques explícitos. **Ambos son obligatorios.**

```markdown
## Alcance

**Dentro:**

- Cosa concreta uno.
- Cosa concreta dos.

**Fuera de alcance (para specs futuros):**

- Algo que se podría hacer pero no ahora.
- Algo que surgió en la conversación pero no está dentro.
```

**Por qué importa el "fuera":** captura las cosas que el usuario mencionó durante la fase de preguntas pero que se decidió posponer. Sin ese registro, durante la implementación existirá la tentación de colarlas "ya que estamos".

---

## Sección 3 — Modelo de datos

Las estructuras concretas que aparecen o cambian. Usá código real, no pseudocódigo abstracto.

```markdown
## Modelo de datos

\`\`\`js
// Estado del juego
const state = {
level: 1,
score: 0,
highScores: [/* { score, level, date } */],
};
\`\`\`

Convenciones:

- Coordenadas: origen arriba a la izquierda.
- Velocidades en píxeles/frame.
```

Si la feature no introduce datos nuevos, escribilo explícitamente: _"Esta feature no introduce estructuras de datos nuevas. Reutiliza el modelo del SPEC 01."_

---

## Sección 4 — Archivos y ubicación, y plan de implementación

Todo plan empieza con una **tabla de archivos y ubicación** derivada de `references/estructura/estructura.md`, y recién después los pasos numerados. Cada paso debe dejar el sistema en un estado **funcional y ejecutable**. Nada de "implemento la mitad y sigo mañana".

```markdown
## Archivos y ubicación

| Archivo                                                                        | Capa / paquete                           | Acción |
| ------------------------------------------------------------------------------ | ---------------------------------------- | ------ |
| `src/main/java/<base>/infrastructure/entrypoints/rest/UserController.java`     | `infrastructure/entrypoints/rest`        | Nuevo  |
| `src/test/java/<base>/infrastructure/entrypoints/rest/UserControllerTest.java` | `infrastructure/entrypoints/rest` (test) | Nuevo  |

## Plan de implementación

1. Crear `src/main/java/<base>/infrastructure/entrypoints/rest/UserController.java` con un esqueleto vacío.
2. Implementar el método A en ese archivo. Prueba manual: ejecutar Y, ver Z.
3. Crear `src/test/java/<base>/infrastructure/entrypoints/rest/UserControllerTest.java` y cubrir el caso B.
```

**Reglas:**

- **Rutas completas obligatorias.** Nada de "el controller" o `UserController.java` a secas: siempre `src/main/java/<base>/<capa>/<subcapa>/Archivo.java`.
- **Capas de `estructura.md` sin excepciones.** `domain/` es puro (sin Spring/JPA); `application/` orquesta casos de uso; `infrastructure/` contiene adaptadores (REST, persistencia, mensajería, seguridad, clientes); `configuration/` agrupa configuración y beans.
- **Prohibido** `<base>.controller`, `<base>.service`, `<base>.repository` y cualquier paquete plano.
- **Tests espejan el paquete** de la clase que prueban, bajo `src/test/java/`.
- **Convenciones de `instructions.md`:** identificadores en inglés, comentarios y documentación de métodos en español, SOLID/DRY, sin comentarios superfluos.
- Cada paso debe poder commitearse por sí solo.
- Si un paso requiere más de 30–50 líneas de código, dividilo.
- El último paso del plan **no** es "probar todo" — eso son los criterios de aceptación.

---

## Sección 5 — Criterios de aceptación

Checklist booleana. Cada ítem se puede verificar con sí o no.

```markdown
## Criterios de aceptación

- [ ] El juego carga sin errores en la consola.
- [ ] Romper un ladrillo suma exactamente 10 puntos.
- [ ] Recargar la página conserva los récords.
```

**Antipatrones a evitar:**

- ❌ "Que funcione bien." → no verificable.
- ❌ "Buena UX." → subjetivo.
- ❌ "Sin bugs." → no operativo.
- ✅ "Presionar Esc pausa el juego y muestra el menú." → verificable, booleano.

**Criterios obligatorios de estructura y convenciones:** todo spec incluye al menos un ítem que verifique que los archivos respetan `references/estructura/estructura.md` (capas correctas, sin paquetes planos) y otro que verifique `references/instructions/instructions.md` (identificadores en inglés, comentarios en español, sin código con "magia").

---

## Sección 6 — Decisiones tomadas y descartadas

La sección con más valor dentro de 3 meses. Capturá **lo que consideraste**, no solo lo que elegiste.

```markdown
## Decisiones

- **Sí:** localStorage para persistencia. Entra en <5MB y no necesitamos consultas.
- **No:** IndexedDB. Overengineering para este caso.
- **Sí:** clave versionada (`save:v1`). Nos permite migrar el esquema después sin romper.
- **No:** sincronización en la nube. Va en otro spec si alguna vez llega.
```

Cada decisión idealmente tiene una razón breve. Las decisiones sin razón son las primeras que se cuestionan después.

---

## Sección 7 — Riesgos identificados (opcional)

Solo cuando hay riesgos no obvios. Tabla simple:

```markdown
## Riesgos

| Riesgo                                     | Mitigación                                                                |
| ------------------------------------------ | ------------------------------------------------------------------------- |
| localStorage deshabilitado en modo privado | Fallback a objeto en memoria. El juego sigue corriendo, solo no persiste. |
| Esquema incompatible a futuro              | La clave incluye `:v1`. Migración documentada en `persistence.js`.        |
```

Para specs pequeños o features muy acotadas, omitila.

---

## Sección final — Lo que NO está (refuerzo)

Repetí explícitamente al final qué **no** se va a hacer en este spec. Esta repetición es deliberada — la sección Alcance ya lo dice, pero al final del documento sirve de recordatorio para quien lee solo las últimas líneas.

```markdown
## Lo que **no** está en este spec

- Editor visual (otro spec si alguna vez llega).
- Multijugador.
- Versión móvil.

Cada uno de esos, si llega, va en su propio spec.
```

---

## Reglas globales sobre todo el documento

- **Una oración por idea.** Si una oración tiene dos comas y un punto y coma, dividila.
- **Nombres concretos.** Si decís "el módulo de niveles", decí `src/levels.js`. Si decís "una clave", dá la cadena exacta.
- **Sin TODOs.** Un TODO en un spec significa que la decisión no se tomó. Tomala o anotala como decisión pendiente con una razón.
- **Estructura obligatoria.** Ningún spec propone archivos fuera de `domain/`, `application/`, `infrastructure/` o `configuration/` según `references/estructura/estructura.md`. Las rutas son completas y los paquetes planos están prohibidos.
- **Convenciones obligatorias.** Identificadores en inglés; comentarios y documentación de métodos en español; documentos `.md` en español.
- **Sin código ejecutable largo.** El spec describe; el código se escribe después. Snippets cortos para ilustrar estructuras de datos están bien; funciones completas no.
- **Markdown estándar.** Sin extensiones raras. Debe renderizar en GitHub sin sorpresas.
