---
name: spec
description: Diseña y desarrolla specs siguiendo el método spec-driven. Hace preguntas de aclaración antes de proponer la estructura, y construye el spec sección a sección. Usala cuando arranques una feature grande, antes de escribir código.
disable-model-invocation: true
argument-hint: 'descripción breve de la feature o requisito'
---

# /spec — Diseñador guiado de specs

Esta skill te ayuda a producir un spec útil siguiendo el método spec-driven. **Acá no escribís código.** Tu trabajo es ayudar al usuario a aclarar qué quiere construir, hacer preguntas cuando algo no está lo suficientemente bien definido, y desarrollar el spec sección a sección hasta que esté listo para guardarse en `specs/`.

## Filosofía

Un spec no es documentación decorativa. Es el contrato que impulsa la ejecución posterior. Si el spec es vago, el código improvisa. Por eso este flujo es **deliberadamente lento durante la fase de definición** y **rápido durante la fase de escritura**.

Leé `template.md` (en el mismo directorio que esta skill) para ver la estructura completa que seguirá el spec. Apoyate en él en cada paso.

## Referencias obligatorias del repositorio

Antes de proponer cualquier archivo, ruta o paquete, leé estas dos referencias. **No son sugerencias: son de cumplimiento obligatorio** y condicionan el plan de implementación.

1. **`references/estructura/estructura.md`** — estructura Clean Architecture del proyecto (`domain/`, `application/`, `infrastructure/`, `configuration/`). Todo artefacto del plan vive en la capa y subcapa que ese documento define. Ejemplos de mapeo (con `<base>` = paquete base real del proyecto):
   - Controlador REST → `src/main/java/<base>/infrastructure/entrypoints/rest/<X>Controller.java`
   - DTO de la API REST → `src/main/java/<base>/infrastructure/entrypoints/rest/dto/`
   - Mapper REST → `src/main/java/<base>/infrastructure/entrypoints/rest/mapper/`
   - Caso de uso → `src/main/java/<base>/application/usecase/`
   - DTO/command de aplicación → `src/main/java/<base>/application/dto/`
   - Modelo de dominio → `src/main/java/<base>/domain/model/`
   - Excepción de negocio → `src/main/java/<base>/domain/exception/`
   - Puerto de repositorio → `src/main/java/<base>/domain/repository/`
   - Entidad JPA → `src/main/java/<base>/infrastructure/persistence/entity/`
   - Spring Data repository → `src/main/java/<base>/infrastructure/persistence/repository/`
   - Mapper de persistencia → `src/main/java/<base>/infrastructure/persistence/mapper/`
   - Adaptador de repositorio → `src/main/java/<base>/infrastructure/persistence/adapter/`
   - Scheduler → `src/main/java/<base>/infrastructure/entrypoints/scheduler/`
   - Seguridad → `src/main/java/<base>/infrastructure/security/…`
   - Cliente HTTP externo → `src/main/java/<base>/infrastructure/client/…`
   - Configuración → `src/main/java/<base>/configuration/…`

   **Prohibido:** paquetes planos o de conveniencia tipo `<base>.controller`, `<base>.service`, `<base>.repository`, `<base>.dto`. Si un artefacto no encaja en ninguna carpeta existente, detenete y preguntá; no inventes paquetes nuevos ni lo pongas en la raíz.

2. **`references/instructions/instructions.md`** — convenciones de código del repo. Aplican a todo el plan y a los criterios de aceptación:
   - Identificadores en inglés (clases, métodos, variables, constantes, archivos).
   - Comentarios y documentación de métodos en español, solo cuando aporten valor.
   - Clean code, DRY, SOLID y simplicidad; sin comentarios superfluos ni "magia".
   - Documentos `.md` en español.
   - Patrones de diseño (creacionales, estructurales, de comportamiento) cuando simplifiquen de verdad.

Si alguna de las dos referencias no existe, decíselo al usuario y pedile la ruta correcta antes de continuar. No inventes la estructura.

## Flujo del comando

- Seguí las cuatro fases en orden. **No saltees fases.** Si el usuario quiere ir más rápido, recordale que el costo de un mal spec se paga después en código.
- Tus respuestas deben estar en el mismo idioma que el prompt inicial. P. ej.: si el prompt inicial está en español, tus respuestas deben estar en español; si está en inglés, en inglés.

### Fase 1 — Entender el contexto

Antes de hacer preguntas sobre la feature, asegurate de tener contexto del proyecto:

1. Leé el archivo de memoria del proyecto, si existe. Probá en orden y detenete en el primer acierto: `CLAUDE.md`, `AGENTS.md`, `GEMINI.md`, `README.md`. Esto adapta la skill al agente que la esté ejecutando (Claude Code, Codex, Gemini CLI, etc.).
2. Leé `references/estructura/estructura.md` y `references/instructions/instructions.md` completos. De ahí salen las rutas y convenciones que el plan **debe** respetar (ver "Referencias obligatorias del repositorio").
3. Detectá el paquete base real del proyecto (por ejemplo, leyendo `pom.xml` y las clases existentes en `src/main/java/`). No asumas `com.tuempresa.proyecto`.
4. Listá el contenido de `specs/` para ver qué specs existen ya y cómo están numerados.
5. Si existen specs previos, leé al menos los dos más recientes para captar las convenciones del proyecto. **No copies sus rutas si contradicen `estructura.md`**: la estructura obligatoria gana siempre y hay que señalarlo.

Si el argumento `$ARGUMENTS` viene vacío, pedile al usuario una **descripción inicial de una sola oración** de lo que quiere construir. Si la descripción no entra en una oración, esa es la primera señal de que la feature es demasiado grande — sugerí dividirla antes de continuar.

### Fase 2 — Aclarar mediante preguntas

Esta es la fase más importante del comando. Tu trabajo acá es **detectar ambigüedades y preguntar**, no asumir.

Hacé preguntas en bloques de 3 a 5 por vez (no una sola pregunta seguida de otra sola — es agotador). Después de cada bloque, esperá una respuesta antes de continuar.

**Categorías de preguntas que siempre deberías considerar:**

- **Alcance:** ¿Qué está dentro y qué NO? ¿Qué partes de la feature se difieren a otro spec?
- **Datos:** ¿Qué estructuras nuevas se introducen? ¿Cómo se nombran? ¿Dónde viven?
- **Ubicación y capas:** ¿En qué capa y subcapa de `references/estructura/estructura.md` vive cada artefacto? La estructura es obligatoria: si el usuario propone un paquete plano, explicale la ruta correcta y registrá la decisión. No hace falta preguntar cuando `estructura.md` ya la define; ahí se deriva y se muestra.
- **Integración:** ¿Esta feature depende de specs previos? ¿Modifica algo existente o solo agrega?
- **Persistencia:** ¿Se guarda algo entre sesiones? ¿Dónde? ¿Con qué versionado?
- **UX y estados:** ¿Cómo se ve cuando funciona? ¿Cómo se ve cuando falla? ¿Hay estados intermedios?
- **Riesgos:** ¿Qué puede romper esto? ¿Qué pasa en el caso degradado?
- **Decisiones cerradas:** ¿Hay alguna decisión que el usuario ya tomó y no quiere reabrir?

**Cómo formular las preguntas:**

- Usá preguntas concretas, no abiertas. ❌ "¿Cómo imaginás la persistencia?" → ✅ "¿La persistencia es localStorage, IndexedDB o un archivo JSON en disco?"
- Cuando ofrezcas opciones, dá 2–4, marcá cuál es tu recomendación y por qué.
- Si detectás una respuesta que abriría la caja de Pandora (p. ej. "y también queremos multijugador"), señalá que merece su propio spec y preguntá si la dejamos fuera del alcance de este.

**Cuándo dejar de preguntar:**

Pará cuando puedas responder estas tres preguntas sin asumir nada:

1. ¿Qué archivos aparecerán o cambiarán?
2. ¿Cuál es el primer paso ejecutable y cuál el último?
3. ¿Cómo verifico que la feature está terminada?

Si todavía no podés responder alguna, seguí preguntando.

### Fase 3 — Desarrollar el spec sección a sección

Una vez que tengas claridad, **no generes el spec completo de una sola vez**. Vas a desarrollar las secciones de la plantilla **una por una**, mostrando cada sección al usuario y esperando confirmación antes de pasar a la siguiente.

Orden estricto:

1. **Encabezado** (estado, dependencias, fecha, objetivo de una oración). El objetivo de una oración es crítico — si no entra en una oración, volvé a la Fase 2.
2. **Alcance** (qué está dentro y qué NO). El "no" debe ser explícito.
3. **Modelo de datos** (estructuras concretas con nombres reales). Si la feature no introduce datos nuevos, salteá esta sección y decilo explícitamente.
4. **Archivos y ubicación** (obligatoria). Tabla con cada archivo nuevo o modificado, su ruta completa `src/main/java/<base>/<capa>/<subcapa>/…` o `src/test/java/…`, la capa de `estructura.md` a la que pertenece y la acción (`Nuevo`/`Modificado`). Los tests espejan el paquete del código que prueban. Esta tabla alimenta directamente el plan.
5. **Plan de implementación** (pasos numerados, cada uno dejando el sistema funcional). Cada paso nombra la ruta completa del archivo que toca; nada de "el controller" a secas.
6. **Criterios de aceptación** (checklist booleana, no aspiracional). Incluí siempre uno que verifique que las rutas respetan `estructura.md` y otro que el código cumple `instructions.md` (identificadores en inglés, sin paquetes planos).
7. **Decisiones tomadas y descartadas** (con justificación breve).
8. **Riesgos identificados** (solo si aplica — si no hay riesgos relevantes, salteala).

**Después de cada sección:**

- Mostrala formateada en markdown.
- Preguntá: "¿Esta sección queda así o querés ajustar algo?"
- Si el usuario pide cambios, aplicalos y mostrá de nuevo.
- Pasá a la sección siguiente solo cuando el usuario confirme.

**Errores comunes a evitar:**

- Generar criterios de aceptación que no son verificables ("que funcione bien").
- Poner en el plan de implementación cosas que no están en el alcance.
- Asumir nombres de archivo o estructuras que el usuario no confirmó.
- Saltear la sección de decisiones — esa sección es la que más valor tiene a largo plazo.
- Ubicar artefactos en paquetes planos (`<base>.controller`, `<base>.service`, `<base>.repository`) o fuera de las capas de `references/estructura/estructura.md`.
- Omitir la tabla de archivos y ubicación, o escribir pasos con rutas ambiguas ("el controller", "el servicio").
- Ignorar `references/instructions/instructions.md` (identificadores en español, comentarios superfluos, código con "magia").

**Validación obligatoria antes de guardar:**

Recorré esta checklist y no escribas el archivo hasta que todo pase:

- [ ] Todo archivo nuevo o modificado tiene ruta completa `src/main/java/<base>/…` o `src/test/java/<base>/…` y cae en `domain/`, `application/`, `infrastructure/` o `configuration/`.
- [ ] Ningún artefacto vive en un paquete plano (`<base>.controller`, `<base>.service`, etc.).
- [ ] Los tests están en el mismo paquete que la clase que prueban.
- [ ] La tabla de archivos y ubicación existe, es completa y coincide con lo que dicen los pasos del plan.
- [ ] Cada paso del plan nombra el archivo y su ruta exacta.
- [ ] Los identificadores son en inglés; los comentarios y la documentación de métodos, en español.
- [ ] Los criterios de aceptación incluyen la verificación de estructura y de convenciones.
- [ ] Si un spec previo contradice `estructura.md`, quedó anotado como deuda explícita (no se copia el error).

### Fase 4 — Guardar el spec

Cuando todas las secciones estén confirmadas:

1. Determiná el siguiente número secuencial mirando `specs/`. Si el último es `02-powerups.md`, este será `03-`.
2. Generá un slug corto a partir del objetivo (p. ej. `levels-and-highscores`).
3. **Corré la validación obligatoria de la Fase 3.** Si algo falla, no escribas el archivo: corregí la sección afectada, mostrala de nuevo y pedí confirmación.
4. Preguntale al usuario si el nombre de archivo propuesto le sirve antes de escribirlo.
5. Creá el archivo en `specs/NN-slug.md` con todas las secciones aprobadas.
6. Marcá el estado como `Borrador` por defecto. **No lo marques como `Aprobado` automáticamente** — eso lo hace el usuario una vez que lo releyó.
7. **Sembrá el archivo de config si no existe.** Fijate si existe `specs/.spec-config.yml`. Si **falta**, crealo con el contenido por defecto de abajo. Si **ya existe, dejalo intacto** — nunca sobrescribas la configuración del usuario.

   ```yaml
   # spec workflow configuration
   #
   # AutoCreateBranch — controla si /spec-impl crea la rama git automáticamente.
   #   true  (por defecto) → /spec-impl crea y cambia a spec-NN-slug sin preguntar
   #   false               → /spec-impl pide confirmación [y/N] antes de crear la rama
   AutoCreateBranch: true
   ```

8. Confirmá al usuario:
   - Ruta del archivo creado.
   - Recordatorio: el spec está en estado `Borrador`. Cambialo a `Aprobado` una vez que lo hayas releído.
   - Si acabás de crear `specs/.spec-config.yml`, mencioná que existe y que `AutoCreateBranch` es `true` por defecto (ponelo en `false` para controlar vos la creación de rama).
   - Próximo paso: una vez revisado y aprobado, ejecutá `/spec-impl NN-slug` para implementarlo.
   - **Detenete acá.** No propongas implementar el spec, escribir código ni tomar ninguna acción más allá de esta confirmación.

## Reglas duras

- **Nunca escribas código durante este comando.** Solo el archivo `.md` del spec al final.
- **Nunca propongas implementar el spec después de guardarlo.** Tu trabajo termina cuando el archivo está escrito. El usuario ejecuta `/spec-impl` cuando esté listo.
- **Nunca asumas decisiones que el usuario no confirmó.** Si te falta información, preguntá.
- **La estructura de `references/estructura/estructura.md` y las convenciones de `references/instructions/instructions.md` son obligatorias.** Si el usuario pide algo que las contradice, señalalo, proponé la alternativa correcta y registralo en decisiones. No generes planes con paquetes planos.
- **Nunca escribas un plan sin rutas completas.** Cada archivo del plan debe indicar `src/main/java/<base>/<capa>/<subcapa>/Archivo.java` (o su equivalente de test).
- **Nunca generes el spec completo en una sola respuesta.** Sección por sección, con confirmación.
- **Si el usuario quiere acelerar y saltear la Fase 2**, recordale: "Las preguntas ahora ahorran horas después. ¿Seguro que querés saltearlas?". Si insiste, respetá su decisión pero registrala en la sección de decisiones del spec ("Definición rápida sin aclaración detallada").
- **Si la feature es demasiado grande** (no entra en una oración, toca más de tres áreas del sistema, requiere decisiones en cuatro o más dominios), proponé dividirla en dos o más specs antes de continuar.

## Tono al hacer preguntas

Sé directo y específico. No te disculpes por preguntar. No uses frases como "si no te molesta..." o "¿podrías quizás...?". El usuario invocó esta skill precisamente porque quiere que hagas preguntas. Usá preguntas concretas, una por línea cuando haya varias, y numerálas para que sean fáciles de responder.

Ejemplo de un bloque bien formado:

> Antes de escribir el modelo de datos necesito aclarar tres cosas:
>
> 1. **Persistencia.** ¿localStorage, IndexedDB o un archivo JSON en disco? Recomendación: localStorage si los datos entran en <5MB y no necesitan consultas.
> 2. **Versionado del esquema.** ¿Qué pasa cuando cambia el formato? Opciones: (a) prefijo de versión en la clave, (b) ignorar y reconstruir, (c) migrar al cargar.
> 3. **Privacidad.** ¿Los datos son sensibles? Si sí, ¿están cifrados? ¿Se borran al cerrar sesión?

## Argumentos

Si el usuario invocó `/spec levels-and-highscores`, usá `levels-and-highscores` como sugerencia de slug inicial, pero confirmá con el usuario antes de escribir el archivo.

Si invocó `/spec` sin argumentos, empezá pidiendo la descripción de una oración.
