---
name: update-golang-stack
description: Analiza el proyecto Golang actual (leyendo go.mod) y actualiza automáticamente el stack tecnológico, dependencias y versión de Go en Agents.md.
---

# Skill: Actualizar Tech Stack de Golang para OpenCode

### Descripción

Este skill instruye a OpenCode para que inspeccione de forma autónoma el directorio de trabajo de un proyecto Go, identifique la versión del lenguaje, el módulo principal, las dependencias y librerías clave (`sqlc`, routers, ORMs, drivers), y mantenga sincronizado el archivo `Agents.md`.

---

### Instrucciones de Ejecución

Cuando el usuario ejecute este skill o pida actualizar el contexto de Golang, sigue estos pasos estrictamente utilizando tus herramientas de lectura y escritura de archivos:

#### Paso 1: Inspección del Workspace

Busca y lee los archivos de configuración en la raíz del proyecto:

1. **`go.mod`**: Analiza su contenido para extraer:
   - Versión de Go (ej. `go 1.22`, `go 1.23`).
   - Nombre del módulo (`module ...`).
   - Dependencias clave (`require (...)`) como:
     - Frameworks / Routers web (ej. `gin-gonic/gin`, `labstack/echo`, `go-chi/chi`, `fiber`).
     - Bases de datos y SQL (ej. `lib/pq`, `pgx`, `sqlc`, `gorm`, `sqlx`, `ent`).
     - Utilidades de archivos, concurrencia o parsers (ej. manejo de PDFs, procesamiento de texto).
     - Pruebas y CLI (ej. `cobra`, `viper`).

#### Paso 2: Generación del Bloque Markdown

Sintetiza los hallazgos en una lista limpia y estructurada:

- **Lenguaje:** Go [Versión detectada]
- **Módulo Principal:** [Nombre del módulo]
- **Framework / Enrutador:** [Gin / Echo / Chi / Ninguno (Standard Library)]
- **Base de datos / Persistencia:** [pgx / sqlc / GORM / etc.]
- **Librerías Clave:** [Cobra, Viper, etc.]

#### Paso 3: Actualización de `Agents.md`

1. Comprueba si el archivo `Agents.md` existe en la raíz del proyecto. Si no existe, créalo.
2. Busca los marcadores de anclaje:
   ```markdown
   <!-- GOLANG_STACK:START -->
   <!-- GOLANG_STACK:END -->
   ```
---
name: update-golang-stack
description: Analiza el proyecto Golang actual (leyendo go.mod) y actualiza automáticamente el stack tecnológico, dependencias y versión de Go en Agents.md.
---

# Skill: Actualizar Tech Stack de Golang para OpenCode

### Descripción

Este skill instruye a OpenCode para que inspeccione de forma autónoma el directorio de trabajo de un proyecto Go, identifique la versión del lenguaje, el módulo principal, las dependencias y librerías clave (`sqlc`, routers, ORMs, drivers), y mantenga sincronizado el archivo `Agents.md`.

---

### Instrucciones de Ejecución

Cuando el usuario ejecute este skill o pida actualizar el contexto de Golang, sigue estos pasos estrictamente utilizando tus herramientas de lectura y escritura de archivos:

#### Paso 1: Inspección del Workspace

Busca y lee los archivos de configuración en la raíz del proyecto:

1. **`go.mod`**: Analiza su contenido para extraer:
   - Versión de Go (ej. `go 1.22`, `go 1.23`).
   - Nombre del módulo (`module ...`).
   - Dependencias clave (`require (...)`) como:
     - Frameworks / Routers web (ej. `gin-gonic/gin`, `labstack/echo`, `go-chi/chi`, `fiber`).
     - Bases de datos y SQL (ej. `lib/pq`, `pgx`, `sqlc`, `gorm`, `sqlx`, `ent`).
     - Utilidades de archivos, concurrencia o parsers (ej. manejo de PDFs, procesamiento de texto).
     - Pruebas y CLI (ej. `cobra`, `viper`).

#### Paso 2: Generación del Bloque Markdown

Sintetiza los hallazgos en una lista limpia y estructurada:

- **Lenguaje:** Go [Versión detectada]
- **Módulo Principal:** [Nombre del módulo]
- **Framework / Enrutador:** [Gin / Echo / Chi / Ninguno (Standard Library)]
- **Base de datos / Persistencia:** [pgx / sqlc / GORM / etc.]
- **Librerías Clave:** [Cobra, Viper, etc.]

#### Paso 3: Actualización de `Agents.md`

1. Comprueba si el archivo `Agents.md` existe en la raíz del proyecto. Si no existe, créalo.
2. Busca los marcadores de anclaje:
   ```markdown
   <!-- GOLANG_STACK:START -->
   <!-- GOLANG_STACK:END -->
   ```
3. Sustituye **únicamente** el contenido comprendido entre ambos marcadores por el bloque Markdown generado en el Paso 2. No modifiques el resto del archivo ni dupliques los marcadores.
4. Si los marcadores no existen, añade la sección `## Golang Stacks` al final del archivo con los marcadores y el bloque dentro.
5. Conserva la codificación UTF-8 y no alteres otras secciones (p. ej. el flujo de specs o la configuración de MCPs).

#### Notas

- Si el repositorio usa `AGENTS.md` (mayúsculas), trabaja sobre ese archivo en lugar de crear un `Agents.md` nuevo.
- Si no se detecta base de datos o testing, indícalo explícitamente como «Ninguna» en lugar de omitir la línea.
