---
name: spec-impl
description: Implementa un spec aprobado. Valida que el estado signifique "Aprobado" (en cualquier idioma), crea una rama git con el nombre del spec, cambia a ella, y arranca la implementación paso a paso con pausas para revisar los diffs.
disable-model-invocation: true
argument-hint: <NN-nombre-spec>
allowed-tools: Bash(git status:*), Bash(git branch:*), Bash(git checkout:*), Bash(git diff:*), Bash(git add:*), Bash(git commit:*), Bash(cat:*), Bash(ls:*), Bash(node:*)
---

# /spec-impl — Implementador de specs aprobados

## Contexto de sesión

Estado actual del repositorio:
!`git status --short`

Rama actual:
!`git branch --show-current`

Specs disponibles en esta carpeta:
!`ls specs/ 2>/dev/null || echo "La carpeta specs/ no existe"`

Configuración de creación de rama:
!`cat specs/.spec-config.yml 2>/dev/null || echo "AutoCreateBranch: true (por defecto, sin archivo de config)"`

---

## Instrucciones

Seguí estas cinco fases en orden estricto. **No avances a la fase siguiente si la anterior no se completó correctamente.**

---

### Fase 1 — Identificar el spec

El argumento recibido es: `$ARGUMENTS`

Si `$ARGUMENTS` está vacío:

- Listá los archivos disponibles en `specs/` (ya los tenés arriba).
- Pedile al usuario que especifique el nombre exacto del spec.
- Detenete y esperá una respuesta. No continúes.

Si `$ARGUMENTS` tiene un valor:

- Buscá el archivo en `specs/`. El usuario puede haber escrito el nombre completo (`01-mvp-arkanoid`), solo el número (`01`) o solo el slug (`mvp-arkanoid`). Intentá encontrar el archivo correcto en cualquiera de esos casos.
- Si no encontrás el archivo, mostrá los specs disponibles y pedile al usuario que corrija el nombre.
- Si lo encontrás, continuá a la Fase 2.

---

### Fase 2 — Validar el estado del spec

Leé el archivo del spec que localizaste en la Fase 1 con la herramienta Read o `cat`.

En el contenido del archivo, buscá la línea que contiene el estado del spec. La etiqueta del encabezado típicamente es `**Status:**` (inglés) o `**Estado:**` (español), pero puede usar cualquier idioma. Coincidí por posición (la línea de estado cerca del inicio del spec) y por la máquina de estados circundante, no por la etiqueta exacta.

**Regla absoluta:** solo podés continuar si el estado **significa "Aprobado"** — sin importar el idioma usado.

Tratá cualquiera de los siguientes (y sus equivalentes en otros idiomas) como el estado **Aprobado** y continuá:

- Español: `Aprobado`
- Inglés: `Approved`
- Portugués: `Aprovado`
- Francés: `Approuvé`
- Alemán: `Genehmigt`
- Italiano: `Approvato`
- …o cualquier otra palabra de otro idioma que claramente signifique "aprobado".

Cualquier otra cosa (Draft / Borrador, In review / En revisión, Implemented / Implementado, Obsolete / Obsoleto, o cualquier valor no reconocido) significa **detenerse** y mostrar el mensaje de error de abajo.

| Categoría de estado                                 | Ejemplos (cualquier idioma)                       | Acción                                                                   |
| --------------------------------------------------- | ------------------------------------------------- | ------------------------------------------------------------------------ |
| Aprobado                                            | `Approved`, `Aprobado`, `Aprovado`, `Approuvé`, … | Continuar a la Fase 3.                                                   |
| Borrador                                            | `Draft`, `Borrador`, …                            | Detenerse. Mostrar el mensaje de error de abajo.                         |
| En revisión                                         | `In review`, `En revisión`, …                     | Detenerse. Mostrar el mensaje de error de abajo.                         |
| Implementado                                        | `Implemented`, `Implementado`, …                  | Detenerse. Mostrar el mensaje de error de abajo.                         |
| Obsoleto                                            | `Obsolete`, `Obsoleto`, …                         | Detenerse. Mostrar el mensaje de error de abajo.                         |
| Línea de estado no encontrada / valor no reconocido | —                                                 | Detenerse. El archivo no sigue el formato esperado. Decíselo al usuario. |

Si no estás seguro de si un valor significa "aprobado", **no asumas**. Detenete y pedile al usuario que aclare o que actualice el spec al texto canónico.

**Mensaje de error estándar cuando el estado no significa Aprobado:**

```
❌ No puedo implementar este spec.

Estado actual: [ESTADO ENCONTRADO]
Solo trabajo con specs cuyo estado signifique "Aprobado" (p. ej. `Approved`,
`Aprobado`, o el equivalente en otro idioma).

Para continuar tenés dos opciones:
  1. Si el spec está listo para implementarse, abrilo y cambiá el estado
     a "Aprobado" (o el término equivalente que use tu equipo) manualmente.
     Ese cambio lo hace el humano, no el agente.
  2. Si el spec todavía necesita trabajo, usá /spec [nombre] para retomarlo.
```

No ofrezcas alternativas, no sugieras "igual puedo empezar si querés". El bloqueo es intencional.

---

### Fase 3 — Crear la rama git y cambiar a ella

Una vez confirmado que el estado significa `Aprobado`:

1. Derivá el nombre de la rama del nombre completo del archivo del spec, sin la extensión. Formato: `spec-NN-slug`. Ejemplos:
   - `01-mvp-arkanoid.md` → rama `spec-01-mvp-arkanoid`
   - `02-powerups.md` → rama `spec-02-powerups`

2. Leé el flag `AutoCreateBranch` de la **Configuración de creación de rama** mostrada en el contexto de sesión de arriba.
   - Si el archivo de config no existe, falta el valor, o el valor no se reconoce → tratalo como `true` (el valor por defecto).
   - Solo un `false` explícito (en cualquier capitalización) desactiva la creación automática de rama.

   **Si `AutoCreateBranch` es `true` (por defecto):** procedé sin preguntar.
   - Si la rama **no existe**: creala con `git checkout -b spec-NN-slug`.
   - Si **ya existe**: informá al usuario que la rama ya existía (puede significar que se retoma trabajo previo).
   - En ambos casos: cambiá a la rama con `git checkout spec-NN-slug` y confirmá que el cambio fue exitoso antes de continuar.

   **Si `AutoCreateBranch` es `false`:** preguntá antes de tocar git. Mostrá:

   ```
   AutoCreateBranch está en false.
   ¿Crear y cambiar a la rama spec-NN-slug? [y/N]
   ```

   - Si el usuario responde **sí**: creá/cambiá a la rama exactamente como en el caso `true`.
   - Si el usuario responde **no** o lo deja vacío: **no crees ninguna rama.** Decile al usuario que vas a implementar en la rama actual (la mostrada en el contexto de sesión de arriba) y pedí confirmación explícita para continuar ahí. No improvises — esperá la respuesta.

3. Confirmá visualmente al usuario que el spec está listo y qué rama está activa:

   ```
   ✅ Listo para implementar.

   Spec:   specs/NN-slug.md
   Rama:   spec-NN-slug  (activa)   (← o la rama actual, si no se creó una nueva)
   Estado: Aprobado   (← repetí el valor real encontrado en el spec)
   ```

4. Inicializá la línea base de métricas de este spec. Es la referencia para medir tokens y LOC reales al cierre:

   ```bash
   node .agents/skills/opencode-metrics-spec/scripts/spec-metrics.mjs start --spec NN-slug
   ```

   Si el comando falla, informá el motivo y continuá. Al cierre se podrán pasar los tokens a mano. No inventes métricas.

5. **No empieces a implementar todavía.** Primero mostrá el resumen del spec al usuario para que lo tenga fresco. Extraé y mostrá:
   - El **objetivo** (la línea después de `**Objective:**` / `**Objetivo:**` / etiqueta equivalente).
   - El **alcance** (la sección `## Scope` / `## Alcance` / equivalente).
   - El **plan de implementación** (la sección con los pasos numerados — `## Implementation plan` / `## Plan de implementación` / equivalente).
   - Los **criterios de aceptación** (la checklist — `## Acceptance criteria` / `## Criterios de aceptación` / equivalente).

   Coincidí con los encabezados de sección por significado, no por redacción exacta — el spec puede estar escrito en cualquier idioma.

---

### Fase 4 — Implementar paso a paso

Después de mostrar el resumen del spec, decile al usuario:

```
Voy a implementar el spec siguiendo el plan de implementación al pie de la letra.
Me detendré después de cada paso para que revises el diff.

¿Empezamos con el Paso 1?
```

Esperá confirmación explícita ("sí", "dale", "vamos", o equivalente). No empieces sin ella.

Una vez confirmado, seguí estas reglas durante toda la implementación:

**Una regla por encima de todo:** implementá lo que dice el spec. Si algo del spec te parece subóptimo, mencionalo como observación pero implementá lo acordado. Los cambios al spec van en el spec, no en el código por sorpresa.

**Guarda de estructura (obligatoria):** antes del Paso 1, contrastá la tabla de archivos y el plan contra `references/estructura/estructura.md` y `references/instructions/instructions.md`. Si el spec ubica un artefacto en un paquete plano (p. ej. `<base>.controller`, `<base>.service`) o fuera de `domain/`, `application/`, `infrastructure/` o `configuration/`, **detenete**: corregí el spec primero y avisá al usuario. La estructura y las convenciones son obligatorias, igual que el resto del spec.

**Ritmo de trabajo:**

- Implementá un paso del plan.
- Mostrá un resumen de qué archivos tocaste y qué hiciste.
- Decí: `Paso N completado. ¿Podés revisar el diff y decirme si continúo con el Paso N+1?`
- Esperá confirmación antes de continuar.

**Si durante la implementación encontrás una ambigüedad** que el spec no resuelve:

- Detenete.
- Describí la ambigüedad exactamente.
- Presentá dos o tres opciones concretas.
- Esperá la decisión del usuario.
- No improvises.

**Si el usuario pide algo fuera del alcance del spec:**

- Recordale que está fuera del alcance de este spec.
- Sugerí anotarlo para el próximo spec.
- No lo implementes en esta rama.

**Al terminar el último paso:**

```
✅ Todos los pasos del plan están implementados.

Próximo paso: Fase 5 — verificar los criterios de aceptación y registrar
las métricas antes de cerrar el spec.
```

---

### Fase 5 — Verificar criterios y registrar métricas (antes de completar)

**Esta fase es obligatoria. Un spec no se marca como `Implementado` sin el reporte de cambios generado y sin las métricas registradas.** El reporte lo produce la skill `opencode-report-change-object` y se genera antes de las métricas; las métricas las produce `opencode-metrics-spec`. No los calcules a mano.

1. Verificá con el usuario, uno por uno, los criterios de aceptación del spec.

2. Si algún criterio falla:
   - No ejecutes las métricas.
   - No cambies el estado del spec.
   - Volvé a la implementación, corregí y repetí la verificación.

3. Si todos los criterios pasan, preguntá si quiere ejecutar `/verify-spec NN-slug` antes de cerrar. Es el momento correcto: el verificador corre en una sesión nueva del mismo directorio y sus tokens entran en la medición.
   - **Sí:** ejecutalo ahora (subagente, o pedile al usuario que lo corra en este mismo directorio). El verificador **no** debe cambiar el estado ni ejecutar `finalize`; si corrige código o el spec, volvé a verificar los criterios afectados.
   - **No:** continuá con el cierre.

   No ejecutes `finalize` en esta fase: borra la línea base y los tokens del verificador quedarían sin atribuir.

4. Generá el reporte de cambios del spec **antes** de registrar las métricas:

   ```bash
   node .agents/skills/opencode-report-change-object/scripts/spec-changes-report.mjs --spec NN-slug
   ```

   Escribe `reports/NN-slug.csv` con una fila por objeto (`fecha,hora,ruta,objeto,tipo,comentario`). Validá que exista, que el encabezado sea correcto y que el `tipo` sea `Nuevo`, `Modificado` o `Eliminado`. Si sale vacío o falla, no cierres el spec: ajustá la base con `--base <ref>` y repetí. La skill `opencode-report-change-object` describe el flujo completo.

5. Registrá las métricas **antes** de tocar el estado del spec:

   ```bash
   node .agents/skills/opencode-metrics-spec/scripts/spec-metrics.mjs finish --spec NN-slug
   ```

   Agregá `--observaciones "..."` si hay algo relevante para el histórico. Si ya habías ejecutado `finish` antes de la verificación, repetilo: reemplaza la fila e incluye la sesión del verificador.

6. Mostrá al usuario el bloque `TAREA FINALIZADA (SPEC)` que imprime el script, sin resumirlo ni modificar los números.

7. Si el script avisa que no pudo leer los tokens:
   - Pedile al usuario los números reales, o leelos de `opencode stats --json --project . --days 1`.
   - Repetí `finish` con `--input`, `--output`, `--cache-read`, `--cache-write` y `--cost`.
   - Solo si de verdad corresponde 0 consumo, agregá `--allow-zero` y dejá el motivo en `--observaciones`. No inventes valores.

8. Solo después de que el reporte y `finish` terminen correctamente:
   - Actualizá el estado del spec a `Implementado` (o el equivalente del repo).
   - Hacé el commit final incluyendo `metrics/`, `reports/` y el cambio de estado.
   - Mergeá la rama si corresponde.

9. Si `finish` falla, no cierres el spec. Corregí el error y volvé a ejecutarlo.

---

## Resumen del comportamiento esperado

```
/spec-impl 01-mvp-arkanoid

  Fase 1  →  Encuentra specs/01-mvp-arkanoid.md
  Fase 2  →  Lee el estado → "Aprobado" (o "Approved", etc.) → ✅ continúa
  Fase 3  →  git checkout -b spec-01-mvp-arkanoid → git checkout spec-01-mvp-arkanoid
              metrics start (línea base de tokens y git)
              Muestra objetivo, alcance, plan y criterios
  Fase 4  →  Implementa paso a paso con pausas
  Fase 5  →  Verifica criterios de aceptación
              reporte de cambios → reports/01-mvp-arkanoid.csv
              metrics finish → CSV + dashboard + resumen mensual
              Recién entonces: estado "Implementado" + commit final

/spec-impl 02-powerups  (estado: Borrador)

  Fase 1  →  Encuentra specs/02-powerups.md
  Fase 2  →  Lee el estado → "Borrador" → ❌ se detiene
              Muestra el mensaje de error estándar
              No crea rama, no toca código, no registra métricas
```

**La creación de rama está controlada por el flag `AutoCreateBranch`** en `specs/.spec-config.yml`. Por defecto es `true` (crea la rama automáticamente, como se muestra arriba). Ponelo en `false` para que la Fase 3 pregunte `[y/N]` antes de crear la rama.
